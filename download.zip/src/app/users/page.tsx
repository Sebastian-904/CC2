

"use client";

import * as React from "react";
import { UsersTable } from "@/components/users-table";
import { AppHeader } from "@/components/app-header";
import { useApp } from "@/components/app-providers";
import { Skeleton } from "@/components/ui/skeleton";
import type { User } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

export default function UsersPage() {
    const { activeCompany, isLoading, updateCompany } = useApp();
    const { toast } = useToast();

    const handleUsersChange = async (updatedUsers: User[]) => {
        if (!activeCompany) return;

        try {
            await updateCompany(activeCompany.id, { users: updatedUsers });
            
            toast({
                title: "Usuarios Actualizados",
                description: "La lista de usuarios ha sido guardada con éxito.",
            });

        } catch (error) {
            console.error("Error updating users:", error);
            toast({
                variant: "destructive",
                title: "Error",
                description: "No se pudo guardar la lista de usuarios.",
            });
        }
    };

    return (
        <>
            <AppHeader />
            <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
            <div className="container mx-auto">
                {isLoading ? (
                    <div className="space-y-4">
                        <Skeleton className="h-10 w-1/3" />
                        <Skeleton className="h-4 w-2/3" />
                        <Skeleton className="h-64 w-full" />
                    </div>
                ) : activeCompany ? (
                    <UsersTable 
                        company={activeCompany}
                        onUsersChange={handleUsersChange}
                    />
                ) : (
                     <div className="text-center py-10">
                        <h2 className="text-xl font-semibold">Seleccione una empresa</h2>
                        <p className="text-muted-foreground mt-2">Por favor, seleccione una empresa para gestionar sus usuarios.</p>
                    </div>
                )}
            </div>
            </main>
        </>
    );
}
