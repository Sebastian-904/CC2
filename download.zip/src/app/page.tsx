
"use client";

import { redirect } from 'next/navigation';
import * as React from 'react';
import { useAuth } from '@/contexts/auth-context';

export default function RootPage() {
  const { user, loading } = useAuth();

  React.useEffect(() => {
    // Since login is disabled and user is mocked, always redirect to dashboard.
    redirect('/dashboard');
  }, []);

  // You can render a loading spinner here while the redirect is happening
  return null; 
}
