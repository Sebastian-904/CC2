

"use client";

import * as React from "react";
import Link from "next/link";
import { Globe, Clock, Bell, Palette, LayoutTemplate } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { ThemeToggle } from "@/components/theme-toggle";
import { AppHeader } from "@/components/app-header";
import { HelpCenter } from "@/components/help-center";
import { useApp } from "@/components/app-providers";

export default function SettingsPage() {
  const { user } = useApp();
  const [language, setLanguage] = React.useState("es");
  const [timeFormat, setTimeFormat] = React.useState("24h");
  const [isHelpCenterOpen, setIsHelpCenterOpen] = React.useState(false);
  
  const canManageTemplates = user?.role === 'admin' || user?.role === 'consultor';
  
  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          <div className="container mx-auto">
              <h1 className="text-2xl font-semibold mb-6">Configuración</h1>
              <div className="grid gap-8 max-w-3xl mx-auto">
                  
                  <Card>
                      <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                              <Palette />
                              Preferencias de Visualización
                          </CardTitle>
                          <CardDescription>
                              Personaliza la apariencia y la experiencia de la aplicación.
                          </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-6">
                          <div className="flex items-center justify-between">
                              <Label>Tema (Claro/Oscuro)</Label>
                              <ThemeToggle />
                          </div>
                          <div className="flex items-center justify-between">
                             <Label htmlFor="language-select" className="flex items-center gap-2">
                                  <Globe className="h-4 w-4" />
                                  Idioma
                              </Label>
                              <Select value={language} onValueChange={setLanguage}>
                                  <SelectTrigger id="language-select" className="w-[180px]">
                                      <SelectValue placeholder="Seleccionar idioma" />
                                  </SelectTrigger>
                                  <SelectContent>
                                      <SelectItem value="en">English</SelectItem>
                                      <SelectItem value="es">Español</SelectItem>
                                  </SelectContent>
                              </Select>
                          </div>
                           <div className="space-y-3">
                              <Label className="flex items-center gap-2">
                                  <Clock />
                                  Formato de Hora
                              </Label>
                              <RadioGroup value={timeFormat} onValueChange={setTimeFormat} className="flex gap-4">
                                  <div className="flex items-center space-x-2">
                                      <RadioGroupItem value="12h" id="12h" />
                                      <Label htmlFor="12h">12 horas (ej., 3:00 PM)</Label>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                      <RadioGroupItem value="24h" id="24h" />
                                      <Label htmlFor="24h">24 horas (ej., 15:00)</Label>
                                  </div>
                              </RadioGroup>
                          </div>
                      </CardContent>
                  </Card>

                  {canManageTemplates && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <LayoutTemplate />
                                Plantillas y Categorías
                            </CardTitle>
                            <CardDescription>
                                Administra las categorías y plantillas para estandarizar la creación de tareas.
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="flex justify-start">
                          <Button variant="outline" asChild>
                                <Link href="/templates">
                                    Administrar Plantillas y Categorías
                                </Link>
                          </Button>
                        </CardContent>
                    </Card>
                  )}


                  <Card>
                      <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                              <Bell />
                              Notificaciones por Correo
                          </CardTitle>
                           <CardDescription>
                              Gestiona qué notificaciones quieres recibir. (Funcionalidad de demostración)
                          </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                          <div className="flex items-center justify-between p-2 rounded-md bg-secondary/50">
                              <Label htmlFor="notif-7-days">Recordatorio 7 días antes</Label>
                              <Switch id="notif-7-days" defaultChecked />
                          </div>
                           <div className="flex items-center justify-between p-2 rounded-md bg-secondary/50">
                              <Label htmlFor="notif-1-day">Recordatorio 1 día antes</Label>
                              <Switch id="notif-1-day" defaultChecked />
                          </div>
                           <div className="flex items-center justify-between p-2 rounded-md bg-secondary/50">
                              <Label htmlFor="notif-same-day">Recordatorio el mismo día</Label>
                              <Switch id="notif-same-day" />
                          </div>
                          <div className="flex items-center justify-between p-2 rounded-md bg-secondary/50">
                              <Label htmlFor="notif-summary">Resumen semanal de tareas</Label>
                              <Switch id="notif-summary" defaultChecked />
                          </div>
                      </CardContent>
                  </Card>
              </div>
               <div className="flex justify-end mt-8 max-w-3xl mx-auto">
                  <Button>Guardar Preferencias</Button>
              </div>
          </div>
      </main>
      <HelpCenter 
        isOpen={isHelpCenterOpen}
        onOpenChange={setIsHelpCenterOpen}
      />
    </>
  );
}
