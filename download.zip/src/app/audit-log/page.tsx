
"use client";

import * as React from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { Download, SlidersHorizontal } from "lucide-react";
import * as XLSX from "xlsx";
import { AppHeader } from "@/components/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useApp } from "@/components/app-providers";
import type { AuditLog } from "@/lib/types";
import { getAuditLogs } from "@/lib/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";

export default function AuditLogPage() {
  const { user, companies, globalUsers } = useApp();
  const [logs, setLogs] = React.useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  
  const [filters, setFilters] = React.useState({
    userId: "",
    companyId: "",
    startDate: undefined as Date | undefined,
    endDate: undefined as Date | undefined,
  });

  const allUsers = React.useMemo(() => {
    const combined = [...globalUsers];
    companies.forEach(c => {
        (c.users || []).forEach(u => {
            if (!combined.some(gu => gu.id === u.id)) {
                combined.push(u);
            }
        });
    });
    return combined;
  }, [globalUsers, companies]);

  React.useEffect(() => {
    const fetchLogs = async () => {
      if (!user || (user.role !== 'admin' && user.role !== 'consultor')) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      try {
        const fetchedLogs = await getAuditLogs({ filters });
        setLogs(fetchedLogs);
      } catch (error) {
        console.error("Error fetching audit logs:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchLogs();
  }, [filters, user]);

  const handleDownload = () => {
    const dataToExport = logs.map(log => ({
        'Fecha y Hora': format(new Date(log.timestamp), "dd/MM/yyyy HH:mm:ss"),
        'Usuario': log.userName,
        'ID Usuario': log.userId,
        'Acción': log.action,
        'Empresa': log.companyName || 'N/A',
        'Detalles': log.details,
    }));
    
    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Audit Log");
    XLSX.writeFile(wb, `Reporte_Auditoria_${format(new Date(), "yyyy-MM-dd")}.xlsx`);
  };
  
  const clearFilters = () => {
      setFilters({ userId: "", companyId: "", startDate: undefined, endDate: undefined });
  }

  if (!user || (user.role !== 'admin' && user.role !== 'consultor')) {
    return (
        <>
            <AppHeader />
            <main className="flex-1 p-4 md:p-6 lg:p-8">
                 <div className="container mx-auto text-center py-10">
                    <h1 className="text-2xl font-bold text-destructive">Acceso Denegado</h1>
                    <p className="text-muted-foreground mt-2">
                        No tienes los permisos necesarios para acceder a esta sección.
                    </p>
                </div>
            </main>
        </>
    )
  }

  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Registro de Auditoría</CardTitle>
                  <CardDescription>
                    Monitorea todas las acciones importantes realizadas en la plataforma.
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline">
                        <SlidersHorizontal className="mr-2 h-4 w-4" />
                        Filtros
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80" align="end">
                      <div className="grid gap-4">
                        <div className="space-y-2">
                          <h4 className="font-medium leading-none">Aplicar Filtros</h4>
                          <p className="text-sm text-muted-foreground">
                            Refina los resultados del registro.
                          </p>
                        </div>
                        <div className="grid gap-2">
                          <div className="grid grid-cols-3 items-center gap-4">
                            <Label htmlFor="user-filter">Usuario</Label>
                            <Select value={filters.userId} onValueChange={(value) => setFilters(f => ({ ...f, userId: value }))}>
                                <SelectTrigger id="user-filter" className="col-span-2 h-8"><SelectValue placeholder="Todos" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="">Todos</SelectItem>
                                    {allUsers.map(u => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                          </div>
                           <div className="grid grid-cols-3 items-center gap-4">
                            <Label htmlFor="company-filter">Empresa</Label>
                             <Select value={filters.companyId} onValueChange={(value) => setFilters(f => ({ ...f, companyId: value }))}>
                                <SelectTrigger id="company-filter" className="col-span-2 h-8"><SelectValue placeholder="Todas" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="">Todas</SelectItem>
                                    {companies.map(c => <SelectItem key={c.id} value={c.id}>{c.generalInfo.legalName}</SelectItem>)}
                                </SelectContent>
                            </Select>
                          </div>
                           <div className="grid grid-cols-3 items-center gap-4">
                               <Label>Fecha Inicio</Label>
                               <Popover>
                                    <PopoverTrigger asChild><Button variant={"outline"} className="col-span-2 h-8 font-normal">{filters.startDate ? format(filters.startDate, "dd/MM/yyyy") : "Seleccionar"}</Button></PopoverTrigger>
                                    <PopoverContent><Calendar mode="single" selected={filters.startDate} onSelect={(d) => setFilters(f => ({...f, startDate: d}))} initialFocus/></PopoverContent>
                                </Popover>
                           </div>
                            <div className="grid grid-cols-3 items-center gap-4">
                               <Label>Fecha Fin</Label>
                               <Popover>
                                    <PopoverTrigger asChild><Button variant={"outline"} className="col-span-2 h-8 font-normal">{filters.endDate ? format(filters.endDate, "dd/MM/yyyy") : "Seleccionar"}</Button></PopoverTrigger>
                                    <PopoverContent><Calendar mode="single" selected={filters.endDate} onSelect={(d) => setFilters(f => ({...f, endDate: d}))} initialFocus/></PopoverContent>
                                </Popover>
                           </div>
                           <Button variant="ghost" size="sm" onClick={clearFilters} className="mt-2">Limpiar Filtros</Button>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>
                   <Button onClick={handleDownload} disabled={logs.length === 0}>
                        <Download className="mr-2 h-4 w-4" />
                        Descargar Reporte
                   </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">Fecha y Hora</TableHead>
                      <TableHead>Usuario</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead>Acción</TableHead>
                      <TableHead>Detalles</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      [...Array(10)].map((_, i) => (
                        <TableRow key={i}>
                          <TableCell><Skeleton className="h-5 w-36" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-28" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-full" /></TableCell>
                        </TableRow>
                      ))
                    ) : logs.length > 0 ? (
                      logs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="text-muted-foreground text-xs">{format(new Date(log.timestamp), "dd/MM/yyyy HH:mm:ss", { locale: es })}</TableCell>
                          <TableCell className="font-medium">{log.userName}</TableCell>
                          <TableCell className="text-muted-foreground">{log.companyName || 'N/A'}</TableCell>
                          <TableCell><Badge variant="secondary">{log.action}</Badge></TableCell>
                          <TableCell className="text-sm text-muted-foreground">{log.details}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          No se encontraron registros de auditoría para los filtros seleccionados.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </>
  );
}
