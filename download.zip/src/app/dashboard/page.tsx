
"use client";

import * as React from "react";
import { isSameDay } from "date-fns";
import { CalendarSection } from "@/components/calendar-section";
import { EventDetails } from "@/components/event-details";
import type { CalendarEvent } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { useApp } from "@/components/app-providers";
import { AppHeader } from "@/components/app-header";
import { HelpCenter } from "@/components/help-center";
import { AiEventCreator } from "@/components/ai-event-creator";
import { CreateEventFromTextOutput } from "@/ai/flows/create-event-from-text";
import { DailyEventsList } from "@/components/daily-events-list";
import { OnboardingChecklist } from "@/components/onboarding-checklist";
import { ComplianceScoreKpi } from "@/components/compliance-score-kpi";
import { TasksByStatusChart } from "@/components/tasks-by-status-chart";
import { TasksByCategoryChart } from "@/components/tasks-by-category-chart";
import { TasksByUserChart } from "@/components/tasks-by-user-chart";
import { TaskEditDialog } from "@/components/task-edit-dialog";

type ChecklistState = {
  createdCompany: boolean;
  invitedUser: boolean;
  createdTask: boolean;
  generatedReport: boolean;
};


export default function DashboardPage() {
  const { events, isLoading, addObligationToCalendar, assigneeFilter, activeCompany, activeCompanyId, user, companies, taskCategories, addEvent, updateEvent, deleteEvent } = useApp();
  const [selectedEvent, setSelectedEvent] = React.useState<CalendarEvent | null>(null);
  const [selectedDate, setSelectedDate] = React.useState<Date>(new Date());

  const [isHelpCenterOpen, setIsHelpCenterOpen] = React.useState(false);
  const [isAiCreatorOpen, setIsAiCreatorOpen] = React.useState(false);

  const [checklistState, setChecklistState] = React.useState<ChecklistState | null>(null);
  const [isTaskEditDialogOpen, setIsTaskEditDialogOpen] = React.useState(false);
  const [editingEvent, setEditingEvent] = React.useState<Partial<CalendarEvent> | null>(null);


  React.useEffect(() => {
    if (user && (user.role === 'consultor' || user.role === 'admin')) {
      const storedState = localStorage.getItem('onboardingChecklistState');
      if (storedState) {
        const parsedState: ChecklistState = JSON.parse(storedState);
        if (!parsedState.createdCompany && companies.length > 1) {
          parsedState.createdCompany = true;
        }
        const company = companies.find(c => c.id === activeCompanyId);
        if (!parsedState.invitedUser && (company?.users?.length || 0) > 0) {
            parsedState.invitedUser = true;
        }
        if (!parsedState.createdTask && events.length > 0) {
            parsedState.createdTask = true;
        }
        setChecklistState(parsedState);
      } else {
        setChecklistState({
            createdCompany: companies.length > 1,
            invitedUser: (companies.find(c => c.id === activeCompanyId)?.users?.length || 0) > 0,
            createdTask: events.length > 0,
            generatedReport: false,
        });
      }
    }
  }, [user, companies, events, activeCompanyId]);

  React.useEffect(() => {
    if (checklistState) {
      localStorage.setItem('onboardingChecklistState', JSON.stringify(checklistState));
    }
  }, [checklistState]);

  const handleChecklistUpdate = (key: keyof ChecklistState) => {
    setChecklistState(prev => prev ? { ...prev, [key]: true } : null);
  };
  
  const showChecklist = user && (user.role === 'consultor' || user.role === 'admin') && checklistState && !Object.values(checklistState).every(Boolean);


  const filteredEvents = React.useMemo(() => {
    const allEvents = events || [];
    if (!assigneeFilter) {
      return allEvents;
    }
    return allEvents.filter(event => event.assignee?.id === assigneeFilter);
  }, [events, assigneeFilter]);
  
  const dailyEvents = React.useMemo(() => {
    return filteredEvents
      .filter((event) => isSameDay(new Date(event.date), selectedDate))
      .sort((a, b) => (a.startTime || "00:00").localeCompare(b.startTime || "00:00"));
  }, [filteredEvents, selectedDate]);

  React.useEffect(() => {
    if (dailyEvents.length > 0 && !dailyEvents.some(event => event.id === selectedEvent?.id)) {
      setSelectedEvent(dailyEvents[0]);
    } else if (dailyEvents.length === 0) {
      setSelectedEvent(null);
    }
  }, [dailyEvents, selectedEvent]);
  
  React.useEffect(() => {
        if (filteredEvents.length > 0 && !selectedEvent) {
            const latestEvent = [...filteredEvents].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
            if(latestEvent) {
              const eventDate = new Date(latestEvent.date);
              setSelectedDate(eventDate);
              setSelectedEvent(latestEvent);
            }
        } else if (filteredEvents.length === 0) {
            setSelectedEvent(null);
        }
  }, [filteredEvents, selectedEvent]);

  // Reset view when company changes
  React.useEffect(() => {
    setSelectedDate(new Date());
    setSelectedEvent(null);
  }, [activeCompanyId]);

  const handleEventCreated = (eventData: CreateEventFromTextOutput) => {
    addObligationToCalendar(eventData);
  }
  
  const handleEventSelectFromCalendar = (event: CalendarEvent) => {
    setSelectedDate(new Date(event.date));
    setSelectedEvent(event);
  }
  
  const handleOpenTaskDialog = (event: Partial<CalendarEvent> | null) => {
    if (event) {
        setEditingEvent(event);
    } else {
        setEditingEvent({ date: selectedDate.toISOString().split('T')[0] });
    }
    setIsTaskEditDialogOpen(true);
  }

  const handleTaskSave = async (data: Omit<CalendarEvent, 'id' | 'companyId'>, id: string | null) => {
    if (id) {
        await updateEvent(id, data);
    } else {
        await addEvent(data);
    }
    setIsTaskEditDialogOpen(false);
    setEditingEvent(null);
  }

  const handleTaskDelete = async (id: string) => {
    await deleteEvent(id);
    setIsTaskEditDialogOpen(false);
    setEditingEvent(null);
  }

  const MainContent = () => {
    if (isLoading) {
        return (
             <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    <Skeleton className="h-32 rounded-lg" />
                    <Skeleton className="h-32 rounded-lg" />
                    <Skeleton className="h-32 rounded-lg" />
                </div>
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 h-full">
                    <div className="xl:col-span-2 h-full flex flex-col">
                        <Skeleton className="w-full h-[500px] rounded-lg" />
                    </div>
                    <div className="h-full flex flex-col gap-4">
                        <Skeleton className="w-full flex-1 h-[250px] rounded-lg" />
                        <Skeleton className="w-full flex-1 h-[250px] rounded-lg" />
                    </div>
                </div>
            </div>
        )
    }

    return (
      <div className="space-y-6">
        {activeCompany ? (
            <>
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    <ComplianceScoreKpi events={events} />
                    <TasksByStatusChart events={events} />
                    {/* Placeholder for another KPI */}
                </div>

                <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 h-full">
                    <div className="xl:col-span-2 h-full flex flex-col">
                    <CalendarSection
                        events={filteredEvents}
                        selectedDate={selectedDate}
                        onDateChange={setSelectedDate}
                        taskCategories={taskCategories}
                        onEventSelect={handleEventSelectFromCalendar}
                    />
                    </div>
                    <div className="xl:col-span-1 h-full flex flex-col gap-4">
                    {showChecklist && checklistState && (
                            <OnboardingChecklist 
                                state={checklistState}
                                onMarkAsDone={handleChecklistUpdate}
                            />
                    )}
                    <div className="flex-1 min-h-0">
                        <DailyEventsList 
                            selectedDate={selectedDate}
                            dailyEvents={dailyEvents}
                            selectedEvent={selectedEvent}
                            onEventSelect={setSelectedEvent}
                            onAddTask={() => handleOpenTaskDialog(null)}
                        />
                    </div>
                    <div className="flex-1 min-h-0">
                        <EventDetails 
                            event={selectedEvent} 
                            onEdit={() => selectedEvent && handleOpenTaskDialog(selectedEvent)}
                        />
                    </div>
                    </div>
                </div>

                <div className="grid gap-6 lg:grid-cols-5 mt-6">
                    <div className="lg:col-span-3">
                        <TasksByCategoryChart events={events} />
                    </div>
                    <div className="lg:col-span-2">
                        <TasksByUserChart events={events} />
                    </div>
                </div>
            </>
        ) : (
             <div className="text-center py-10">
              <h2 className="text-xl font-semibold">Seleccione una empresa</h2>
              <p className="text-muted-foreground mt-2">Por favor, seleccione o cree una empresa para empezar a trabajar.</p>
            </div>
        )}
      </div>
    )
  }

  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto">
            <div className="mb-6">
                <h1 className="text-2xl font-semibold">Dashboard Unificado</h1>
                <p className="text-muted-foreground mt-1">
                    Vista operativa y análisis de rendimiento para {activeCompany?.generalInfo.legalName || "la empresa activa"}.
                </p>
            </div>
            <MainContent />
        </div>
      </main>
      <HelpCenter 
        isOpen={isHelpCenterOpen}
        onOpenChange={setIsHelpCenterOpen}
      />
      <AiEventCreator 
        isOpen={isAiCreatorOpen}
        onOpenChange={setIsAiCreatorOpen}
        onEventCreate={handleEventCreated}
      />
      <TaskEditDialog
        isOpen={isTaskEditDialogOpen}
        onOpenChange={setIsTaskEditDialogOpen}
        event={editingEvent}
        onSave={handleTaskSave}
        onDelete={handleTaskDelete}
      />
    </>
  );
}
