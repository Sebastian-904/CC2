
"use client";

import * as React from "react";
import { AppHeader } from "@/components/app-header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { MoreHorizontal, Pencil, PlusCircle, Trash2 } from "lucide-react";
import { useApp } from "@/components/app-providers";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import type { User } from "@/lib/types";
import { UserEditDialog } from "@/components/user-edit-dialog";
import { DeleteConfirmationDialog } from "@/components/template/delete-confirmation-dialog";
import { useToast } from "@/hooks/use-toast";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";


const roleTranslations: { [key in User['role']]: string } = {
    admin: "Administrador Global",
    consultor: "Consultor",
    cliente_admin: "Admin de Cliente",
    cliente_miembro: "Miembro de Cliente",
}

export default function AdminPage() {
  const { user, globalUsers, updateGlobalUsers, isLoading: isAppLoading } = useApp();
  const { toast } = useToast();
  
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingUser, setEditingUser] = React.useState<User | null>(null);

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false);
  const [itemToDelete, setItemToDelete] = React.useState<User | null>(null);
  const [justUpdatedId, setJustUpdatedId] = React.useState<string | null>(null);


  const handleSave = async (data: Omit<User, 'id' | 'avatarUrl' | 'password'>, userId: string | null) => {
    let updatedUsers: User[];
    let updatedId: string;

    if (userId) { // Editing
      const originalUser = globalUsers.find(u => u.id === userId);
      if (!originalUser) return;
      
      const updatedUser = { ...originalUser, ...data };
      
      updatedUsers = globalUsers.map(u => u.id === userId ? updatedUser : u);
      updatedId = userId;
      await updateGlobalUsers(updatedUsers);
       toast({ 
            title: 'Usuario Actualizado', 
            description: `Los datos de ${data.name} se han guardado correctamente.`
        });

    } else { // Adding
      const newUser: User = {
          id: `global-${Date.now()}`,
          name: data.name,
          email: data.email,
          role: data.role as 'admin' | 'consultor',
          avatarUrl: `https://placehold.co/32x32.png`,
      };
      updatedUsers = [...globalUsers, newUser];
      updatedId = newUser.id;
      await updateGlobalUsers(updatedUsers);
      toast({ 
          title: 'Usuario Creado', 
          description: `El acceso para ${data.name} se ha creado correctamente.`
      });
    }
    
    setIsDialogOpen(false);
    setJustUpdatedId(updatedId);
    setTimeout(() => setJustUpdatedId(null), 1500); // Remove highlight after animation
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;
    const updatedUsers = globalUsers.filter(u => u.id !== itemToDelete.id);
    await updateGlobalUsers(updatedUsers);
    toast({ title: "Usuario Eliminado", description: `${itemToDelete.name} ha sido eliminado de la plataforma.` });
    setItemToDelete(null);
    setIsDeleteDialogOpen(false);
  };

  const openDeleteDialog = (userToDelete: User) => {
    setItemToDelete(userToDelete);
    setIsDeleteDialogOpen(true);
  };
  
  const openEditDialog = (userToEdit: User | null) => {
    setEditingUser(userToEdit);
    setIsDialogOpen(true);
  };


  if (isAppLoading) {
     return (
       <>
        <AppHeader />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
            <div className="container mx-auto">
                <Card>
                    <CardHeader>
                        <Skeleton className="h-8 w-2/5" />
                        <Skeleton className="h-4 w-3/5" />
                    </CardHeader>
                    <CardContent>
                        <div className="border rounded-lg">
                           <Table>
                               <TableHeader>
                                   <TableRow>
                                       <TableHead><Skeleton className="h-5 w-24" /></TableHead>
                                       <TableHead><Skeleton className="h-5 w-32" /></TableHead>
                                       <TableHead><Skeleton className="h-5 w-20" /></TableHead>
                                       <TableHead className="text-right"><Skeleton className="h-5 w-16 ml-auto" /></TableHead>
                                   </TableRow>
                               </TableHeader>
                               <TableBody>
                                   {[...Array(3)].map((_, i) => (
                                       <TableRow key={i}>
                                            <TableCell><Skeleton className="h-8 w-32" /></TableCell>
                                            <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                                            <TableCell><Skeleton className="h-6 w-28" /></TableCell>
                                            <TableCell className="text-right"><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                                       </TableRow>
                                   ))}
                               </TableBody>
                           </Table>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </main>
       </>
     )
  }

  if (!user || user.role !== 'admin') {
    return (
        <>
            <AppHeader />
            <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
                 <div className="container mx-auto text-center py-10">
                    <h1 className="text-2xl font-bold text-destructive">Acceso Denegado</h1>
                    <p className="text-muted-foreground mt-2">
                        No tienes los permisos necesarios para acceder a esta sección.
                    </p>
                </div>
            </main>
        </>
    )
  }


  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Administración Global de Usuarios</CardTitle>
                  <CardDescription>
                    Gestiona los consultores y administradores de la plataforma.
                  </CardDescription>
                </div>
                <Button size="sm" onClick={() => openEditDialog(null)}>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Nuevo Usuario Global
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Rol</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {globalUsers.length > 0 ? globalUsers.map((u) => (
                      <TableRow 
                        key={u.id}
                        className={cn(justUpdatedId === u.id && "row-pulse-animation")}
                      >
                        <TableCell>
                           <div className="flex items-center gap-3">
                                <Avatar className="h-8 w-8">
                                    <AvatarImage src={u.avatarUrl} alt={u.name} data-ai-hint="user avatar" />
                                    <AvatarFallback>{u.name.charAt(0).toUpperCase()}</AvatarFallback>
                                </Avatar>
                                <span className="font-medium">{u.name}</span>
                            </div>
                        </TableCell>
                         <TableCell className="text-muted-foreground">{u.email}</TableCell>
                        <TableCell>
                          <Badge variant={u.role === 'admin' ? 'default' : 'secondary'}>
                            {roleTranslations[u.role]}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" disabled={u.id === user?.id}>
                                    <MoreHorizontal className="h-4 w-4" />
                                     <span className="sr-only">Menú de acciones para {u.name}</span>
                                  </Button>
                                </DropdownMenuTrigger>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Menú de acciones</p>
                              </TooltipContent>
                            </Tooltip>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEditDialog(u)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive" onClick={() => openDeleteDialog(u)}>
                                <Trash2 className="mr-2 h-4 w-4" />
                                Eliminar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )) : (
                        <TableRow>
                            <TableCell colSpan={4} className="h-24 text-center">
                                No se encontraron usuarios globales.
                            </TableCell>
                        </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <UserEditDialog
        isOpen={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSave={handleSave}
        user={editingUser}
        isGlobalAdmin={true}
      />
      
      <DeleteConfirmationDialog
        isOpen={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDelete}
        itemName={itemToDelete?.name || ''}
        itemType="usuario global"
      />
    </>
  );
}
