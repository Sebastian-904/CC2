

"use client";

import * as React from "react";
import { AppHeader } from "@/components/app-header";
import { useApp } from "@/components/app-providers";
import { Skeleton } from "@/components/ui/skeleton";
import type { ComplianceObligation, CalendarEvent } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { ObligationsTable } from "@/components/obligations-table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format, isSameMonth, startOfMonth } from "date-fns";
import { es } from "date-fns/locale";
import { cn } from "@/lib/utils";


const statusStyles: { [key in CalendarEvent['status']]: string } = {
    completed: "bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300 border-green-200 dark:border-green-800",
    pending: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-300 border-yellow-200 dark:border-yellow-800",
    'in-progress': "bg-sky-100 text-sky-800 dark:bg-sky-900/40 dark:text-sky-300 border-sky-200 dark:border-sky-800",
}

export default function ObligationsPage() {
  const { activeCompany, isLoading, updateCompany, events } = useApp();
  const { toast } = useToast();

  const handleSave = async (updatedObligations: ComplianceObligation[]) => {
    if (!activeCompany) return;

    try {
      await updateCompany(activeCompany.id, { obligations: updatedObligations });

      toast({
        title: "Obligaciones Guardadas",
        description: "La lista de obligaciones ha sido guardada con éxito.",
      });

    } catch (error) {
      console.error("Error updating obligations:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo guardar la lista de obligaciones.",
      });
    }
  };

  const monthlyTasks = React.useMemo(() => {
    if (!events) return [];
    const currentMonthStart = startOfMonth(new Date());
    return events.filter(event => isSameMonth(new Date(event.date), currentMonthStart))
                 .sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [events]);

  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto space-y-8">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-10 w-1/3" />
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-64 w-full" />
            </div>
          ) : activeCompany ? (
            <>
              <ObligationsTable
                company={activeCompany}
                onObligationsChange={handleSave}
              />
              <Card>
                <CardHeader>
                  <CardTitle>Tareas Generadas para este Mes</CardTitle>
                  <CardDescription>
                    Esta es una vista previa de las tareas que se han generado automáticamente en el calendario para el mes en curso.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border rounded-lg overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Título de la Tarea</TableHead>
                          <TableHead>Fecha de Vencimiento</TableHead>
                          <TableHead>Asignado</TableHead>
                          <TableHead>Estado</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {monthlyTasks.length > 0 ? monthlyTasks.map(task => (
                          <TableRow key={task.id}>
                            <TableCell className="font-medium">{task.title}</TableCell>
                            <TableCell>{format(new Date(task.date), "dd 'de' MMMM, yyyy", { locale: es })}</TableCell>
                            <TableCell>{task.assignee?.name || 'N/A'}</TableCell>
                            <TableCell>
                              <Badge className={cn("capitalize", statusStyles[task.status])}>
                                {task.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        )) : (
                          <TableRow>
                            <TableCell colSpan={4} className="h-24 text-center">
                              No hay tareas generadas para este mes.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <div className="text-center py-10">
              <h2 className="text-xl font-semibold">Seleccione una empresa</h2>
              <p className="text-muted-foreground mt-2">Por favor, seleccione una empresa para gestionar sus obligaciones.</p>
            </div>
          )}
        </div>
      </main>
    </>
  );
}
