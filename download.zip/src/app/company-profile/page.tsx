

"use client";

import * as React from "react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { CompanyProfileGeneralForm } from "@/components/company-profile-general-form";
import { CompanyProfileProgramsForm } from "@/components/company-profile-programs-form";
import { CompanyProfileMembersForm } from "@/components/company-profile-members-form";
import { CompanyProfileAddressesForm } from "@/components/company-profile-addresses-form";
import { CompanyProfileAgentsForm } from "@/components/company-profile-agents-form";
import { AppHeader } from "@/components/app-header";
import type { Company } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Wand2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AiCompanyDataUpdater } from "@/components/ai-company-data-updater";
import { useApp } from "@/components/app-providers";
import { UpdateCompanyDataFromTextOutput } from "@/ai/flows/update-company-data-from-text";
import { ExcelImportWizard } from "@/components/excel-import-wizard";

export default function CompanyProfilePage() {
  const { toast } = useToast();
  const { activeCompany, isLoading, addObligationToCalendar, addCompany, updateCompany } = useApp();
  const [isAiUpdaterOpen, setIsAiUpdaterOpen] = React.useState(false);
  const [isImportWizardOpen, setIsImportWizardOpen] = React.useState(false);
  const isReadOnly = false; // Placeholder
  const [activeTab, setActiveTab] = React.useState("general");
  
  const handleSaveChanges = async (data: Partial<Company>) => {
    if (!activeCompany) return;

    try {
        await updateCompany(activeCompany.id, data);
        toast({
            title: "Guardado",
            description: "Los cambios se han guardado con éxito.",
        });
    } catch (error) {
        console.error("Error saving company profile:", error);
        toast({
            variant: "destructive",
            title: "Error de Guardado",
            description: "No se pudieron guardar los cambios.",
        });
    }
  };

  const handleAiUpdate = (extractedData: UpdateCompanyDataFromTextOutput) => {
    if (!activeCompany) return;

    const changesToSave: Partial<Company> = {};
    const updateMessages: string[] = [];

    if (extractedData.generalInfo && Object.keys(extractedData.generalInfo).length > 0) {
      changesToSave.generalInfo = { ...activeCompany.generalInfo, ...extractedData.generalInfo };
      updateMessages.push("Información General");
    }
    if (extractedData.incorporationDocument && Object.keys(extractedData.incorporationDocument).length > 0) {
      changesToSave.incorporationDocument = { ...activeCompany.incorporationDocument, ...extractedData.incorporationDocument };
      updateMessages.push("Acta Constitutiva");
    }
    if (extractedData.legalRepresentative && Object.keys(extractedData.legalRepresentative).length > 0) {
      changesToSave.legalRepresentative = { ...activeCompany.legalRepresentative, ...extractedData.legalRepresentative };
       updateMessages.push("Representante Legal");
    }
    
    // We don't handle obligations/events from AI updater anymore in this simplified model.
    // They are managed via the Obligations page.
    handleSaveChanges(changesToSave);
    
    let description = `Se actualizaron los siguientes apartados: ${updateMessages.join(', ')}.`;
    
    toast({
        title: "Perfil Actualizado con IA",
        description,
        duration: 9000,
    });
  };

  const handleImportSuccess = (newCompany: Omit<Company, 'id' | 'users' | 'obligations'>) => {
    addCompany(newCompany);
    toast({
        title: "Importación Exitosa",
        description: `La empresa "${newCompany.generalInfo.legalName}" ha sido creada y seleccionada.`,
    });
    setIsImportWizardOpen(false);
  };


  if (isLoading || !activeCompany) {
    return (
      <>
        <AppHeader />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
            <div className="container mx-auto space-y-8">
                {isLoading ? (
                    <>
                        <Skeleton className="h-12 w-1/3" />
                        <Skeleton className="h-10 w-full" />
                        <Skeleton className="h-96 w-full" />
                    </>
                ) : (
                    <div className="text-center py-10">
                        <h2 className="text-xl font-semibold">Seleccione una empresa</h2>
                        <p className="text-muted-foreground mt-2">Por favor, seleccione o cree una empresa para ver su perfil.</p>
                    </div>
                )}
            </div>
        </main>
      </>
    )
  }

  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto" id="tour-company-profile">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-4">
              <div>
                <h1 className="text-2xl font-semibold">Perfil de Empresa</h1>
                <p className="text-muted-foreground mt-1">
                  Administra toda la información legal y operativa de la empresa en un solo lugar.
                </p>
              </div>
              <div className="flex items-center gap-2">
                    <Button variant="outline" onClick={() => setIsAiUpdaterOpen(true)} id="tour-ai-profile-update">
                        <Wand2 className="mr-2 h-4 w-4" />
                        Actualizar con IA
                    </Button>
                    <Button variant="outline" onClick={() => setIsImportWizardOpen(true)}>
                        <Upload className="mr-2 h-4 w-4" />
                        Importar desde Excel
                    </Button>
              </div>
            </div>

            <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-5 mb-6">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="programs">Programas</TabsTrigger>
                <TabsTrigger value="members">Miembros</TabsTrigger>
                <TabsTrigger value="addresses">Domicilios</TabsTrigger>
                <TabsTrigger value="agents">Agentes Aduanales</TabsTrigger>
              </TabsList>
              
              <TabsContent value="general">
                <CompanyProfileGeneralForm 
                  isReadOnly={isReadOnly} 
                  defaultValues={activeCompany} 
                  onSave={(data) => handleSaveChanges(data)} 
                />
              </TabsContent>

              <TabsContent value="programs">
                <CompanyProfileProgramsForm 
                    isReadOnly={isReadOnly} 
                    defaultValues={activeCompany.programs} 
                    onSave={(data) => handleSaveChanges({ programs: data })}
                />
              </TabsContent>

              <TabsContent value="members">
                <CompanyProfileMembersForm 
                    isReadOnly={isReadOnly} 
                    defaultValues={activeCompany.members} 
                    onSave={(data) => handleSaveChanges({ members: data })}
                />
              </TabsContent>
              
              <TabsContent value="addresses">
                <CompanyProfileAddressesForm 
                    isReadOnly={isReadOnly} 
                    defaultValues={activeCompany.addresses} 
                    onSave={(data) => handleSaveChanges({ addresses: data })}
                />
              </TabsContent>

              <TabsContent value="agents">
                <CompanyProfileAgentsForm 
                    isReadOnly={isReadOnly} 
                    defaultValues={activeCompany.customsAgents} 
                    onSave={(data) => handleSaveChanges({ customsAgents: data })}
                />
              </TabsContent>

            </Tabs>
        </div>
      </main>
       <AiCompanyDataUpdater
        isOpen={isAiUpdaterOpen}
        onOpenChange={setIsAiUpdaterOpen}
        onDataExtract={handleAiUpdate}
      />
       <ExcelImportWizard
        isOpen={isImportWizardOpen}
        onOpenChange={setIsImportWizardOpen}
        onDataProcessed={handleImportSuccess}
        importType="company"
      />
    </>
  );
}
