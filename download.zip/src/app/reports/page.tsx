
"use client";

import * as React from "react";
import { Download, FileText, FileSpreadsheet, Upload, BarChart, ListTodo, CalendarClock, Calendar as CalendarIcon } from "lucide-react";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useApp } from "@/components/app-providers";
import { format, startOfMonth, endOfMonth, isWithinInterval, addDays } from 'date-fns';
import { es } from "date-fns/locale";
import type { User, ComplianceObligation, Company, Priority, CalendarEvent } from "@/lib/types";
import { ReportPreview } from "@/components/report-preview";
import { AppHeader } from "@/components/app-header";
import { ExcelImportWizard } from "@/components/excel-import-wizard";
import { useToast } from "@/hooks/use-toast";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { DateRange } from "react-day-picker";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";


type ReportType = "monthly-summary" | "pending-by-category" | "upcoming-deadlines";

const priorityTranslations: {[key in Priority]: string} = {
    high: 'Alta',
    medium: 'Media',
    low: 'Baja',
}

const statusTranslations: {[key in CalendarEvent['status']]: string} = {
    completed: 'Completado',
    pending: 'Pendiente',
    'in-progress': 'En Progreso',
}

// Helper to draw text with styles
const addText = (doc: jsPDF, text: string, x: number, y: number, size: number, weight: 'normal' | 'bold' = 'normal') => {
  doc.setFontSize(size);
  doc.setFont('helvetica', weight);
  doc.text(text, x, y);
};

export default function ReportsPage() {
  const { user, events, activeCompany, companies, addCompany } = useApp();
  const { toast } = useToast();
  const [isPreviewOpen, setIsPreviewOpen] = React.useState(false);
  const [isImportWizardOpen, setIsImportWizardOpen] = React.useState(false);
  const [reportData, setReportData] = React.useState<Partial<CalendarEvent>[]>([]);
  const [reportTitle, setReportTitle] = React.useState("");
  const [reportType, setReportType] = React.useState<ReportType>("monthly-summary");
  const [dateRange, setDateRange] = React.useState<DateRange | undefined>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  });

  const generatePdf = () => {
    if (!activeCompany) return;

    const doc = new jsPDF();
    const today = new Date();
    const formattedDate = format(today, 'dd/MM/yyyy');
    
    // Header
    if (activeCompany.logoUrl) {
      try {
        doc.addImage(activeCompany.logoUrl, 'PNG', 14, 15, 12, 12);
      } catch (e) {
        console.error("Error adding image to PDF.", e);
      }
    }
    addText(doc, "Reporte de Cumplimiento", 30, 22, 20, 'bold');
    addText(doc, `Empresa: ${activeCompany.generalInfo.legalName}`, 150, 18, 10);
    addText(doc, `Fecha: ${formattedDate}`, 150, 24, 10);

    // Dynamic content based on report type
    switch (reportType) {
        case 'monthly-summary':
            generateMonthlySummary(doc, events);
            break;
        case 'pending-by-category':
            generatePendingByCategoryReport(doc, events);
            break;
        case 'upcoming-deadlines':
            generateUpcomingDeadlinesReport(doc, events, dateRange);
            break;
    }
    
    doc.save(`${reportTitle.replace(/[\s/]/g, '_')}_${format(new Date(), "yyyy-MM-dd")}.pdf`);
    setIsPreviewOpen(false);
  };
  
  const generateMonthlySummary = (doc: jsPDF, allEvents: CalendarEvent[]) => {
      addText(doc, "Resumen de Actividad Mensual", 14, 40, 16, 'bold');

      const monthStart = startOfMonth(new Date());
      const monthEnd = endOfMonth(new Date());
      const monthlyEvents = allEvents.filter(e => isWithinInterval(new Date(e.date), { start: monthStart, end: monthEnd }));

      const total = monthlyEvents.length;
      const completed = monthlyEvents.filter(e => e.status === 'completed').length;
      const pending = monthlyEvents.filter(e => e.status === 'pending').length;
      const inProgress = total - completed - pending;
      const complianceIndex = total > 0 ? ((completed / total) * 100).toFixed(0) : "100";

      // KPIs
      doc.setFillColor(244, 244, 245); // zinc-200
      doc.rect(14, 50, 45, 20, 'F');
      addText(doc, `${total}`, 36, 58, 18, 'bold');
      addText(doc, "Tareas Totales", 36, 64, 10);

      doc.rect(63, 50, 45, 20, 'F');
      addText(doc, `${completed}`, 85, 58, 18, 'bold');
      addText(doc, "Completadas", 85, 64, 10);
      
      doc.rect(112, 50, 45, 20, 'F');
      addText(doc, `${pending}`, 134, 58, 18, 'bold');
      addText(doc, "Pendientes", 134, 64, 10);
      
      doc.setFillColor(22, 163, 74); // primary
      doc.rect(161, 50, 35, 20, 'F');
      doc.setTextColor(255, 255, 255);
      addText(doc, `${complianceIndex}%`, 178, 58, 16, 'bold');
      addText(doc, "Cumplimiento", 178, 64, 9);
      doc.setTextColor(0, 0, 0);

      autoTable(doc, {
          head: [["Fecha", "Título", "Categoría", "Prioridad", "Asignado", "Estado"]],
          body: monthlyEvents.map(event => [
              format(new Date(event.date), 'dd/MM/yyyy'),
              event.title,
              event.category,
              priorityTranslations[event.priority],
              event.assignee?.name,
              statusTranslations[event.status],
          ]),
          startY: 80,
          theme: 'striped',
          headStyles: { fillColor: [22, 163, 74] },
      });
  }

  const generatePendingByCategoryReport = (doc: jsPDF, allEvents: CalendarEvent[]) => {
      addText(doc, "Reporte de Tareas Pendientes por Categoría", 14, 40, 16, 'bold');

      const pendingEvents = allEvents.filter(e => e.status === 'pending');
      const categories = [...new Set(pendingEvents.map(e => e.category))];
      let startY = 50;

      categories.forEach(category => {
          const categoryEvents = pendingEvents.filter(e => e.category === category);
          if (startY > 250) {
              doc.addPage();
              startY = 20;
          }
          addText(doc, `Categoría: ${category}`, 14, startY, 12, 'bold');
          autoTable(doc, {
              head: [["Fecha Límite", "Título", "Prioridad", "Asignado"]],
              body: categoryEvents.map(event => [
                  format(new Date(event.date), 'dd/MM/yyyy'),
                  event.title,
                  priorityTranslations[event.priority],
                  event.assignee?.name,
              ]),
              startY: startY + 5,
              theme: 'striped',
              headStyles: { fillColor: [22, 163, 74] },
          });
          startY = (doc as any).lastAutoTable.finalY + 15;
      });
  }
  
  const generateUpcomingDeadlinesReport = (doc: jsPDF, allEvents: CalendarEvent[], range?: DateRange) => {
      const fromDate = range?.from ? format(range.from, 'dd/MM/yyyy') : '';
      const toDate = range?.to ? format(range.to, 'dd/MM/yyyy') : '';
      const title = `Vencimientos del ${fromDate} al ${toDate}`;
      addText(doc, title, 14, 40, 16, 'bold');
      
      const upcomingEvents = allEvents.filter(event => {
          const eventDate = new Date(event.date);
          return event.status !== 'completed' && isWithinInterval(eventDate, { start: range?.from || new Date(), end: range?.to || new Date()});
      }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
       autoTable(doc, {
          head: [["Fecha", "Título", "Categoría", "Prioridad", "Asignado"]],
          body: upcomingEvents.map(event => [
              format(new Date(event.date), 'dd/MM/yyyy'),
              event.title,
              event.category,
              priorityTranslations[event.priority],
              event.assignee?.name,
          ]),
          startY: 50,
          theme: 'striped',
          headStyles: { fillColor: [22, 163, 74] },
      });
  }


  const handlePreviewReport = (type: ReportType, range?: DateRange) => {
    let title = "";
    let dataToPreview: Partial<CalendarEvent>[] = [];
    const today = new Date();
    const monthStart = startOfMonth(today);
    const monthEnd = endOfMonth(today);

    switch (type) {
        case 'monthly-summary':
            title = 'Resumen de Actividad Mensual';
            dataToPreview = events.filter(e => isWithinInterval(new Date(e.date), { start: monthStart, end: monthEnd }));
            break;
        case 'pending-by-category':
            title = 'Tareas Pendientes por Categoría';
            dataToPreview = events.filter(e => e.status === 'pending');
            break;
        case 'upcoming-deadlines':
            const fromDate = range?.from ? format(range.from, 'dd/MM/yyyy') : '';
            const toDate = range?.to ? format(range.to, 'dd/MM/yyyy') : '';
            title = `Reporte de Vencimientos: ${fromDate} - ${toDate}`;
            dataToPreview = events.filter(event => {
              const eventDate = new Date(event.date);
              return event.status !== 'completed' && range?.from && range?.to && isWithinInterval(eventDate, { start: range.from, end: range.to });
            }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
            break;
    }

    setReportType(type);
    setReportTitle(title);
    setReportData(dataToPreview);
    setIsPreviewOpen(true);
  };

  const handleDownloadTemplate = () => {
    const columnHeaders = [
      // General
      "Razón Social", "RFC", "Actividad Económica", "Domicilio Fiscal", "Teléfono",
      "Acta Constitutiva - No. Escritura", "Acta Constitutiva - Fecha", "Acta Constitutiva - Fedatario",
      "Representante Legal - No. Escritura Poder", "Representante Legal - Fecha Poder", "Representante Legal - Fedatario",
      // Programas
      "IMMEX - No. Registro", "IMMEX - Modalidad", "IMMEX - Fecha Autorización",
      "PROSEC - No. Registro", "PROSEC - Sector", "PROSEC - Fecha Autorización",
      "CERTIVA - Folio", "CERTIVA - Rubro", "CERTIVA - Resolución", "CERTIVA - Fecha Renovación",
      "Padrón Importadores - Folio", "Padrón Importadores - Fecha", "Padrón Importadores - Sector",
      // Miembros (Ejemplo para un miembro, se pueden añadir más columnas como Miembro 2 - Nombre, etc.)
      "Miembro 1 - Nombre", "Miembro 1 - RFC", "Miembro 1 - Tipo Persona (Física/Moral)", "Miembro 1 - Carácter", "Miembro 1 - Nacionalidad", "Miembro 1 - Tributa en México (Sí/No)",
      // Domicilios (Ejemplo para un domicilio)
      "Domicilio 1 - Calle y Número", "Domicilio 1 - Código Postal", "Domicilio 1 - Colonia", "Domicilio 1 - Municipio", "Domicilio 1 - Ciudad", "Domicilio 1 - Estado", "Domicilio 1 - Teléfono", "Domicilio 1 - Programa Vinculado (IMMEX/PROSEC/Ninguno)",
      // Agentes Aduanales (Ejemplo para un agente)
      "Agente Aduanal 1 - Nombre", "Agente Aduanal 1 - Patente", "Agente Aduanal 1 - Estado Encargo (Aceptado/Pendiente)",
      // Obligaciones (Ejemplo para una obligación)
      "Obligación 1 - Nombre", "Obligación 1 - Programa Relacionado", "Obligación 1 - Fecha Presentación", "Obligación 1 - Estado (Cumple/No Cumple)", "Obligación 1 - Frecuencia (Mensual/Anual/Etc)",
      // Tareas/Eventos (Ejemplo para una tarea)
      "Tarea 1 - Título", "Tarea 1 - Descripción", "Tarea 1 - Fecha", "Tarea 1 - Hora Inicio", "Tarea 1 - Hora Fin", "Tarea 1 - Prioridad (Alta/Media/Baja)", "Tarea 1 - Categoría",
      // Usuarios (Ejemplo para un usuario)
      "Usuario 1 - Nombre", "Usuario 1 - Email", "Usuario 1 - Rol (cliente_admin/cliente_miembro)"
    ];
    
    const ws = XLSX.utils.aoa_to_sheet([columnHeaders]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Plantilla Empresas");
    
    XLSX.writeFile(wb, "Plantilla_Importacion_Empresas.xlsx");
  };

  const handleDownloadLogins = () => {
    const allUsers = companies.flatMap(company => 
      (company.users || []).map(user => ({
        empresa: company.generalInfo.legalName,
        nombre: user.name,
        email: user.email,
        rol: user.role,
      }))
    );

    const ws = XLSX.utils.json_to_sheet(allUsers);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Accesos de Usuarios");
    XLSX.writeFile(wb, "Reporte_Total_Accesos.xlsx");
  };

  const handleImportSuccess = (newCompany: Omit<Company, 'id' | 'users' | 'obligations'>) => {
    addCompany(newCompany);
    toast({
        title: "¡Importación completada con éxito!",
        description: `La empresa "${newCompany.generalInfo.legalName}" ha sido creada y seleccionada.`,
        duration: 6000,
    });
    setIsImportWizardOpen(false);
  };


  return (
    <>
      <AppHeader onAiCreateClick={() => {}} onHelpClick={() => {}}/>
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          <div className="container mx-auto">
              <h1 className="text-xl font-semibold mb-2">Central de Reportes</h1>
              <p className="text-muted-foreground mb-6">
                  Genera reportes detallados y exporta datos clave de la plataforma.
              </p>

              <div className="grid gap-8">
                  <Card>
                      <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                              <FileText className="text-primary" />
                              Reportes de Cumplimiento en PDF
                          </CardTitle>
                          <CardDescription>
                              Elige un reporte para obtener una vista detallada y profesional de la actividad de cumplimiento, incluyendo el logotipo de la empresa.
                          </CardDescription>
                      </CardHeader>
                      <CardContent className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        <Button variant="outline" onClick={() => handlePreviewReport('monthly-summary')} disabled={!activeCompany}>
                              <BarChart className="mr-2 h-4 w-4" />
                              Resumen de Actividad Mensual
                        </Button>
                        <Button variant="outline" onClick={() => handlePreviewReport('pending-by-category')} disabled={!activeCompany}>
                              <ListTodo className="mr-2 h-4 w-4" />
                              Pendientes por Categoría
                        </Button>
                         <Popover>
                            <PopoverTrigger asChild>
                               <Button variant="outline" disabled={!activeCompany}>
                                    <CalendarClock className="mr-2 h-4 w-4" />
                                    Vencimientos por Rango
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-4" align="start">
                                <Label>Selecciona un rango de fechas</Label>
                                <Calendar
                                    initialFocus
                                    mode="range"
                                    defaultMonth={dateRange?.from}
                                    selected={dateRange}
                                    onSelect={setDateRange}
                                    numberOfMonths={2}
                                />
                                <Button 
                                    onClick={() => handlePreviewReport('upcoming-deadlines', dateRange)}
                                    disabled={!dateRange?.from || !dateRange?.to}
                                    className="w-full mt-2"
                                >
                                    Generar Reporte de Vencimientos
                                </Button>
                            </PopoverContent>
                        </Popover>
                      </CardContent>
                  </Card>

                  <Card>
                      <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                              <FileSpreadsheet className="text-green-600" />
                              Importación y Exportación Masiva
                          </CardTitle>
                          <CardDescription>
                              Utiliza plantillas de Excel para cargar o descargar datos de la plataforma de forma masiva.
                          </CardDescription>
                      </CardHeader>
                      <CardContent className="flex flex-wrap gap-4">
                        <Button variant="outline" onClick={handleDownloadTemplate}>
                              <Download className="mr-2 h-4 w-4" />
                              Descargar Plantilla de Empresas
                        </Button>
                        <Button variant="outline" onClick={() => setIsImportWizardOpen(true)}>
                            <Upload className="mr-2 h-4 w-4" />
                            Importar desde Excel
                        </Button>
                      </CardContent>
                  </Card>

                  {(user?.role === 'admin' || user?.role === 'consultor') && (
                    <Card className="border-primary/50">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                                <FileText className="text-primary" />
                                Acciones de Administrador
                            </CardTitle>
                            <CardDescription>
                                Exporta datos maestros y de configuración. Estas acciones son exclusivas para roles de Consultor o Admin.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Button onClick={handleDownloadLogins} disabled={companies.length === 0}>
                                <Download className="mr-2 h-4 w-4" />
                                Descargar Todos los Accesos (CSV)
                          </Button>
                        </CardContent>
                    </Card>
                  )}
              </div>
          </div>
      </main>
      <ReportPreview
        isOpen={isPreviewOpen}
        onOpenChange={setIsPreviewOpen}
        reportTitle={reportTitle}
        reportData={reportData}
        onConfirmDownload={generatePdf}
        reportType={reportType}
      />
      <ExcelImportWizard 
        isOpen={isImportWizardOpen}
        onOpenChange={setIsImportWizardOpen}
        onDataProcessed={handleImportSuccess}
        importType="company"
      />
    </>
  );
}

    