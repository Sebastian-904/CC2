
"use client";

import * as React from "react";
import { AppHeader } from "@/components/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MoreHorizontal, Pencil, PlusCircle, Trash2, Palette } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useApp } from "@/components/app-providers";
import { Skeleton } from "@/components/ui/skeleton";
import type { TaskCategory, TaskTemplate } from "@/lib/types";
import { CategoryEditDialog } from "@/components/template/category-edit-dialog";
import { TemplateEditDialog } from "@/components/template/template-edit-dialog";
import { DeleteConfirmationDialog } from "@/components/template/delete-confirmation-dialog";
import { useToast } from "@/hooks/use-toast";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export default function TemplatesPage() {
    const { 
        taskCategories, 
        taskTemplates, 
        isLoading,
        handleCategoryAdd,
        handleCategoryUpdate,
        handleCategoryDelete,
        handleTemplateAdd,
        handleTemplateUpdate,
        handleTemplateDelete,
    } = useApp();
    const { toast } = useToast();

    const [isCategoryDialogOpen, setIsCategoryDialogOpen] = React.useState(false);
    const [editingCategory, setEditingCategory] = React.useState<TaskCategory | null>(null);

    const [isTemplateDialogOpen, setIsTemplateDialogOpen] = React.useState(false);
    const [editingTemplate, setEditingTemplate] = React.useState<TaskTemplate | null>(null);
    
    const [itemToDelete, setItemToDelete] = React.useState<{id: string, name: string, type: 'category' | 'template'} | null>(null);


    const onCategorySave = async (data: Omit<TaskCategory, 'id'>) => {
        try {
            if (editingCategory) {
                await handleCategoryUpdate({ ...data, id: editingCategory.id });
            } else {
                await handleCategoryAdd(data);
            }
        } catch (error) {
            toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar la categoría.' });
        }
    };
    
    const onTemplateSave = async (data: Omit<TaskTemplate, 'id'>) => {
        try {
            if (editingTemplate) {
                await handleTemplateUpdate({ ...data, id: editingTemplate.id });
            } else {
                await handleTemplateAdd(data);
            }
        } catch (error) {
             toast({ variant: 'destructive', title: 'Error', description: 'No se pudo guardar la plantilla.' });
        }
    };
    
    const handleDelete = () => {
        if (!itemToDelete) return;
        try {
            if (itemToDelete.type === 'category') {
                handleCategoryDelete(itemToDelete.id);
            } else {
                handleTemplateDelete(itemToDelete.id);
            }
        } catch (error) {
             toast({ variant: 'destructive', title: 'Error', description: 'No se pudo eliminar el elemento.' });
        } finally {
            setItemToDelete(null);
        }
    };

    if (isLoading) {
        return (
            <>
                <AppHeader />
                <main className="flex-1 p-4 md:p-6 lg:p-8">
                    <div className="container mx-auto space-y-6">
                        <Skeleton className="h-8 w-1/3" />
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <Skeleton className="h-64" />
                            <Skeleton className="h-64" />
                        </div>
                    </div>
                </main>
            </>
        )
    }

  return (
    <>
      <AppHeader />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="container mx-auto">
          <h1 className="text-2xl font-semibold mb-6">Gestión de Plantillas y Categorías</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Categories Section */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle>Gestionar Categorías</CardTitle>
                        <CardDescription>Crea y edita las categorías para clasificar tareas.</CardDescription>
                    </div>
                    <Button size="sm" onClick={() => { setEditingCategory(null); setIsCategoryDialogOpen(true); }}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Nueva Categoría
                    </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Nombre</TableHead>
                                <TableHead>Color</TableHead>
                                <TableHead className="text-right">Acciones</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {taskCategories.map(cat => (
                                <TableRow key={cat.id}>
                                    <TableCell className="font-medium">{cat.name}</TableCell>
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            <div className="h-4 w-4 rounded-full border" style={{ backgroundColor: cat.color }} />
                                            <span className="font-mono text-xs">{cat.color}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <Tooltip>
                                                <TooltipTrigger asChild>
                                                    <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                                                </TooltipTrigger>
                                                <TooltipContent><p>Menú de acciones</p></TooltipContent>
                                            </Tooltip>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => { setEditingCategory(cat); setIsCategoryDialogOpen(true); }}><Pencil className="mr-2 h-4 w-4" />Editar</DropdownMenuItem>
                                                <DropdownMenuItem className="text-destructive" onClick={() => setItemToDelete({id: cat.id, name: cat.name, type: 'category'})}><Trash2 className="mr-2 h-4 w-4" />Eliminar</DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
              </CardContent>
            </Card>

            {/* Templates Section */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle>Gestionar Plantillas de Tareas</CardTitle>
                        <CardDescription>Crea atajos para tareas comunes y recurrentes.</CardDescription>
                    </div>
                     <Button size="sm" onClick={() => { setEditingTemplate(null); setIsTemplateDialogOpen(true); }}>
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Nueva Plantilla
                    </Button>
                </div>
              </CardHeader>
              <CardContent>
                 <div className="border rounded-lg">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Nombre de Plantilla</TableHead>
                                <TableHead>Categoría Asignada</TableHead>
                                <TableHead className="text-right">Acciones</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {taskTemplates.map(tpl => (
                                <TableRow key={tpl.id}>
                                    <TableCell className="font-medium">{tpl.name}</TableCell>
                                    <TableCell>
                                        <Badge variant="outline">{taskCategories.find(c => c.id === tpl.categoryId)?.name || 'Sin categoría'}</Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <DropdownMenu>
                                            <Tooltip>
                                                <TooltipTrigger asChild>
                                                    <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                                                </TooltipTrigger>
                                                <TooltipContent><p>Menú de acciones</p></TooltipContent>
                                            </Tooltip>
                                            <DropdownMenuContent align="end">
                                                <DropdownMenuItem onClick={() => { setEditingTemplate(tpl); setIsTemplateDialogOpen(true); }}><Pencil className="mr-2 h-4 w-4" />Editar</DropdownMenuItem>
                                                <DropdownMenuItem className="text-destructive" onClick={() => setItemToDelete({id: tpl.id, name: tpl.name, type: 'template'})}><Trash2 className="mr-2 h-4 w-4" />Eliminar</DropdownMenuItem>
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <CategoryEditDialog
        isOpen={isCategoryDialogOpen}
        onOpenChange={setIsCategoryDialogOpen}
        onSave={onCategorySave}
        category={editingCategory}
      />
      <TemplateEditDialog
        isOpen={isTemplateDialogOpen}
        onOpenChange={setIsTemplateDialogOpen}
        onSave={onTemplateSave}
        template={editingTemplate}
        categories={taskCategories}
      />
      <DeleteConfirmationDialog
        isOpen={!!itemToDelete}
        onOpenChange={(open) => !open && setItemToDelete(null)}
        onConfirm={handleDelete}
        itemName={itemToDelete?.name || ''}
        itemType={itemToDelete?.type === 'category' ? 'categoría' : 'plantilla'}
      />

    </>
  );
}
