
"use client";

import * as React from "react";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ShieldCheck, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getCompanies, getGlobalUsers } from "@/lib/firestore";
import type { User } from "@/lib/types";

export default function LoginPage() {
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [loginAs, setLoginAs] = React.useState<string | null>(null);
  const [allUsers, setAllUsers] = React.useState<User[]>([]);

  React.useEffect(() => {
    const fetchUsers = async () => {
        try {
            const [globalUsers, companies] = await Promise.all([getGlobalUsers(), getCompanies()]);
            const clientUsers = companies.flatMap(c => c.users || []);
            setAllUsers([...globalUsers, ...clientUsers]);
        } catch (error) {
            toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar los usuarios de demostración."})
        }
    }
    fetchUsers();
  }, [toast]);


  const handleLogin = async (email: string) => {
    setLoginAs(email);
    setIsLoading(true);
    const loginSuccess = await login(email);
    if (!loginSuccess) {
      setIsLoading(false);
      setLoginAs(null);
    }
  };
  
  const adminUser = allUsers.find(u => u.role === 'admin');
  const clientUser = allUsers.find(u => u.role === 'cliente_admin');

  return (
    <main className="flex items-center justify-center min-h-screen bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <div className="flex justify-center items-center mb-2">
            <ShieldCheck className="h-10 w-10 text-primary" />
          </div>
          <CardTitle className="text-2xl">CompliancePro</CardTitle>
          <CardDescription>
            Selecciona un perfil para iniciar sesión.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            {adminUser && (
                <Button 
                    onClick={() => handleLogin(adminUser.email)} 
                    className="w-full" 
                    variant="default"
                    disabled={isLoading}
                >
                    {isLoading && loginAs === adminUser.email ? <Loader2 className="h-5 w-5 animate-spin"/> : `Entrar como Administrador`}
                </Button>
            )}
             {clientUser && (
                <Button 
                    onClick={() => handleLogin(clientUser.email)} 
                    className="w-full" 
                    variant="secondary"
                    disabled={isLoading}
                >
                    {isLoading && loginAs === clientUser.email ? <Loader2 className="h-5 w-5 animate-spin"/> : `Entrar como Cliente`}
                </Button>
            )}
          <div className="mt-6 text-center text-sm">
            <p className="text-muted-foreground">Perfiles de demostración disponibles:</p>
            {adminUser && <p><span className="font-semibold">Admin:</span> {adminUser.email}</p>}
            {clientUser && <p><span className="font-semibold">Cliente:</span> {clientUser.email}</p>}
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
