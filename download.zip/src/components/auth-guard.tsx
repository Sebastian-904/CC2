
"use client";

import * as React from "react";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/contexts/auth-context";

export function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  React.useEffect(() => {
    if (!loading && !user && pathname !== '/login') {
      router.push('/login');
    }
  }, [user, loading, pathname, router]);

  if (loading) {
     return (
        <div className="flex items-center justify-center h-screen">
            <div className="text-xl font-semibold">Cargando...</div>
        </div>
    );
  }

  // Allow access to login page even if there is no user
  if (!user && pathname === '/login') {
      return <>{children}</>;
  }

  // If there is a user, allow access
  if (user) {
      return <>{children}</>;
  }

  return null;
}
