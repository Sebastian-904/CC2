

"use client";

import * as React from "react";
import { Download, MoreHorizontal, Pencil, PlusCircle, Trash2, Upload, Database, AlertCircle, Loader2 } from "lucide-react";
import jsPDF from "jspdf";
import "jspdf-autotable";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Company, ComplianceObligation, Priority, User } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { ObligationEditDialog } from "./obligation-edit-dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { cn } from "@/lib/utils";
import { ExcelImportWizard } from "./excel-import-wizard";
import { useToast } from "@/hooks/use-toast";
import { useApp } from "./app-providers";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";

// Correctly extend jsPDF with autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

const statusTranslations: { [key in ComplianceObligation['status']]: string } = {
    activa: "Activa",
    inactiva: "Inactiva",
}

const statusStyles: { [key in ComplianceObligation['status']]: string } = {
    activa: "bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300 border-green-200 dark:border-green-800",
    inactiva: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-300 border-yellow-200 dark:border-yellow-800",
}

const frequencyTranslations: { [key in ComplianceObligation['frequency']]: string } = {
    semanal: "Semanal",
    mensual: "Mensual",
    anual: "Anual",
}

const priorityTranslations: {[key in Priority]: string} = {
    high: 'Alta',
    medium: 'Media',
    low: 'Baja',
}

const priorityStyles: {[key in Priority]: string} = {
    high: "bg-high-priority/20 text-high-priority border border-high-priority/30",
    medium: "bg-medium-priority/20 text-medium-priority border border-medium-priority/30",
    low: "bg-low-priority/20 text-low-priority border border-low-priority/30",
}

const dayOfWeekMap: { [key: number]: string } = {
    1: "Lunes", 2: "Martes", 3: "Miércoles", 4: "Jueves", 5: "Viernes", 6: "Sábado", 7: "Domingo"
};

type ObligationsTableProps = {
  company: Company;
  onObligationsChange: (obligations: ComplianceObligation[]) => Promise<void>;
}

export function ObligationsTable({ company, onObligationsChange }: ObligationsTableProps) {
  const [obligations, setObligations] = React.useState(company.obligations || []);
  const [isSaving, setIsSaving] = React.useState(false);
  const [isImportWizardOpen, setIsImportWizardOpen] = React.useState(false);
  const [justUpdatedId, setJustUpdatedId] = React.useState<string | null>(null);

  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [editingObligation, setEditingObligation] = React.useState<ComplianceObligation | null>(null);
  
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = React.useState(false);
  const [deletingObligation, setDeletingObligation] = React.useState<ComplianceObligation | null>(null);

  const { toast } = useToast();
  const { regenerateEvents, user } = useApp();

  React.useEffect(() => {
    setObligations(company.obligations || []);
  }, [company]);

  const handleSaveObligation = (obligationData: Omit<ComplianceObligation, 'id'>, obligationId: string | null) => {
    let updatedObligations: ComplianceObligation[];
    let finalId: string;
    if (obligationId) {
      finalId = obligationId;
      updatedObligations = obligations.map(o => 
        o.id === obligationId ? { ...o, ...obligationData } : o
      );
    } else {
      const newObligation: ComplianceObligation = {
        id: `ob-${Date.now()}-${Math.random()}`,
        ...obligationData,
      };
      finalId = newObligation.id;
      updatedObligations = [...obligations, newObligation];
    }
    setObligations(updatedObligations);
    setJustUpdatedId(finalId);
    setTimeout(() => setJustUpdatedId(null), 1500);
  };
  
  const handleInitiateDelete = (obligation: ComplianceObligation) => {
    setDeletingObligation(obligation);
    setIsDeleteAlertOpen(true);
  };

  const handleConfirmDelete = () => {
    if (deletingObligation) {
      const updatedObligations = obligations.filter(o => o.id !== deletingObligation.id);
      setObligations(updatedObligations);
    }
    setIsDeleteAlertOpen(false);
    setDeletingObligation(null);
  };

  const handleSaveChanges = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
        await onObligationsChange(obligations);
        await regenerateEvents(company.id, obligations, company.users);
        toast({
            title: "¡Éxito!",
            description: "Las obligaciones se guardaron y los eventos del calendario se han actualizado automáticamente.",
        });
    } catch(e) {
        toast({
            title: "Error al Guardar",
            description: "No se pudieron guardar los cambios. Inténtalo de nuevo.",
            variant: "destructive"
        });
        console.error(e);
    } finally {
        setIsSaving(false);
    }
  };
  
  const handleImportSuccess = () => {
    // This should trigger a refetch of the company data in the parent component
    console.log("Import successful, parent should refetch data.");
    setIsImportWizardOpen(false);
  };

  const handleDownloadPdf = () => {
    if (!company) return;

    const doc = new jsPDF();
    const today = new Date().toLocaleDateString('es-MX');

    // Add logo only if it exists
    if (company.logoUrl) {
      try {
        doc.addImage(company.logoUrl, 'PNG', 14, 15, 12, 12);
      } catch (e) {
        console.error("Error adding image to PDF, skipping.", e);
      }
    }

    doc.setFontSize(20);
    doc.text("Reporte de Obligaciones de Cumplimiento", 30, 22);
    doc.setFontSize(10);
    doc.text(`Empresa: ${company.generalInfo.legalName}`, 150, 18);
    doc.text(`Fecha: ${today}`, 150, 24);

    const tableColumn = ["Nombre", "Categoría", "Frecuencia", "Día de Vencimiento", "Estado"];
    const tableRows: any[] = [];

    obligations.forEach(item => {
      const itemData = [
        item.name,
        item.category,
        frequencyTranslations[item.frequency],
        item.dueDay,
        statusTranslations[item.status],
      ];
      tableRows.push(itemData);
    });

    doc.autoTable({
      head: [tableColumn],
      body: tableRows,
      startY: 40,
      theme: 'striped',
      headStyles: { fillColor: [22, 163, 74] }, // Emerald color
    });

    doc.save(`Reporte_Obligaciones_${company.generalInfo.rfc}_${today}.pdf`);
  };


  const hasChanges = JSON.stringify(obligations) !== JSON.stringify(company.obligations || []);

  const formatDueDay = (item: ComplianceObligation) => {
    if(item.frequency === 'semanal' && item.dueDay >= 1 && item.dueDay <= 7) {
        return dayOfWeekMap[item.dueDay];
    }
    return item.dueDay;
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <CardTitle>Obligaciones de Cumplimiento</CardTitle>
              <CardDescription>
                Este es el motor de tu calendario. Define aquí las reglas y la app creará las tareas por ti.
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
                <Button variant="outline" onClick={handleDownloadPdf} disabled={obligations.length === 0}>
                    <Download className="mr-2 h-4 w-4" />
                    Descargar PDF
                </Button>
                <Button variant="outline" onClick={() => setIsImportWizardOpen(true)}>
                    <Upload className="mr-2 h-4 w-4" />
                    Importar
                </Button>
                <Button onClick={() => { setEditingObligation(null); setIsDialogOpen(true); }}>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Añadir Obligación
                </Button>
                <div className="flex justify-end">
                    <Button onClick={handleSaveChanges} disabled={!hasChanges || isSaving}>
                        {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isSaving ? 'Guardando...' : 'Guardar y Regenerar'}
                    </Button>
                </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[40%]">Nombre</TableHead>
                  <TableHead>Categoría</TableHead>
                  <TableHead>Prioridad Def.</TableHead>
                  <TableHead>Asignado</TableHead>
                  <TableHead>Frecuencia</TableHead>
                  <TableHead>Día Venc.</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {obligations.length > 0 ? obligations.map((item) => (
                  <TableRow key={item.id} className={cn(justUpdatedId === item.id && "row-pulse-animation")}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell><Badge variant="secondary">{item.category}</Badge></TableCell>
                    <TableCell>
                        <Badge className={cn("capitalize", item.defaultPriority ? priorityStyles[item.defaultPriority] : 'bg-transparent')}>
                           {item.defaultPriority ? priorityTranslations[item.defaultPriority] : 'N/A'}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{(company.users || []).find(u => u.id === item.assigneeId)?.name || 'N/A'}</TableCell>
                    <TableCell>{frequencyTranslations[item.frequency]}</TableCell>
                    <TableCell>{formatDueDay(item)}</TableCell>
                    <TableCell>
                      <Badge className={cn("capitalize", statusStyles[item.status])}>{statusTranslations[item.status]}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Menú de acciones</span>
                              </Button>
                            </DropdownMenuTrigger>
                          </TooltipTrigger>
                          <TooltipContent><p>Menú de acciones</p></TooltipContent>
                        </Tooltip>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditingObligation(item); setIsDialogOpen(true); }}>
                            <Pencil className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => handleInitiateDelete(item)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )) : (
                   <TableRow>
                      <TableCell colSpan={8} className="h-48 text-center text-muted-foreground">
                        <div className="flex flex-col items-center justify-center gap-2">
                            <Database className="w-10 h-10" />
                            <p className="font-medium">Tu base de automatización está vacía</p>
                            <p className="text-sm">Añade tu primera obligación para empezar a generar tareas automáticamente.</p>
                        </div>
                      </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      <ObligationEditDialog
        isOpen={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSave={handleSaveObligation}
        obligation={editingObligation}
        companyUsers={company.users || []}
      />

      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás absolutamente seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. Esto eliminará permanentemente la obligación
              <span className="font-bold"> {deletingObligation?.name} </span>.
              El cambio no se guardará hasta que presiones "Guardar Cambios".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction asChild>
                <Button variant="destructive" onClick={handleConfirmDelete}>Sí, eliminar</Button>
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

       <ExcelImportWizard
        isOpen={isImportWizardOpen}
        onOpenChange={setIsImportWizardOpen}
        onDataProcessed={handleImportSuccess}
        importType="obligations"
      />
    </>
  );
}
