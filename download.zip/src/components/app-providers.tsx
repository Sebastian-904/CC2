
"use client";

import * as React from "react";
import type { ComplianceObligation, User, Company, Comment, TaskCategory, TaskTemplate, Status, CalendarEvent, Priority } from "@/lib/types";
import { 
    getEvents,
    addEvent as addEventToDb,
    updateEvent as updateEventInDb,
    deleteEvent as deleteEventFromDb,
    addCommentToEvent,
    addAttachmentToEvent,
    getCompanies, 
    updateCompanyProfile,
    getTaskCategories,
    getTaskTemplates,
    addTaskCategory,
    updateTaskCategory,
    deleteTaskCategory,
    addTaskTemplate,
    updateTaskTemplate,
    deleteTaskTemplate,
    getGlobalUsers,
    saveGlobalUsers,
    logUserActivity,
    generateEventsFromObligations,
    findUserCompany
} from "@/lib/firestore";
import { useToast } from "@/hooks/use-toast";
import { CreateEventFromTextOutput } from "@/ai/flows/create-event-from-text";
import { useAuth } from "@/contexts/auth-context";

type AppContextType = {
    user: User | null;
    companies: Company[];
    setCompanies: React.Dispatch<React.SetStateAction<Company[]>>;
    activeCompanyId: string | null;
    activeCompany: Company | null;
    setActiveCompanyId: (id: string | null) => void;
    addCompany: (companyData: Omit<Company, 'id' | 'users' | 'obligations' | 'logoUrl'>) => void;
    updateCompany: (companyId: string, companyData: Partial<Omit<Company, 'id'>>) => Promise<void>;
    events: CalendarEvent[];
    setEvents: React.Dispatch<React.SetStateAction<CalendarEvent[]>>;
    isLoading: boolean;
    addObligationToCalendar: (eventData: CreateEventFromTextOutput) => Promise<void>;
    addEvent: (eventData: Omit<CalendarEvent, 'id' | 'companyId'>) => Promise<void>;
    updateEvent: (eventId: string, eventData: Partial<Omit<CalendarEvent, 'id'>>) => Promise<void>;
    deleteEvent: (eventId: string) => Promise<void>;
    updateEventStatus: (eventId: string, status: Status) => Promise<void>;
    addComment: (eventId: string, commentText: string) => Promise<void>;
    addAttachment: (eventId: string, file: File) => Promise<void>;
    assignableUsers: User[];
    assigneeFilter: string | null;
    setAssigneeFilter: React.Dispatch<React.SetStateAction<string | null>>;
    taskCategories: TaskCategory[];
    taskTemplates: TaskTemplate[];
    handleCategoryUpdate: (category: TaskCategory) => Promise<void>;
    handleCategoryAdd: (category: Omit<TaskCategory, 'id'>) => Promise<void>;
    handleCategoryDelete: (categoryId: string) => Promise<void>;
    handleTemplateUpdate: (template: TaskTemplate) => Promise<void>;
    handleTemplateAdd: (template: Omit<TaskTemplate, 'id'>) => Promise<void>;
    handleTemplateDelete: (templateId: string) => Promise<void>;
    globalUsers: User[];
    updateGlobalUsers: (users: User[]) => Promise<void>;
    logActivity: (action: string, details: string, companyContext?: Company) => Promise<void>;
    regenerateEvents: (companyId: string, obligations: ComplianceObligation[], companyUsers: User[]) => Promise<void>;
};

const AppContext = React.createContext<AppContextType | undefined>(undefined);

export function AppProviders({ children }: { children: React.ReactNode }) {
    const { user: authUser, loading: authLoading } = useAuth();
    const [user, setUser] = React.useState<User | null>(null);
    const [events, setEvents] = React.useState<CalendarEvent[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const [assigneeFilter, setAssigneeFilter] = React.useState<string | null>(null);
    const [companies, setCompanies] = React.useState<Company[]>([]);
    const [activeCompanyId, setActiveCompanyId] = React.useState<string | null>(null);
    const [taskCategories, setTaskCategories] = React.useState<TaskCategory[]>([]);
    const [taskTemplates, setTaskTemplates] = React.useState<TaskTemplate[]>([]);
    const [globalUsers, setGlobalUsers] = React.useState<User[]>([]);
    const { toast } = useToast();

    const activeCompany = React.useMemo(() => {
        return companies.find(c => c.id === activeCompanyId) || null;
    }, [companies, activeCompanyId]);

    const assignableUsers = React.useMemo(() => {
        if (!user) return [];
        // Consultants can assign to any other global user or any client user of the active company
        if (user.role === 'admin' || user.role === 'consultor') {
            const allAssignable = [...globalUsers];
            if (activeCompany?.users) {
                activeCompany.users.forEach(clientUser => {
                    if (!allAssignable.some(u => u.id === clientUser.id)) {
                        allAssignable.push(clientUser);
                    }
                })
            }
             return Array.from(new Map(allAssignable.map(u => [u.id, u])).values());
        }
        // Client users can only assign to other users within their own company
        return activeCompany?.users || [];
    }, [user, activeCompany, globalUsers]);
    
    React.useEffect(() => {
        const fetchInitialData = async () => {
            if (authLoading || !authUser) {
                if (!authLoading) setIsLoading(false);
                return;
            };

            setIsLoading(true);
            try {
                // Step 1: Fetch all data that doesn't depend on the user's role first.
                const [fetchedCategories, fetchedTemplates, fetchedGlobalUsers, allCompanies] = await Promise.all([
                    getTaskCategories(),
                    getTaskTemplates(),
                    getGlobalUsers(),
                    getCompanies(), // Fetch all companies upfront
                ]);

                setGlobalUsers(fetchedGlobalUsers);
                setTaskCategories(fetchedCategories);
                setTaskTemplates(fetchedTemplates);
                setCompanies(allCompanies);

                // Step 2: Determine user role and set context accordingly
                const globalUserMatch = fetchedGlobalUsers.find(u => u.id === authUser.id);
                
                setUser(authUser);

                if (globalUserMatch) {
                    // User is an Admin or Consultant
                    if (allCompanies.length > 0) {
                        const lastCompanyId = localStorage.getItem('lastActiveCompanyId');
                        // Select last used company or default to the first one
                        const companyToSelect = allCompanies.find(c => c.id === lastCompanyId) ? lastCompanyId : allCompanies[0].id;
                        setActiveCompanyId(companyToSelect);
                    }
                } else {
                    // User is likely a Client Admin/Member, find their company from the pre-fetched list
                    const userCompany = allCompanies.find(c => c.users?.some(u => u.id === authUser.id));

                    if (userCompany) {
                        setActiveCompanyId(userCompany.id);
                    } else {
                        toast({ variant: "destructive", title: "Error de Acceso", description: "Tu cuenta no está registrada en ninguna empresa." });
                        setActiveCompanyId(null);
                    }
                }

            } catch (error) {
                console.error("Error fetching initial data:", error);
                toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar los datos iniciales." });
            } finally {
                setIsLoading(false);
            }
        };
        fetchInitialData();
    }, [toast, authUser, authLoading]);

    React.useEffect(() => {
        if (activeCompanyId && user && (user.role === 'admin' || user.role === 'consultor')) {
            localStorage.setItem('lastActiveCompanyId', activeCompanyId);
        }
    }, [activeCompanyId, user]);

    React.useEffect(() => {
        if (!activeCompanyId) {
            setEvents([]);
            return;
        }

        const fetchData = async () => {
            try {
                setIsLoading(true);
                const fetchedEvents = await getEvents(activeCompanyId);
                setEvents(fetchedEvents);
            } catch (error) {
                console.error("Error fetching data for company:", activeCompanyId, error);
                toast({ variant: "destructive", title: "Error de Carga", description: "No se pudieron cargar los datos de la empresa." });
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [activeCompanyId, toast]);
    
    const logActivity = async (action: string, details: string, companyContext?: Company) => {
        if (!user) return;
        await logUserActivity(user, action, details, companyContext || activeCompany || undefined);
    };

    const addEvent = async (eventData: Omit<CalendarEvent, 'id' | 'companyId'>) => {
        if (!activeCompanyId || !user) {
             toast({ variant: "destructive", title: "Error", description: "No hay una empresa activa seleccionada." });
             return;
        }
        try {
            const newEvent = await addEventToDb(activeCompanyId, eventData, user);
            setEvents(prev => [...prev, newEvent]);
            toast({ title: "Tarea Creada", description: `Se ha añadido "${newEvent.title}" al calendario.` });
        } catch (error) {
            console.error("Failed to save event to Firestore:", error);
            toast({ variant: "destructive", title: "Error de guardado", description: "No se pudo guardar la tarea." });
            throw error;
        }
    };
    
    const updateEvent = async (eventId: string, eventData: Partial<Omit<CalendarEvent, 'id'>>) => {
        if (!activeCompanyId || !user) return;
        setEvents(prev => prev.map(e => e.id === eventId ? {...e, ...eventData} as CalendarEvent : e));
        try {
            await updateEventInDb(activeCompanyId, eventId, eventData, user);
            toast({ title: "Tarea Actualizada", description: `Se ha guardado "${eventData.title}".` });
        } catch (error) {
            console.error("Failed to update event:", error);
            const originalEvents = await getEvents(activeCompanyId);
            setEvents(originalEvents);
            toast({ variant: "destructive", title: "Error de guardado", description: "No se pudo actualizar la tarea." });
            throw error;
        }
    };
    
    const deleteEvent = async (eventId: string) => {
        if (!activeCompanyId || !user) return;
        const originalEvents = events;
        setEvents(prev => prev.filter(e => e.id !== eventId));
        try {
            await deleteEventFromDb(activeCompanyId, eventId, user);
            toast({ title: "Tarea Eliminada" });
        } catch (error) {
            setEvents(originalEvents);
            console.error("Failed to delete event:", error);
            toast({ variant: "destructive", title: "Error", description: "No se pudo eliminar la tarea." });
            throw error;
        }
    }


    const addObligationToCalendar = async (eventData: CreateEventFromTextOutput) => {
        if (!activeCompanyId || !user) {
             toast({ variant: "destructive", title: "Error", description: "No hay una empresa activa seleccionada." });
             return;
        }
        const newEventData: Omit<CalendarEvent, 'id' | 'companyId'> = {
          title: eventData.title,
          description: eventData.description,
          date: new Date(eventData.date).toISOString().split('T')[0],
          startTime: eventData.startTime,
          endTime: eventData.endTime,
          location: eventData.location,
          participants: [],
          comments: [],
          attachments: [],
          priority: 'medium',
          status: 'pending',
          category: 'General',
          assignee: user,
        };
        await addEvent(newEventData);
    };
    
    const updateEventStatus = async (eventId: string, status: Status) => {
        if (!activeCompanyId || !user) return;
        setEvents(prev => prev.map(o => o.id === eventId ? {...o, status} : o));
        try {
            await updateEventInDb(activeCompanyId, eventId, { status }, user);
        } catch (error) {
            console.error("Failed to update event status:", error);
            const originalEvents = await getEvents(activeCompanyId);
            setEvents(originalEvents);
            throw error;
        }
    }


    const addCompany = async (companyData: Omit<Company, 'id' | 'users' | 'obligations' | 'logoUrl'>) => {
        if (!user || !companyData.generalInfo.rfc) {
             toast({ variant: "destructive", title: "Error al crear empresa", description: "El RFC no puede estar vacío." });
            return;
        }
        try {
            const companyId = companyData.generalInfo.rfc;
            const newCompany = await updateCompanyProfile(companyId, companyData, user, true);
            setCompanies(prev => [...prev, newCompany]);
            setActiveCompanyId(newCompany.id);
        } catch(error) {
             console.error("Failed to add company:", error);
            toast({ variant: "destructive", title: "Error al crear empresa", description: "No se pudo guardar la nueva empresa." });
        }
    };
    
    const updateCompany = async (companyId: string, companyData: Partial<Omit<Company, 'id'>>) => {
         if (!user) return;
         try {
             await updateCompanyProfile(companyId, companyData, user, false);
             setCompanies(prev => prev.map(c => c.id === companyId ? { ...c, ...companyData } as Company : c));
             if(companyData.obligations) {
                 const newEvents = await getEvents(companyId);
                 setEvents(newEvents);
             }

         } catch(error) {
              console.error("Failed to update company:", error);
              toast({ variant: "destructive", title: "Error al actualizar", description: "No se pudo guardar la empresa." });
         }
    };

    const addComment = async (eventId: string, commentText: string) => {
        if (!user || !activeCompanyId) {
            toast({ variant: "destructive", title: "Error", description: "Debes estar autenticado para comentar." });
            return;
        }
        
        const newComment: Omit<Comment, 'id'> = {
            user,
            text: commentText,
            timestamp: new Date().toISOString(),
        };

        try {
            await addCommentToEvent(activeCompanyId, eventId, newComment, user);
            setEvents(prev => prev.map(o => {
                if (o.id === eventId) {
                    const updatedComments = [...(o.comments || []), { ...newComment, id: `temp-${Date.now()}` }];
                    return { ...o, comments: updatedComments };
                }
                return o;
            }));
        } catch (error) {
            console.error("Failed to add comment:", error);
            toast({ variant: "destructive", title: "Error", description: "No se pudo añadir el comentario." });
        }
    };
    
     const addAttachment = async (eventId: string, file: File) => {
        if (!user || !activeCompanyId) {
            toast({ variant: "destructive", title: "Error", description: "Debes estar autenticado para adjuntar archivos." });
            return;
        }

        try {
            const newAttachment = await addAttachmentToEvent(activeCompanyId, eventId, file, user);
            setEvents(prev => prev.map(o => {
                if (o.id === eventId) {
                    return { ...o, attachments: [...(o.attachments || []), newAttachment] };
                }
                return o;
            }));
        } catch (error) {
            console.error("Failed to add attachment:", error);
            toast({ variant: "destructive", title: "Error", description: "No se pudo adjuntar el archivo." });
            throw error;
        }
    };


    const updateGlobalUsers = async (users: User[]) => {
        if (!user) return;
        try {
            await saveGlobalUsers(users, user);
            setGlobalUsers(users);
        } catch (error) {
            console.error("Error saving global users:", error);
            toast({ variant: "destructive", title: "Error", description: "No se pudieron guardar los usuarios globales." });
        }
    };


    // --- Template & Category Management ---

    const handleCategoryAdd = async (categoryData: Omit<TaskCategory, 'id'>) => {
        if (!user) return;
        const newCategory = await addTaskCategory(categoryData, user);
        setTaskCategories(prev => [...prev, newCategory]);
        toast({ title: "Categoría Añadida", description: `Se ha creado la categoría "${newCategory.name}".` });
    };

    const handleCategoryUpdate = async (categoryData: TaskCategory) => {
        if (!user) return;
        await updateTaskCategory(categoryData.id, categoryData, user);
        setTaskCategories(prev => prev.map(c => c.id === categoryData.id ? categoryData : c));
        toast({ title: "Categoría Actualizada", description: `Se ha guardado "${categoryData.name}".` });
    };

    const handleCategoryDelete = async (categoryId: string) => {
        if (!user) return;
        await deleteTaskCategory(categoryId, user);
        setTaskCategories(prev => prev.filter(c => c.id !== categoryId));
        toast({ title: "Categoría Eliminada" });
    };

    const handleTemplateAdd = async (templateData: Omit<TaskTemplate, 'id'>) => {
        if (!user) return;
        const newTemplate = await addTaskTemplate(templateData, user);
        setTaskTemplates(prev => [...prev, newTemplate]);
        toast({ title: "Plantilla Añadida", description: `Se ha creado la plantilla "${newTemplate.name}".` });
    };

    const handleTemplateUpdate = async (templateData: TaskTemplate) => {
        if (!user) return;
        await updateTaskTemplate(templateData.id, templateData, user);
        setTaskTemplates(prev => prev.map(t => t.id === templateData.id ? templateData : c));
        toast({ title: "Plantilla Actualizada", description: `Se ha guardado "${templateData.name}".` });
    };

    const handleTemplateDelete = async (templateId: string) => {
        if (!user) return;
        await deleteTaskTemplate(templateId, user);
        setTaskTemplates(prev => prev.filter(t => t.id !== templateId));
        toast({ title: "Plantilla Eliminada" });
    };
    
    const regenerateEvents = async (companyId: string, obligations: ComplianceObligation[], companyUsers: User[]) => {
        if(!user) return;
        await generateEventsFromObligations(companyId, obligations, companyUsers, user);
        const newEvents = await getEvents(companyId);
        setEvents(newEvents);
    }

    const contextValue = {
        user,
        companies,
        setCompanies,
        activeCompanyId,
        activeCompany,
        setActiveCompanyId,
        addCompany,
        updateCompany,
        events,
        setEvents,
        isLoading,
        addObligationToCalendar,
        addEvent,
        updateEvent,
        deleteEvent,
        updateEventStatus,
        addComment,
        addAttachment,
        assignableUsers,
        assigneeFilter,
        setAssigneeFilter,
        taskCategories,
        taskTemplates,
        handleCategoryAdd,
        handleCategoryUpdate,
        handleCategoryDelete,
        handleTemplateAdd,
        handleTemplateUpdate,
        handleTemplateDelete,
        globalUsers,
        updateGlobalUsers,
        logActivity,
        regenerateEvents,
    };

    return (
        <AppContext.Provider value={contextValue}>
            {children}
        </AppContext.Provider>
    );
}

export function useApp() {
    const context = React.useContext(AppContext);
    if (context === undefined) {
        throw new Error("useApp must be used within an AppProvider");
    }
    return context;
}
