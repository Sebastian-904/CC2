
"use client";

import * as React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { CalendarEvent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";

type TasksByCategoryChartProps = {
  events: CalendarEvent[];
};

export function TasksByCategoryChart({ events }: TasksByCategoryChartProps) {
  const data = React.useMemo(() => {
    const categoryCounts: { [key: string]: number } = {};
    
    events.forEach((event) => {
      const category = event.category || "Sin Categoría";
      categoryCounts[category] = (categoryCounts[category] || 0) + 1;
    });

    return Object.entries(categoryCounts)
      .map(([name, tasks]) => ({ name, tasks }))
      .sort((a, b) => b.tasks - a.tasks); // Sort descending
  }, [events]);

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Distribución de Tareas por Categoría</CardTitle>
        <CardDescription>Muestra la carga de trabajo en las diferentes áreas de cumplimiento.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={120} tick={{ fontSize: 12 }} />
                <Tooltip
                    cursor={{fill: 'hsl(var(--muted))'}}
                    contentStyle={{
                        backgroundColor: 'hsl(var(--background))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: 'var(--radius)',
                    }}
                 />
                <Bar dataKey="tasks" fill="hsl(var(--primary))" barSize={30} />
                </BarChart>
            </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
