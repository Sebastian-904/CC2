
"use client";

import * as React from "react";
import * as XLSX from "xlsx";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  Upload,
  FileCheck2,
  ListChecks,
  Rocket,
  Loader2,
  FileSpreadsheet,
  AlertTriangle,
  ChevronLeft,
  Map,
  Sheet as SheetIcon,
  PartyPopper,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import {
  mapExcelHeaders,
  MapExcelHeadersOutput,
} from "@/ai/flows/map-excel-headers";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { ScrollArea } from "./ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { Label } from "./ui/label";
import type { Company } from "@/lib/types";

type ExcelImportWizardProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onDataProcessed: (data: any) => void;
  importType: 'company' | 'tasks' | 'obligations';
};

const steps = [
  { id: "upload", title: "Subir Archivo", icon: Upload },
  { id: "selectSheet", title: "Elegir Hoja", icon: SheetIcon },
  { id: "map", title: "Mapear Columnas", icon: Map },
  { id: "validate", title: "Validar Datos", icon: ListChecks },
  { id: "summary", title: "Resumen", icon: Rocket },
];

const TARGET_SCHEMA = {
    company: [
      "legalName", "rfc", "economicActivity", "taxAddress", "phone",
      "deedNumber", "incorporationDate", "incorporationNotary",
      "powerOfAttorneyDeed", "powerOfAttorneyDate", "powerOfAttorneyNotary"
    ],
    tasks: [
      "title", "description", "date", "startTime", "endTime", "location", 
      "participants", "priority", "status", "category", "assignee"
    ],
    obligations: [
        "name", "relatedProgram", "frequency", "dueDay", "status"
    ]
}

const mapFriendlyNameToSchemaKey = (name: string) => {
    const map: {[key: string]: string} = {
        'Razón Social': 'legalName',
        'RFC': 'rfc',
        // ... add more mappings as needed
    };
    return map[name] || name;
}


export function ExcelImportWizard({
  isOpen,
  onOpenChange,
  onDataProcessed,
  importType,
}: ExcelImportWizardProps) {
  const [currentStep, setCurrentStep] = React.useState(0);
  const [file, setFile] = React.useState<File | null>(null);
  const [workbook, setWorkbook] = React.useState<XLSX.WorkBook | null>(null);
  const [sheetNames, setSheetNames] = React.useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = React.useState<string>("");
  const [fileData, setFileData] = React.useState<any[]>([]);
  const [headers, setHeaders] = React.useState<string[]>([]);
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [headerMapping, setHeaderMapping] =
    React.useState<MapExcelHeadersOutput>({});
  const { toast } = useToast();

  const targetSchema = TARGET_SCHEMA[importType];

  const resetWizard = () => {
    setCurrentStep(0);
    setFile(null);
    setWorkbook(null);
    setSheetNames([]);
    setSelectedSheet("");
    setFileData([]);
    setHeaders([]);
    setHeaderMapping({});
    setIsProcessing(false);
  };

  const handleClose = (open: boolean) => {
    if (!open) {
      resetWizard();
    }
    onOpenChange(open);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (
        selectedFile.type !== "application/vnd.ms-excel" &&
        selectedFile.type !==
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ) {
        toast({
          variant: "destructive",
          title: "Archivo no válido",
          description: "Por favor, sube un archivo de Excel (.xls, .xlsx).",
        });
        return;
      }
      setFile(selectedFile);
    }
  };

  const processFile = () => {
    if (!file) return;
    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = e.target?.result;
        const wb = XLSX.read(data, { type: "binary" });
        setWorkbook(wb);
        setSheetNames(wb.SheetNames);

        if (wb.SheetNames.length === 1) {
          // If only one sheet, select it and proceed to mapping
          const sheetName = wb.SheetNames[0];
          setSelectedSheet(sheetName);
          await processSheet(wb, sheetName);
        } else {
          // If multiple sheets, go to sheet selection step
          setCurrentStep(1); 
        }
      } catch (error) {
        console.error("Error processing Excel file:", error);
        toast({
          variant: "destructive",
          title: "Error al procesar",
          description: "No se pudo leer el archivo de Excel. Asegúrate de que no esté corrupto.",
        });
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsBinaryString(file);
  };

  const processSheet = async (wb: XLSX.WorkBook, sheetName: string) => {
      if (!wb || !sheetName) return;
      setIsProcessing(true);
      try {
        const worksheet = wb.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        if (Array.isArray(json) && json.length > 0) {
          const fileHeaders = (json[0] as string[]).filter(h => h); // Filter out empty headers
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          setHeaders(fileHeaders);
          setFileData(jsonData);
          
          const mapping = await mapExcelHeaders({ headers: fileHeaders });
          setHeaderMapping(mapping);
          
          setCurrentStep(2); // Go to mapping step
        } else {
            throw new Error("La hoja de Excel está vacía o tiene un formato incorrecto.");
        }
      } catch (error) {
           console.error("Error processing sheet:", error);
            toast({
            variant: "destructive",
            title: "Error al procesar la hoja",
            description: "No se pudo leer la hoja de Excel seleccionada.",
            });
      } finally {
        setIsProcessing(false);
      }
  }
  
  const handleMappingChange = (schemaField: string, excelHeader: string) => {
    setHeaderMapping(prev => ({...prev, [schemaField]: excelHeader === "none" ? undefined : excelHeader }));
  }

  const handleFinalImport = () => {
    if (importType === 'company') {
        const firstRow = fileData[0];
        if (!firstRow) {
            toast({ variant: "destructive", title: "Error", description: "El archivo de Excel está vacío."});
            return;
        }

        const getVal = (key: keyof MapExcelHeadersOutput) => {
            const header = headerMapping[key];
            return header ? firstRow[header] : "";
        }

        const newCompany: Omit<Company, 'id' | 'users' | 'events' | 'logoUrl'> = {
            generalInfo: {
                legalName: getVal('title') || getVal('legalName') || "Nombre no encontrado",
                rfc: getVal('rfc') || "RFC no encontrado",
                economicActivity: getVal('economicActivity') || "",
                taxAddress: getVal('taxAddress') || "",
                phone: getVal('phone') || ""
            },
            incorporationDocument: {
                deedNumber: getVal('deedNumber') || "",
                date: getVal('incorporationDate') || "",
                notary: getVal('incorporationNotary') || ""
            },
            legalRepresentative: {
                powerOfAttorneyDeed: getVal('powerOfAttorneyDeed') || "",
                date: getVal('powerOfAttorneyDate') || "",
                notary: getVal('powerOfAttorneyNotary') || ""
            },
            programs: {},
            members: [],
            addresses: [],
            customsAgents: [],
            obligations: [],
        };
        onDataProcessed(newCompany);
        toast({
            title: "¡Importación completada con éxito!",
            description: `La empresa "${newCompany.generalInfo.legalName}" ha sido creada y seleccionada.`,
            duration: 6000,
        });
        handleClose(false);
    }
  }


  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Upload
        return (
          <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg h-full">
            <FileSpreadsheet className="h-16 w-16 text-muted-foreground mb-4" />
            <input
              type="file"
              id="excel-upload"
              className="hidden"
              onChange={handleFileChange}
              accept=".xlsx, .xls"
            />
            <Label htmlFor="excel-upload" className="cursor-pointer">
              <Button className="pointer-events-none">
                  Seleccionar Archivo
              </Button>
            </Label>
            {file && <p className="mt-4 text-sm text-muted-foreground">{file.name}</p>}
          </div>
        );
       case 1: // Select Sheet
        return (
          <div className="flex flex-col items-center justify-center p-8 h-full">
            <SheetIcon className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold">Selecciona una hoja</h3>
            <p className="text-muted-foreground mb-4">Tu archivo contiene múltiples hojas. Por favor, elige cuál quieres importar.</p>
            <Select value={selectedSheet} onValueChange={setSelectedSheet}>
              <SelectTrigger className="w-[280px]">
                <SelectValue placeholder="Elige una hoja..." />
              </SelectTrigger>
              <SelectContent>
                {sheetNames.map(name => (
                  <SelectItem key={name} value={name}>{name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      case 2: // Map
        return (
            <div className="space-y-4 h-full flex flex-col">
                <Alert>
                    <Map className="h-4 w-4" />
                    <AlertTitle>Revisa el Mapeo de Columnas</AlertTitle>
                    <AlertDescription>
                        La IA ha sugerido un mapeo entre las columnas de tu archivo y los campos de la aplicación.
                        Por favor, verifica y ajusta las asignaciones si es necesario.
                    </AlertDescription>
                </Alert>
                <ScrollArea className="flex-1 border rounded-md p-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                        {targetSchema.map(field => (
                            <div key={field} className="grid grid-cols-2 items-center gap-4">
                                <Label htmlFor={`map-${field}`} className="capitalize text-right">{field.replace(/([A-Z])/g, ' $1')}</Label>
                                <Select 
                                    value={headerMapping[field as keyof MapExcelHeadersOutput] || "none"}
                                    onValueChange={(value) => handleMappingChange(field, value)}
                                >
                                    <SelectTrigger id={`map-${field}`}>
                                        <SelectValue placeholder="No mapeado" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="none">No mapeado</SelectItem>
                                        {headers.map(header => (
                                            <SelectItem key={header} value={header}>{header}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        ))}
                    </div>
                </ScrollArea>
            </div>
        )
      case 3: // Validate
        const validationResult = {
            validRows: fileData.length,
            invalidRows: 0,
        };
        const previewHeaders = targetSchema.filter(field => headerMapping[field as keyof MapExcelHeadersOutput]);
        
        return (
             <div className="space-y-4 h-full flex flex-col">
                <Alert variant="default" className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                    <FileCheck2 className="h-4 w-4 text-green-600" />
                    <AlertTitle className="text-green-800 dark:text-green-300">Validación Exitosa</AlertTitle>
                    <AlertDescription className="text-green-700 dark:text-green-400">
                        Se encontraron <strong>{validationResult.validRows} filas válidas</strong>. Revisa los datos extraídos a continuación. Solo se importarán las filas válidas.
                    </AlertDescription>
                </Alert>
                <div className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full border rounded-md">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    {previewHeaders.map(h => <TableHead key={h} className="capitalize">{h.replace(/([A-Z])/g, ' $1')}</TableHead>)}
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {fileData.slice(0, 50).map((row, i) => (
                                    <TableRow key={i}>
                                        {previewHeaders.map(field => {
                                        const mappedHeader = headerMapping[field as keyof MapExcelHeadersOutput];
                                        return <TableCell key={field}>{mappedHeader ? row[mappedHeader] : ''}</TableCell>
                                        })}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </ScrollArea>
                </div>
             </div>
        );
      case 4: // Summary
        return (
            <div className="flex flex-col items-center justify-center text-center p-8 h-full">
                <Rocket className="h-16 w-16 text-primary animate-pulse mx-auto mb-4" />
                <h3 className="text-xl font-bold">¡Todo listo para el despegue!</h3>
                <p className="text-muted-foreground mt-2">
                    Se importarán <strong>{fileData.length} nuevos registros</strong> a la plataforma.
                    Esta acción no se puede deshacer.
                </p>
            </div>
        );
      default:
        return null;
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={handleClose}>
      <SheetContent side="left" className="sm:max-w-2xl w-full flex flex-col">
        <SheetHeader className="flex-shrink-0">
          <SheetTitle>Asistente de Importación desde Excel</SheetTitle>
          <SheetDescription>
            Sigue los pasos para importar nuevas empresas, usuarios y tareas de forma masiva.
          </SheetDescription>
        </SheetHeader>

        <div className="my-4 flex-shrink-0">
            <Progress value={((currentStep + 1) / steps.length) * 100} className="w-full" />
            <div className={`grid grid-cols-${steps.length} mt-2`}>
                {steps.map((step, index) => (
                    <div key={step.id} className="flex flex-col items-center text-center px-1">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${index <= currentStep ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                            <step.icon className="h-4 w-4" />
                        </div>
                        <p className={`text-xs mt-1 font-medium ${index <= currentStep ? 'text-primary' : 'text-muted-foreground'}`}>{step.title}</p>
                    </div>
                ))}
            </div>
        </div>
        
        <div className="flex-1 min-h-0">
            {renderStepContent()}
        </div>

        <SheetFooter className="flex-shrink-0 pt-4 border-t">
          {currentStep > 0 && (
            <Button
              variant="outline"
              onClick={() => {
                if (currentStep === 2 && sheetNames.length > 1) {
                  setCurrentStep(1); // Go back to sheet selection if there are multiple sheets
                } else if (currentStep === 2 && sheetNames.length <= 1) {
                  setCurrentStep(0); // Go back to file upload
                } else {
                  setCurrentStep(currentStep - 1);
                }
              }}
              disabled={isProcessing}
            >
                <ChevronLeft className="mr-2 h-4 w-4"/>
              Anterior
            </Button>
          )}
          {currentStep < steps.length - 1 ? (
            <Button
              onClick={() => {
                if (currentStep === 0) {
                  processFile();
                } else if (currentStep === 1) {
                  if (workbook && selectedSheet) {
                    processSheet(workbook, selectedSheet);
                  }
                }
                else {
                  setCurrentStep(currentStep + 1);
                }
              }}
              disabled={isProcessing || (currentStep === 0 && !file) || (currentStep === 1 && !selectedSheet)}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Procesando...
                </>
              ) : (
                <>
                  Siguiente <ArrowRight className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          ) : (
            <Button onClick={handleFinalImport}>
              <PartyPopper className="mr-2 h-4 w-4" /> Finalizar Importación
            </Button>
          )}
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
