

"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Building, Loader2 } from "lucide-react";
import type { Company } from "@/lib/types";


const formSchema = z.object({
  name: z.string().min(3, {
    message: "La razón social debe tener al menos 3 caracteres.",
  }),
  rfc: z.string().min(12, {
    message: "El RFC debe tener al menos 12 caracteres.",
  }),
  country: z.string().min(1, { message: "Por favor selecciona un país." }),
});

type NewCompanyDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onCompanyCreated: (newCompanyData: Omit<Company, 'id' | 'users' | 'events' | 'logoUrl'>) => void;
};

export function NewCompanyDialog({
  isOpen,
  onOpenChange,
  onCompanyCreated,
}: NewCompanyDialogProps) {
  const [isProcessing, setIsProcessing] = React.useState(false);
  const { toast } = useToast();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      rfc: "",
      country: "MX",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsProcessing(true);
    try {
      const newCompanyData: Omit<Company, 'id' | 'users' | 'events' | 'logoUrl'> = {
          generalInfo: { legalName: values.name, rfc: values.rfc, economicActivity: "", taxAddress: "", phone: "" },
          incorporationDocument: { deedNumber: "", date: "", notary: "" },
          legalRepresentative: { powerOfAttorneyDeed: "", date: "", notary: "" },
          programs: {},
          members: [],
          addresses: [],
          customsAgents: [],
          obligations: [],
      };
      
      onCompanyCreated(newCompanyData);
      
      toast({
        title: "Empresa Creada con Éxito",
        description: `La empresa "${values.name}" ha sido creada.`,
      });
      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error("Falló la creación de la empresa:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo crear la empresa. Por favor, inténtalo de nuevo.",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building className="text-primary" />
            Crear Nueva Empresa
          </DialogTitle>
          <DialogDescription>
            Ingresa los datos básicos para registrar una nueva empresa cliente en la plataforma.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Razón Social</FormLabel>
                  <FormControl>
                    <Input placeholder="Ej. ACME S.A. de C.V." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="rfc"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>RFC</FormLabel>
                  <FormControl>
                    <Input placeholder="Ej. AME880808XXX" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="country"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>País</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                          <SelectTrigger><SelectValue placeholder="Seleccionar país" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                          <SelectItem value="MX">México</SelectItem>
                          <SelectItem value="US">Estados Unidos</SelectItem>
                          <SelectItem value="CA">Canadá</SelectItem>
                          <SelectItem value="OTHER">Otro</SelectItem>
                      </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isProcessing}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={isProcessing}>
                {isProcessing ? (
                  <>
                    <Loader2 className="animate-spin" />
                    Creando...
                  </>
                ) : (
                  "Crear Empresa"
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
