
"use client";

import * as React from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { PlusCircle, CalendarSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { CalendarEvent, Status } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ScrollArea } from "./ui/scroll-area";
import { Checkbox } from "./ui/checkbox";
import { useApp } from "./app-providers";
import { useToast } from "@/hooks/use-toast";

type DailyEventsListProps = {
  selectedDate: Date;
  dailyEvents: CalendarEvent[];
  selectedEvent: CalendarEvent | null;
  onEventSelect: (event: CalendarEvent) => void;
  onAddTask: () => void;
};

export function DailyEventsList({
  selectedDate,
  dailyEvents,
  selectedEvent,
  onEventSelect,
  onAddTask,
}: DailyEventsListProps) {
  const { updateEventStatus } = useApp();
  const { toast } = useToast();

  const handleStatusChange = async (event: CalendarEvent, newStatus: Status) => {
    try {
      await updateEventStatus(event.id, newStatus);
      toast({
        title: newStatus === 'completed' ? "¡Tarea Completada!" : "Tarea marcada como pendiente",
        description: `"${event.title}" ha sido actualizada.`,
      });
    } catch (e) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo actualizar el estado de la tarea.",
      });
    }
  }

  return (
    <Card className="shadow-sm h-full flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>
            Agenda para {format(selectedDate, "d MMM, yyyy", { locale: es })}
          </span>
          <Button variant="ghost" size="sm" onClick={onAddTask}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Añadir
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0 flex-1 min-h-0">
        <ScrollArea className="h-full">
          <div className="space-y-4">
            {dailyEvents.length > 0 ? (
              dailyEvents.map((event) => {
                const isCompleted = event.status === 'completed';
                return (
                 <div key={event.id} className="flex items-start gap-3">
                    <Checkbox
                      id={`complete-${event.id}`}
                      className="mt-4 h-5 w-5"
                      checked={isCompleted}
                      onCheckedChange={(checked) => {
                        handleStatusChange(event, checked ? 'completed' : 'pending');
                      }}
                      aria-label={`Marcar ${event.title} como completada`}
                    />
                    <button
                      onClick={() => onEventSelect(event)}
                      className={cn(
                        "w-full text-left p-4 rounded-lg border transition-all",
                        selectedEvent?.id === event.id
                          ? "bg-secondary border-primary shadow-sm"
                          : "hover:bg-secondary/50",
                        isCompleted && "bg-muted/50 border-transparent"
                      )}
                    >
                      <div className="flex items-start justify-between">
                        <div className={cn("font-semibold", isCompleted && "line-through text-muted-foreground")}>{event.title}</div>
                        <Badge variant="outline" className={cn("capitalize shrink-0", isCompleted && "opacity-60")}>
                          {event.category}
                        </Badge>
                      </div>
                      <p className={cn("text-sm text-muted-foreground mt-1", isCompleted && "line-through")}>
                        {event.startTime} - {event.endTime}
                      </p>
                    </button>
                  </div>
                )
              })
            ) : (
              <div className="text-center text-muted-foreground py-10 h-full flex flex-col items-center justify-center">
                <CalendarSearch className="h-12 w-12 text-muted-foreground/50 mb-4" />
                <p className="font-medium">Sin Obligaciones</p>
                <p className="text-sm">No hay nada programado para este día.</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
