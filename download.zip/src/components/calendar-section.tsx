
"use client";

import * as React from "react";
import { format, isSameDay } from "date-fns";
import { es } from "date-fns/locale";
import {
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { CalendarEvent, TaskCategory } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from "./ui/tooltip";

type CalendarSectionProps = {
  events: CalendarEvent[];
  selectedDate: Date;
  onDateChange: (date: Date) => void;
  taskCategories: TaskCategory[];
  onEventSelect: (event: CalendarEvent) => void;
};

// Custom formatter for weekday names
const formatters = {
  formatWeekdayName: (day: Date) => {
    return format(day, 'EEEEEE', { locale: es });
  }
};

const MAX_EVENTS_VISIBLE = 2;


export function CalendarSection({
  events,
  selectedDate,
  onDateChange,
  taskCategories,
  onEventSelect
}: CalendarSectionProps) {

  const handleMonthChange = (offset: number) => {
    const newDate = new Date(selectedDate);
    newDate.setMonth(newDate.getMonth() + offset);
    onDateChange(newDate);
  };
  
  const categoryColorMap = React.useMemo(() => {
    const map = new Map<string, string>();
    taskCategories.forEach(cat => {
        map.set(cat.name, cat.color);
    });
    return map;
  }, [taskCategories]);


  return (
      <Card className="shadow-sm h-full flex flex-col" id="tour-calendar-view">
        <CardContent className="p-2 flex-1 flex flex-col">
          <TooltipProvider>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(day) => onDateChange(day || new Date())}
              month={selectedDate}
              onMonthChange={(month) => onDateChange(month)}
              locale={es}
              formatters={formatters}
              className="flex-1 flex flex-col"
              classNames={{
                  months: "flex flex-col sm:flex-row space-y-4 sm:space-x-4 sm:space-y-0 flex-1",
                  month: "space-y-4 flex-1 flex flex-col",
                  table: "w-full border-collapse flex-1 flex flex-col",
                  tbody: "flex-1 grid grid-cols-7",
                  head_row: "flex",
                  row: "flex w-full flex-1 grid grid-rows-6",
                  cell: "h-full text-center text-sm p-0 relative [&:has([aria-selected].day-range-end)]:rounded-r-md [&:has([aria-selected].day-outside)]:bg-accent/50 [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20 flex flex-col border border-border/50",
                  day: "h-full p-1 flex flex-col items-start",
                  day_selected: "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground focus:bg-primary focus:text-primary-foreground",
                  day_today: "bg-accent text-accent-foreground rounded-md",
              }}
              components={{
                DayContent: ({ date }) => {
                  const dayEvents = events.filter((event) =>
                    isSameDay(new Date(event.date), date)
                  ).sort((a,b) => (a.startTime || "00:00").localeCompare(b.startTime || "00:00"));

                  return (
                    <Tooltip>
                       <TooltipTrigger asChild>
                          <div className="relative h-full w-full flex flex-col items-start cursor-pointer">
                              <span className="self-end text-xs font-medium">{format(date, "d")}</span>
                              <div className="flex-1 w-full space-y-1 overflow-hidden mt-1">
                                  {dayEvents.slice(0, MAX_EVENTS_VISIBLE).map((event) => {
                                    const color = categoryColorMap.get(event.category) || 'hsl(var(--muted-foreground))';
                                    return (
                                        <div
                                          key={event.id}
                                          onClick={(e) => { e.stopPropagation(); onEventSelect(event); }}
                                          className={cn(
                                              "w-full text-left text-xs px-1.5 py-0.5 rounded-sm truncate transition-colors",
                                              "text-white cursor-pointer"
                                          )}
                                          style={{ backgroundColor: color }}
                                        >
                                          {event.title}
                                        </div>
                                      );
                                  })}
                              </div>
                              {dayEvents.length > MAX_EVENTS_VISIBLE && (
                                <div
                                    onClick={() => onDateChange(date)}
                                    className="text-xs font-medium text-muted-foreground hover:underline mt-auto cursor-pointer"
                                >
                                    +{dayEvents.length - MAX_EVENTS_VISIBLE} más
                                </div>
                              )}
                          </div>
                      </TooltipTrigger>
                      {dayEvents.length > 0 && (
                        <TooltipContent>
                            <div className="flex flex-col gap-1 items-start p-1">
                                {dayEvents.map(e => (
                                    <div key={e.id} className="flex items-center gap-2">
                                        <div className="h-2 w-2 rounded-full" style={{backgroundColor: categoryColorMap.get(e.category) || 'hsl(var(--muted-foreground))' }}/>
                                        <span className="text-xs">{e.title}</span>
                                    </div>
                                ))}
                            </div>
                        </TooltipContent>
                      )}
                    </Tooltip>
                  );
                },
                Caption: ({...props}) => (
                  <div className="flex justify-between items-center px-2 pt-1 mb-4">
                      <h2 className="text-lg font-semibold capitalize">
                        {format(props.displayMonth, 'MMMM yyyy', { locale: es })}
                      </h2>
                      <div className="flex items-center gap-1">
                          <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => handleMonthChange(-1)}>
                              <ChevronsLeft className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => handleMonthChange(1)}>
                              <ChevronsRight className="h-4 w-4" />
                          </Button>
                      </div>
                  </div>
              )
              }}
            />
          </TooltipProvider>
        </CardContent>
      </Card>
  );
}
