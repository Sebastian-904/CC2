
"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import type { User } from "@/lib/types";


const baseUserSchema = {
  name: z.string().min(1, "El nombre es requerido."),
  email: z.string().email("Debe ser un correo electrónico válido."),
};

// We need to define the schemas with the correct role types for validation.
const clientUserSchema = z.object({
  ...baseUserSchema,
  role: z.enum(["cliente_admin", "cliente_miembro"]),
});

const globalUserSchema = z.object({
    ...baseUserSchema,
    role: z.enum(["admin", "consultor"]),
});

type UserEditDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onSave: (data: Omit<User, 'id' | 'avatarUrl'>, userId: string | null) => Promise<void>;
  user: User | null;
  isGlobalAdmin?: boolean;
};

export function UserEditDialog({ isOpen, onOpenChange, onSave, user, isGlobalAdmin = false }: UserEditDialogProps) {
  // Select the correct schema based on the context
  const formSchema = isGlobalAdmin ? globalUserSchema : clientUserSchema;
  const [isSaving, setIsSaving] = React.useState(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
  });

  React.useEffect(() => {
    if (isOpen) {
        setIsSaving(false);
        if (user) {
          form.reset({
              name: user.name,
              email: user.email,
              role: user.role,
          } as z.infer<typeof formSchema>); // Cast to ensure compatibility
        } else {
          form.reset({
              name: "",
              email: "",
              role: isGlobalAdmin ? "consultor" : "cliente_miembro",
          });
        }
    }
  }, [user, form, isOpen, isGlobalAdmin]);

  const handleSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsSaving(true);
    // The `values` object now correctly conforms to one of the schemas.
    // The `onSave` function is expected to handle this data structure.
    await onSave(values, user?.id || null);
    setIsSaving(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{user ? "Editar Usuario" : "Añadir Nuevo Usuario"}</DialogTitle>
          <DialogDescription>
            {user ? "Modifica los detalles del usuario." : "Completa los detalles para el nuevo usuario."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nombre Completo</FormLabel>
                    <FormControl>
                      <Input placeholder="Ej. Juan Pérez" {...field} disabled={isSaving} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="Ej. juan.perez@cliente.com" {...field} disabled={!!user || isSaving}/>
                    </FormControl>
                    {user && <p className="text-xs text-muted-foreground">El email no se puede cambiar al editar.</p>}
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="role"
                render={({ field }) => (
                  <FormItem className="sm:col-span-2">
                    <FormLabel>Rol</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value} disabled={isSaving}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar un rol" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {isGlobalAdmin ? (
                          <>
                              <SelectItem value="admin">Administrador Global</SelectItem>
                              <SelectItem value="consultor">Consultor</SelectItem>
                          </>
                        ) : (
                          <>
                              <SelectItem value="cliente_admin">Admin de Cliente</SelectItem>
                              <SelectItem value="cliente_miembro">Miembro de Cliente</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter className="pt-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving}>Cancelar</Button>
              <Button type="submit" disabled={isSaving}>{isSaving ? "Guardando..." : "Guardar"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
