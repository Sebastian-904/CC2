
"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { updateCompanyDataFromText, type UpdateCompanyDataFromTextOutput } from "@/ai/flows/update-company-data-from-text";
import { Wand2, Loader2 } from "lucide-react";

const formSchema = z.object({
  text: z.string().min(10, {
    message: "Por favor ingresa la información de la empresa.",
  }),
});

type AiCompanyDataUpdaterProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onDataExtract: (result: UpdateCompanyDataFromTextOutput) => void;
};

export function AiCompanyDataUpdater({
  isOpen,
  onOpenChange,
  onDataExtract,
}: AiCompanyDataUpdaterProps) {
  const [isProcessing, setIsProcessing] = React.useState(false);
  const { toast } = useToast();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      text: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsProcessing(true);
    try {
      const result = await updateCompanyDataFromText({ text: values.text });
      
      onDataExtract(result);
      
      toast({
        title: "Datos Extraídos con Éxito",
        description: "El perfil de la empresa y el calendario han sido actualizados. Guarda los cambios para persistirlos.",
      });
      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error("Falló la extracción de datos con IA:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudieron extraer los datos. Por favor, inténtalo de nuevo.",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="text-primary" />
            Actualizar Perfil con IA
          </DialogTitle>
          <DialogDescription>
            Pega un texto con la información de la empresa (ej. de un correo o documento) y la IA extraerá los datos para rellenar los campos del perfil y el calendario.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="text"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Información de la Empresa</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Ej. La razón social es ACME S.A. de C.V., con RFC AME880808XXX y domicilio en Av. Siempre Viva 742..."
                      className="min-h-[150px] resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isProcessing}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={isProcessing}>
                {isProcessing ? (
                  <>
                    <Loader2 className="animate-spin" />
                    Procesando...
                  </>
                ) : (
                  "Extraer y Actualizar Datos"
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
