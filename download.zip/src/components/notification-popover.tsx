
"use client";

import * as React from "react";
import Link from "next/link";
import { addDays, format, isSameDay, startOfDay } from "date-fns";
import { es } from "date-fns/locale";
import { Bell, Calendar as CalendarIcon } from "lucide-react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import type { CalendarEvent } from "@/lib/types";
import { cn } from "@/lib/utils";
import { ScrollArea } from "./ui/scroll-area";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";

const priorityClasses = {
  high: "border-l-high-priority",
  medium: "border-l-medium-priority",
  low: "border-l-low-priority",
};

const EventNotificationItem = ({ event }: { event: CalendarEvent }) => (
    <div className={cn("p-2 rounded-md border-l-4", priorityClasses[event.priority])}>
        <p className="text-sm font-medium truncate">{event.title}</p>
        <p className="text-xs text-muted-foreground">{event.startTime} - {event.endTime}</p>
    </div>
);

const EventNotificationGroup = ({ title, events }: { title: string, events: CalendarEvent[] }) => (
    <>
        <h5 className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
            {title}
        </h5>
        {events.length > 0 ? (
            <div className="space-y-1">
                {events.map(event => <EventNotificationItem key={event.id} event={event} />)}
            </div>
        ) : (
            <div className="text-center text-sm text-muted-foreground py-4 px-2">
                <p>No tienes eventos programados.</p>
            </div>
        )}
    </>
);

export function NotificationPopover({ events }: { events: CalendarEvent[] }) {
  const today = startOfDay(new Date());
  const tomorrow = addDays(today, 1);

  const todaysEvents = React.useMemo(() => {
    return (events || [])
      .filter((event) => isSameDay(new Date(event.date), today))
      .sort((a, b) => (a.startTime || "00:00").localeCompare(b.startTime || "00:00"));
  }, [events, today]);

  const tomorrowsEvents = React.useMemo(() => {
    return (events || [])
      .filter((event) => isSameDay(new Date(event.date), tomorrow))
      .sort((a, b) => (a.startTime || "00:00").localeCompare(b.startTime || "00:00"));
  }, [events, tomorrow]);
  
  const unreadCount = todaysEvents.length;

  return (
    <Popover>
        <Tooltip>
            <TooltipTrigger asChild>
                <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" aria-label="Notificaciones" className="relative">
                    <Bell className="h-4 w-4" />
                    {unreadCount > 0 && (
                        <span className="absolute top-1 right-1 flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                        </span>
                    )}
                    </Button>
                </PopoverTrigger>
            </TooltipTrigger>
            <TooltipContent>
                <p>Notificaciones</p>
            </TooltipContent>
        </Tooltip>
      <PopoverContent className="w-80 p-0">
        <div className="p-4">
            <h4 className="text-sm font-medium leading-none">Notificaciones</h4>
        </div>
        <Separator />
        <ScrollArea className="max-h-80">
            <div className="p-2">
                <EventNotificationGroup 
                    title={`Hoy - ${format(today, "d 'de' MMMM", { locale: es })}`}
                    events={todaysEvents}
                />
                <EventNotificationGroup 
                    title={`Mañana - ${format(tomorrow, "d 'de' MMMM", { locale: es })}`}
                    events={tomorrowsEvents}
                />
            </div>
        </ScrollArea>
        <Separator />
        <div className="p-2">
            <Link href="/dashboard" passHref>
                <Button variant="ghost" size="sm" className="w-full justify-center">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    Ver calendario completo
                </Button>
            </Link>
        </div>
      </PopoverContent>
    </Popover>
  );
}
