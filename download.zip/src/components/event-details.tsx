

"use client";

import * as React from "react";
import type { CalendarEvent } from "@/lib/types";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Clock,
  MapPin,
  Users,
  Paperclip,
  MessageSquare,
  File,
  FileText,
  FileImage,
  Send,
  CalendarDays,
  Upload,
  Loader2,
  Edit,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { useApp } from "./app-providers";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";

const priorityStyles = {
  high: "bg-high-priority text-high-priority-foreground hover:bg-high-priority/90",
  medium: "bg-medium-priority text-medium-priority-foreground hover:bg-medium-priority/90",
  low: "bg-low-priority text-low-priority-foreground hover:bg-low-priority/90",
};

const statusStyles = {
  completed: "bg-completed text-completed-foreground",
  "in-progress": "bg-in-progress text-in-progress-foreground",
  pending: "bg-pending text-pending-foreground",
};

const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    if (extension === 'pdf') return <FileText className="h-5 w-5 flex-shrink-0 text-red-500" />;
    if (['doc', 'docx'].includes(extension || '')) return <File className="h-5 w-5 flex-shrink-0 text-blue-500" />;
    if (['png', 'jpg', 'jpeg', 'gif'].includes(extension || '')) return <FileImage className="h-5 w-5 flex-shrink-0 text-green-500" />;
    return <File className="h-5 w-5 flex-shrink-0" />;
}


const priorityTranslations: {[key in CalendarEvent['priority']]: string} = {
    high: 'Alta',
    medium: 'Media',
    low: 'Baja',
}

const statusTranslations: {[key in CalendarEvent['status']]: string} = {
    completed: 'Completado',
    'in-progress': 'En Progreso',
    pending: 'Pendiente',
}

type EventDetailsProps = {
    event: CalendarEvent | null;
    onEdit: () => void;
}

export function EventDetails({ event, onEdit }: EventDetailsProps) {
  const { user, addComment, addAttachment } = useApp();
  const [comment, setComment] = React.useState("");
  const [isUploading, setIsUploading] = React.useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim() || !event) return;
    await addComment(event.id, comment);
    setComment("");
  };
  
  const handleAttachmentClick = () => {
    fileInputRef.current?.click();
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0 || !event) {
      return;
    }
    const file = e.target.files[0];
    
    setIsUploading(true);
    try {
        await addAttachment(event.id, file);
        toast({
            title: "Archivo Adjuntado",
            description: `"${file.name}" se ha subido y adjuntado a la tarea.`,
        });

    } catch (error) {
         toast({
            variant: "destructive",
            title: "Error de Subida",
            description: `No se pudo subir el archivo. ${error instanceof Error ? error.message : ''}`,
        });
        console.error("Error uploading file:", error);
    } finally {
        setIsUploading(false);
        if(fileInputRef.current) fileInputRef.current.value = "";
    }
  };


  if (!event) {
    return (
      <Card className="h-full flex items-center justify-center shadow-sm">
        <CardContent className="text-center text-muted-foreground p-6">
          <CalendarDays className="mx-auto h-12 w-12 text-muted-foreground/50 mb-4" />
          <p className="font-medium">Selecciona un evento</p>
          <p className="text-sm">Elige un evento de la lista para ver todos sus detalles aquí.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="h-full flex flex-col shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-start gap-4">
            <CardTitle>{event.title}</CardTitle>
            <div className="flex items-center gap-2 flex-shrink-0">
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onEdit}>
                    <Edit className="h-4 w-4"/>
                    <span className="sr-only">Editar Tarea</span>
                </Button>
                <div className="flex gap-2">
                    <Badge className={cn("capitalize", priorityStyles[event.priority])}>
                        {priorityTranslations[event.priority]}
                    </Badge>
                    <Badge className={cn("capitalize", statusStyles[event.status])}>
                        {statusTranslations[event.status]}
                    </Badge>
                </div>
            </div>
        </div>
        <CardDescription>{event.category}</CardDescription>
      </CardHeader>
      <ScrollArea className="flex-1">
      <CardContent className="space-y-6 pt-0">
        <p className="text-sm">{event.description}</p>
        <Separator />
        <div className="space-y-4 text-sm">
          {event.startTime && event.endTime && (
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <span>
                {event.startTime} - {event.endTime}
              </span>
            </div>
          )}
          {event.location && (
            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground" />
              <span>{event.location}</span>
            </div>
          )}
          {event.participants && event.participants.length > 0 && (
            <div className="flex items-start gap-3">
              <Users className="h-5 w-5 text-muted-foreground mt-1" />
              <div className="flex flex-col">
                <span>Participantes</span>
                <div className="flex flex-wrap gap-2 mt-2">
                  {event.participants.map((user) => (
                    <div key={user.id} className="flex items-center gap-2 text-xs p-1 bg-secondary rounded-md">
                      <Avatar className="h-5 w-5">
                        <AvatarImage src={user.avatarUrl} alt={user.name} data-ai-hint="user avatar" />
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span>{user.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          <div className="flex items-start gap-3">
            <Paperclip className="h-5 w-5 text-muted-foreground mt-1" />
            <div className="flex flex-col w-full">
                <div className="flex justify-between items-center">
                    <span>Archivos Adjuntos</span>
                     <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                     <Button variant="ghost" size="sm" onClick={handleAttachmentClick} disabled={isUploading}>
                        {isUploading ? (
                             <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                             <Upload className="h-4 w-4 mr-2" />
                        )}
                        Adjuntar
                    </Button>
                </div>
                <div className="space-y-2 mt-2">
                    {event.attachments?.map(att => (
                        <Link key={att.id} href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs p-2 bg-secondary rounded-md cursor-pointer hover:bg-secondary/80">
                            {getFileIcon(att.name)}
                            <span className="font-medium flex-1 truncate">{att.name}</span>
                        </Link>
                    ))}
                    {isUploading && (
                        <div className="flex items-center gap-2 text-xs p-2 bg-secondary rounded-md">
                           <Loader2 className="h-5 w-5 flex-shrink-0 animate-spin" />
                           <span className="font-medium flex-1 truncate text-muted-foreground">Subiendo archivo...</span>
                        </div>
                    )}
                </div>
            </div>
          </div>
        </div>
        <Separator />
        <div className="space-y-4">
            <h3 className="text-base font-semibold flex items-center gap-3">
                <MessageSquare className="h-5 w-5 text-muted-foreground" />
                Comentarios
            </h3>
            <div className="space-y-4">
                {event.comments?.map(comment => (
                    <div key={comment.id} className="flex items-start gap-3">
                        <Avatar className="h-8 w-8">
                            <AvatarImage src={comment.user.avatarUrl} alt={comment.user.name} data-ai-hint="user avatar" />
                            <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 bg-secondary p-3 rounded-lg">
                            <div className="flex items-baseline justify-between">
                                <p className="font-semibold text-sm">{comment.user.name}</p>
                                <p className="text-xs text-muted-foreground">{new Date(comment.timestamp).toLocaleTimeString()}</p>
                            </div>
                            <p className="text-sm mt-1">{comment.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </CardContent>
      </ScrollArea>
      <CardFooter className="pt-4 border-t">
        <form onSubmit={handleCommentSubmit} className="flex w-full items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={user?.avatarUrl} alt={user?.name} data-ai-hint="user avatar" />
              <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
            </Avatar>
            <Input 
                placeholder="Añadir un comentario..." 
                className="flex-1"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
            />
            <Button type="submit" size="icon">
                <Send className="h-4 w-4" />
            </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
