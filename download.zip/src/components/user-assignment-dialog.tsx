
"use client";

import * as React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { User } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";


const createUserSchema = z.object({
  name: z.string().min(1, "El nombre es requerido."),
  email: z.string().email("Debe ser un correo electrónico válido."),
  role: z.enum(["cliente_admin", "cliente_miembro"]),
});

type CreateUserFormValues = z.infer<typeof createUserSchema>;

type UserAssignmentDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onUserCreated: (newUser: User) => void;
};

export function UserAssignmentDialog({ isOpen, onOpenChange, onUserCreated }: UserAssignmentDialogProps) {
    const form = useForm<CreateUserFormValues>({
        resolver: zodResolver(createUserSchema),
        defaultValues: { name: "", email: "", role: "cliente_miembro" },
    });
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = React.useState(false);

    React.useEffect(() => {
        if (!isOpen) {
            form.reset();
            setIsSubmitting(false);
        }
    }, [isOpen, form]);


    const handleSubmit = async (values: CreateUserFormValues) => {
        setIsSubmitting(true);
        try {
            const newUser: User = {
                id: `client-${Date.now()}`,
                avatarUrl: `https://placehold.co/32x32.png`,
                ...values,
            };
            onUserCreated(newUser);
            form.reset();
            toast({ title: "Usuario Creado", description: `Se ha creado el acceso para ${values.name}.` });
            onOpenChange(false);
        } catch (error: any) {
            console.error("Error creating user:", error);
            toast({ variant: "destructive", title: "Error de Creación", description: "No se pudo crear el usuario." });
        } finally {
            setIsSubmitting(false);
        }
    };
    
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Crear Nuevo Usuario de Cliente</DialogTitle>
                    <DialogDescription>
                        Crea un nuevo usuario que pertenecerá exclusivamente a esta empresa.
                    </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 p-1">
                        <FormField control={form.control} name="name" render={({ field }) => (
                            <FormItem><FormLabel>Nombre Completo</FormLabel><FormControl><Input placeholder="Ej. Juan Pérez" {...field} /></FormControl><FormMessage /></FormItem>
                        )}/>
                        <FormField control={form.control} name="email" render={({ field }) => (
                            <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" placeholder="Ej. juan.perez@cliente.com" {...field} /></FormControl><FormMessage /></FormItem>
                        )}/>
                        <FormField control={form.control} name="role" render={({ field }) => (
                            <FormItem><FormLabel>Rol</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue/></SelectTrigger></FormControl><SelectContent>
                                <SelectItem value="cliente_admin">Admin de Cliente</SelectItem>
                                <SelectItem value="cliente_miembro">Miembro de Cliente</SelectItem>
                            </SelectContent></Select><FormMessage /></FormItem>
                        )}/>
                        <div className="flex justify-end pt-4 gap-2">
                             <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting && <Loader2 className="animate-spin mr-2"/>}
                                {isSubmitting ? "Creando..." : "Crear Usuario"}
                            </Button>
                        </div>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
}
