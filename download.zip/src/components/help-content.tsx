
"use client";

import * as React from "react";

export const helpCategories = [
    { id: "accounts", title: "1. Gestión de Cuentas" },
    { id: "multi-company", title: "2. Gestión Multiempresa" },
    { id: "tasks", title: "3. Tareas y Automatización" },
    { id: "company-profile", title: "4. Perfil de Empresa" },
    { id: "reports", title: "5. Reportes y Análisis" },
    { id: "settings", title: "6. Configuración" },
    { id: "support", title: "7. Ayuda y Soporte" },
    { id: "audit", title: "8. Auditoría y Seguridad" },
];

const HelpSection = ({ id, title, children }: { id: string, title: string, children: React.ReactNode }) => (
    <section id={id} className="mb-12 scroll-mt-20">
        <h2 className="text-2xl font-bold border-b pb-2 mb-4">{title}</h2>
        <div className="prose prose-sm max-w-none text-muted-foreground">
            {children}
        </div>
    </section>
);

const SubSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div className="mb-6">
        <h3 className="text-xl font-semibold mb-2 text-foreground">{title}</h3>
        {children}
    </div>
);

const RoleSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div className="p-4 border rounded-lg mb-4">
        <h4 className="text-lg font-bold mb-2 text-primary">{title}</h4>
        <div className="space-y-2">{children}</div>
    </div>
);

const Feature = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div>
        <p className="font-semibold text-foreground">{title}</p>
        <p>{children}</p>
    </div>
);


export function HelpContent() {
  return (
    <>
      <HelpSection id="accounts" title="Categoría 1: Gestión de Cuentas y Roles">
        <p>Esta sección cubre todo lo relacionado con el acceso, los roles y los permisos de los usuarios dentro de la plataforma.</p>
        
        <RoleSection title="1. Rol: CONSULTOR">
            <p>Este rol es para el equipo de la consultoría. Tiene amplios permisos para gestionar a todos los clientes y su información.</p>
            <Feature title="Gestión Multiempresa:">
                - **Visibilidad Completa:** Puede ver y acceder a la información de todas las empresas clientes registradas.
                - **Creación de Empresas:** Puede dar de alta nuevas empresas, ya sea manualmente o usando el Asistente de Importación desde Excel.
                - **Edición:** Puede editar la información de las empresas, pero no eliminarlas.
            </Feature>
            <Feature title="Gestión de Usuarios de Clientes:">
                - **Control en Empresas Cliente:** Puede ver, agregar, editar y eliminar usuarios dentro de cualquier empresa cliente. No puede modificar la lista de Administradores o Consultores globales.
            </Feature>
            <Feature title="Gestión de Tareas y Perfil de Empresa:">
                - **Acceso Total:** Tiene acceso de lectura y escritura a los calendarios, tareas y perfiles de todas las empresas.
            </Feature>
             <Feature title="Gestión de Plantillas:">
                - **Administrador de Plantillas y Categorías:** Puede crear, editar y eliminar las categorías y plantillas de tareas para toda la plataforma.
            </Feature>
        </RoleSection>
        
        <RoleSection title="2. Rol: Cliente - Admin (cliente_admin)">
            <p>Este rol es para el líder o gerente del lado del cliente. Tiene permisos de administrador, pero únicamente dentro de su propia empresa.</p>
            <Feature title="Gestión de Usuarios (Limitado a su Empresa):">Puede agregar, editar y eliminar usuarios, pero solo dentro de su propia empresa.</Feature>
            <Feature title="Gestión de Tareas y Calendario:">Puede crear, editar, eliminar y actualizar el estado de las tareas de su empresa.</Feature>
            <Feature title="Perfil de Empresa:">Tiene acceso de lectura y escritura al perfil de su empresa.</Feature>
        </RoleSection>

         <RoleSection title="3. Rol: Cliente - Miembro (cliente_miembro)">
            <p>Este es el rol más limitado, diseñado para miembros del equipo que solo necesitan consultar información. Es principalmente un rol de solo lectura.</p>
            <Feature title="Gestión de Tareas y Calendario:">Puede ver todas las tareas, pero no crearlas, editarlas ni eliminarlas. Puede añadir comentarios y ver archivos adjuntos.</Feature>
            <Feature title="Perfil de Empresa:">Acceso de solo lectura al perfil de la empresa.</Feature>
            <Feature title="Reportes:">Puede generar reportes en PDF para su empresa.</Feature>
        </RoleSection>
      </HelpSection>

      <HelpSection id="multi-company" title="Categoría 2: Gestión Multiempresa (Para Consultores)">
        <p>Funcionalidades diseñadas para administrar múltiples clientes desde una única interfaz.</p>
        <SubSection title="Selector de Empresas">
            <p>Un menú desplegable en la barra lateral izquierda permite cambiar de forma instantánea entre las diferentes empresas que gestionas. Al seleccionar una, toda la interfaz (dashboard, perfil, usuarios) se actualiza al contexto de esa empresa.</p>
        </SubSection>
        <SubSection title="Creación de Empresas">
            <Feature title="Creación Manual:">Desde el selector de empresas, la opción "Crear Nueva Empresa" abre un formulario para añadir una compañía rellenando sus datos básicos.</Feature>
            <Feature title="Asistente de Importación desde Excel:">Puedes usar el Asistente de Importación para crear una nueva empresa y rellenar todo su perfil a partir de un único archivo de Excel, automatizando la configuración inicial.</Feature>
        </SubSection>
      </HelpSection>

       <HelpSection id="tasks" title="Categoría 3: Tareas y Automatización Inteligente">
        <p>El corazón de la aplicación es su capacidad para gestionar el cumplimiento de forma automatizada, basándose en la lógica "Obligaciones a Tareas".</p>
        <SubSection title="1. Obligaciones (La Regla Maestra)">
            <Feature title="¿Qué son?">Son las reglas que definen cada responsabilidad de cumplimiento. Se gestionan desde la página "Obligaciones". Cada obligación contiene la información clave para la automatización.</Feature>
            <Feature title="Campos Clave de Automatización:">
                - **Frecuencia:** Define si la obligación es `Mensual` o `Anual`.
                - **Día de Vencimiento:** El día del mes (1-31) o del año (1-366) en que se debe cumplir.
                - **Categoría por Defecto:** La categoría (`Fiscal`, `Legal`, etc.) que heredarán las tareas generadas.
                - **Asignado por Defecto:** El usuario responsable de las tareas que se generen a partir de esta obligación.
            </Feature>
        </SubSection>
         <SubSection title="2. Generación Automática de Tareas (La Magia)">
            <Feature title="¿Cómo funciona?">Al hacer clic en "Guardar y Regenerar Eventos" en la página de Obligaciones, el sistema lee todas las obligaciones `activas` y crea automáticamente las tareas correspondientes en el calendario para los próximos 1-2 años.</Feature>
            <Feature title="Inteligencia Proactiva:">Este sistema elimina la carga manual, previene errores y asegura que el calendario de cumplimiento esté siempre actualizado y correctamente asignado.</Feature>
        </SubSection>
         <SubSection title="3. Tareas Individuales (La Acción Específica)">
            <Feature title="¿Qué son?">Es la tarea final que aparece en el calendario (ej. "Declaración Mensual de IVA - Mayo 2024"). Incluye todos los detalles y es donde el equipo interactúa, añade comentarios y adjunta archivos.</Feature>
             <Feature title="Gestión de Archivos:">En el detalle de cada tarea, puedes adjuntar archivos relevantes (PDFs, imágenes, documentos). Estos se almacenan de forma segura y están disponibles para su descarga, manteniendo toda la evidencia en un solo lugar.</Feature>
        </SubSection>
      </HelpSection>

      <HelpSection id="company-profile" title="Categoría 4: Perfil de Empresa">
        <p>Un repositorio centralizado para toda la información legal y operativa. Se accede a través del enlace "Perfil de Empresa" en la barra lateral.</p>
      </HelpSection>

      <HelpSection id="reports" title="Categoría 5: Reportes y Análisis de Datos">
        <p>Herramientas para visualizar el progreso y compartir información.</p>
        <SubSection title="Funcionalidades">
            <Feature title="Dashboard Unificado:">La página principal combina la vista del calendario con KPIs y gráficos de BI, ofreciendo una visión 360° del estado de cumplimiento.</Feature>
            <Feature title="Generación de Reportes PDF:">Exporta la información a documentos PDF con un formato profesional y el logotipo de la empresa.</Feature>
        </SubSection>
      </HelpSection>

      <HelpSection id="settings" title="Categoría 6: Configuración y Personalización">
        <p>Opciones que permiten a los usuarios y administradores adaptar la aplicación a sus necesidades.</p>
        <SubSection title="Preferencias de Visualización">
             <Feature title="Tema Visual, Idioma y Formato de Hora:">Permite a cada usuario personalizar su experiencia visual.</Feature>
        </SubSection>
        <SubSection title="Gestión de Plantillas y Categorías (Consultor)">
            <p>Un administrador centralizado para crear y gestionar las categorías de tareas, que son la base para la organización y la automatización del calendario.</p>
        </SubSection>
      </HelpSection>

       <HelpSection id="support" title="Categoría 7: Ayuda y Soporte al Usuario">
        <p>Recursos integrados para facilitar el uso de la plataforma.</p>
        <SubSection title="Centro de Ayuda">
            <p>Se accede haciendo clic en el icono de signo de interrogación en el encabezado superior. Abre una ventana con este manual de usuario completo y un buscador.</p>
        </SubSection>
      </HelpSection>

      <HelpSection id="audit" title="Categoría 8: Auditoría y Seguridad">
        <p>Funcionalidades avanzadas para garantizar la seguridad y la trazabilidad en la plataforma.</p>
        <SubSection title="Registro de Auditoría (Exclusivo para Consultores)">
             <Feature title="Trazabilidad Completa:">Se accede desde la barra lateral. Esta sección registra cada acción importante realizada en la plataforma: quién la hizo, qué hizo y cuándo.</Feature>
             <Feature title="Filtrado y Exportación:">Permite filtrar los registros por usuario, empresa y fecha, así como exportar los resultados a un archivo CSV para análisis externos o propósitos de seguridad.</Feature>
        </SubSection>
      </HelpSection>
    </>
  );
}
