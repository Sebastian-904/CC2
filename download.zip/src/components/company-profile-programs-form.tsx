
"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { FormSection } from "./ui/form-section";
import { Button } from "./ui/button";
import type { CompanyPrograms } from "@/lib/types";

const programsSchema = z.object({
  immex: z.object({
      registrationNumber: z.string().optional(),
      modality: z.string().optional(),
      authorizationDate: z.string().optional(),
  }).optional(),
  prosec: z.object({
      registrationNumber: z.string().optional(),
      modality: z.string().optional(),
      authorizationDate: z.string().optional(),
  }).optional(),
  certiva: z.object({
      folio: z.string().optional(),
      category: z.string().optional(),
      resolution: z.string().optional(),
      renewalDate: z.string().optional(),
  }).optional(),
  importersRegistry: z.object({
      folio: z.string().optional(),
      date: z.string().optional(),
      sector: z.string().optional(),
  }).optional(),
});

type ProgramsFormValues = z.infer<typeof programsSchema>;

const getSafeDefaults = (values?: CompanyPrograms): ProgramsFormValues => {
    const emptyState = {
        immex: { registrationNumber: '', modality: '', authorizationDate: '' },
        prosec: { registrationNumber: '', modality: '', authorizationDate: '' },
        certiva: { folio: '', category: '', resolution: '', renewalDate: '' },
        importersRegistry: { folio: '', date: '', sector: '' },
    };

    if (!values) {
        return emptyState;
    }
    
    return {
        immex: values.immex || emptyState.immex,
        prosec: values.prosec || emptyState.prosec,
        certiva: values.certiva || emptyState.certiva,
        importersRegistry: values.importersRegistry || emptyState.importersRegistry,
    };
}

type CompanyProfileProgramsFormProps = {
  isReadOnly: boolean;
  defaultValues?: CompanyPrograms;
  onSave: (data: CompanyPrograms) => Promise<void>;
};

export function CompanyProfileProgramsForm({ isReadOnly, defaultValues, onSave }: CompanyProfileProgramsFormProps) {
  const form = useForm<ProgramsFormValues>({
    resolver: zodResolver(programsSchema),
    defaultValues: getSafeDefaults(defaultValues),
  });

  React.useEffect(() => {
    form.reset(getSafeDefaults(defaultValues));
  }, [defaultValues, form]);

  const onSubmit = async (data: ProgramsFormValues) => {
    await onSave(data as CompanyPrograms);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Programas y Certificaciones</CardTitle>
            <CardDescription>
              Registros y programas especiales de comercio exterior con los que cuenta la empresa.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <FormSection title="Programa IMMEX" description="Información del Programa de la Industria Manufacturera, Maquiladora y de Servicios de Exportación.">
              <fieldset disabled={isReadOnly} className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="immex.registrationNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>No. de Registro</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. IM-1234-2021" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="immex.modality"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Modalidad</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Seleccionar modalidad" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Industrial">Industrial</SelectItem>
                          <SelectItem value="Servicios">Servicios</SelectItem>
                          <SelectItem value="Albergue">Albergue</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="immex.authorizationDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fecha de Autorización</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </fieldset>
            </FormSection>

            <FormSection title="Programa PROSEC" description="Información del Programa de Promoción Sectorial.">
              <fieldset disabled={isReadOnly} className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="prosec.registrationNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>No. de Registro</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. PS-5678-2022" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="prosec.modality"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sector</FormLabel>
                       <FormControl>
                        <Input placeholder="Ej. Electrónico" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="prosec.authorizationDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fecha de Autorización</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </fieldset>
            </FormSection>
            
            <FormSection title="Certificación IVA y IEPS" description="Datos del registro en el Esquema de Certificación de Empresas.">
              <fieldset disabled={isReadOnly} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <FormField
                    control={form.control}
                    name="certiva.folio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Folio</FormLabel>
                        <FormControl><Input placeholder="Ej. IVA-9991" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="certiva.category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rubro (A, AA, AAA)</FormLabel>
                         <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccionar rubro" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="A">A</SelectItem>
                              <SelectItem value="AA">AA</SelectItem>
                              <SelectItem value="AAA">AAA</SelectItem>
                            </SelectContent>
                          </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                   <FormField
                    control={form.control}
                    name="certiva.resolution"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Resolución</FormLabel>
                        <FormControl><Input placeholder="Ej. Favorable" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="certiva.renewalDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Próxima Renovación</FormLabel>
                        <FormControl><Input type="date" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
              </fieldset>
            </FormSection>
            
            <FormSection title="Padrón de Importadores" description="Información sobre el registro en el Padrón de Importadores.">
              <fieldset disabled={isReadOnly} className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="importersRegistry.folio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Folio</FormLabel>
                      <FormControl><Input placeholder="Ej. PI-XYZ-001" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="importersRegistry.date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fecha de Registro</FormLabel>
                      <FormControl><Input type="date" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="importersRegistry.sector"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sector</FormLabel>
                      <FormControl><Input placeholder="Ej. General" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </fieldset>
            </FormSection>
             {!isReadOnly && (
                <div className="flex justify-end">
                    <Button type="submit">Guardar Cambios</Button>
                </div>
            )}
          </CardContent>
        </Card>
      </form>
    </Form>
  );
}
