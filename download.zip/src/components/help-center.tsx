
"use client";

import * as React from "react";
import { Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { HelpContent, helpCategories } from "./help-content";

type HelpCenterProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
};

export function HelpCenter({ isOpen, onOpenChange }: HelpCenterProps) {
  const [activeCategory, setActiveCategory] = React.useState(helpCategories[0].id);
  const contentRef = React.useRef<HTMLDivElement>(null);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, categoryId: string) => {
    e.preventDefault();
    setActiveCategory(categoryId);
    const section = document.getElementById(categoryId);
    if (section && contentRef.current) {
      contentRef.current.scrollTo({
        top: section.offsetTop - 20,
        behavior: 'smooth',
      });
    }
  };


  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>Centro de Ayuda</DialogTitle>
          <DialogDescription>
            Encuentra guías y documentación sobre todas las funcionalidades de la aplicación.
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 grid grid-cols-4 overflow-hidden">
          <aside className="col-span-1 border-r flex flex-col">
            <div className="p-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Buscar..." className="pl-8" />
              </div>
            </div>
            <ScrollArea className="flex-1">
              <nav className="p-4 space-y-2">
                {helpCategories.map((category) => (
                  <a
                    key={category.id}
                    href={`#${category.id}`}
                    onClick={(e) => handleNavClick(e, category.id)}
                    className={cn(
                        "block px-3 py-2 rounded-md text-sm font-medium",
                        activeCategory === category.id
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                    )}
                  >
                    {category.title}
                  </a>
                ))}
              </nav>
            </ScrollArea>
          </aside>
          <main ref={contentRef} className="col-span-3 overflow-y-auto">
            <div className="p-6">
                <HelpContent />
            </div>
          </main>
        </div>
      </DialogContent>
    </Dialog>
  );
}
