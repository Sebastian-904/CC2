

"use client";

import * as React from "react";
import {
  Settings,
  FileText,
  ShieldCheck,
  Building,
  Users,
  LayoutDashboard,
  PlusCircle,
  LayoutTemplate,
  Shield,
  History,
} from "lucide-react";
import {
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarSeparator,
  SidebarMenuSkeleton
} from "@/components/ui/sidebar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { usePathname, useRouter } from 'next/navigation';
import { useApp } from "./app-providers";
import { NewCompanyDialog } from "./new-company-dialog";
import type { Company } from "@/lib/types";
import { Skeleton } from "./ui/skeleton";


export function AppSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { 
    user,
    assigneeFilter, 
    setAssigneeFilter, 
    companies, 
    activeCompanyId, 
    setActiveCompanyId,
    addCompany,
    assignableUsers,
    events,
    isLoading,
    activeCompany,
  } = useApp();
  const [isNewCompanyDialogOpen, setIsNewCompanyDialogOpen] = React.useState(false);
  const [isMounted, setIsMounted] = React.useState(false);

  const eventCategories = React.useMemo(() => {
    const categories = new Set(events.map(event => event.category));
    return Array.from(categories);
  }, [events]);

  const canManageTemplates = user?.role === 'admin' || user?.role === 'consultor';
  const isGlobalAdmin = user?.role === 'admin';
  const isConsultant = user?.role === 'admin' || user?.role === 'consultor';
  const isClientUser = user?.role === 'cliente_admin' || user?.role === 'cliente_miembro';


  React.useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleCompanyChange = (value: string) => {
    if (value === "new-company") {
        setIsNewCompanyDialogOpen(true);
    } else {
        setActiveCompanyId(value);
        router.push('/dashboard');
    }
  };
  
  const handleCompanyCreated = (newCompanyData: Omit<Company, 'id' | 'users' | 'events' | 'logoUrl'>) => {
    addCompany(newCompanyData);
  };
  
  if (!isMounted || isLoading) {
    return (
      <>
        <SidebarHeader>
            <div className="flex items-center gap-2">
            <ShieldCheck className="w-8 h-8 text-primary" />
            <div className="flex flex-col group-data-[collapsible=icon]:hidden">
                <h2 className="text-lg font-semibold">CompliancePro</h2>
                <p className="text-xs text-muted-foreground">Suite de Calendario</p>
            </div>
            </div>
        </SidebarHeader>
        <SidebarContent>
            <div className="px-4 mb-4 group-data-[collapsible=icon]:hidden">
                <Skeleton className="h-6 w-20 mb-2"/>
                <Skeleton className="h-10 w-full"/>
            </div>
            <SidebarMenu>
                <SidebarMenuSkeleton showIcon />
                <SidebarMenuSkeleton showIcon />
                <SidebarMenuSkeleton showIcon />
                <SidebarMenuSkeleton showIcon />
                <SidebarMenuSkeleton showIcon />
                <SidebarSeparator/>
                <SidebarMenuSkeleton showIcon />
            </SidebarMenu>
        </SidebarContent>
      </>
    )
  }

  return (
    <>
      <SidebarHeader>
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-8 h-8 text-primary" />
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <h2 className="text-lg font-semibold">CompliancePro</h2>
            <p className="text-xs text-muted-foreground">Suite de Calendario</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        {isConsultant && (
            <div className="px-4 mb-4 group-data-[collapsible=icon]:hidden" id="tour-company-selector">
                <Label htmlFor="company-select">Empresa Activa</Label>
                <Select 
                value={activeCompanyId || ""} 
                onValueChange={handleCompanyChange}
                disabled={isLoading || companies.length === 0}
                >
                <SelectTrigger id="company-select">
                    <SelectValue placeholder={isLoading ? "Cargando..." : "Seleccionar empresa"} />
                </SelectTrigger>
                <SelectContent>
                    {companies.map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                        {company.generalInfo.legalName}
                    </SelectItem>
                    ))}
                    <SidebarSeparator className="my-1"/>
                    {isConsultant && (
                        <div 
                            className="flex items-center gap-2 p-2 text-sm text-muted-foreground cursor-pointer hover:bg-muted rounded-sm"
                            onClick={() => handleCompanyChange("new-company")}
                        >
                            <PlusCircle className="h-4 w-4" />
                            <span>Crear Nueva Empresa</span>
                        </div>
                    )}
                </SelectContent>
                </Select>
            </div>
        )}
        
        {isClientUser && activeCompany && (
             <div className="px-4 mb-4 group-data-[collapsible=icon]:hidden">
                <Label>Empresa</Label>
                <div className="mt-2 flex items-center gap-2 rounded-md border bg-muted/50 p-2 text-sm">
                    <Building className="h-4 w-4 shrink-0" />
                    <span className="font-semibold truncate">{activeCompany.generalInfo.legalName}</span>
                </div>
            </div>
        )}


        <SidebarMenu>
          
            <>
              <SidebarMenuItem>
                <SidebarMenuButton href="/dashboard" isActive={pathname.startsWith('/dashboard')} tooltip="Dashboard">
                  <LayoutDashboard />
                  <span>Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton href="/company-profile" isActive={pathname === '/company-profile'} tooltip="Perfil de Empresa">
                  <Building />
                  <span>Perfil de Empresa</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                  <SidebarMenuButton href="/obligations" isActive={pathname === '/obligations'} tooltip="Obligaciones">
                    <ShieldCheck />
                    <span>Obligaciones</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              <SidebarMenuItem>
                  <SidebarMenuButton href="/users" isActive={pathname === '/users'} tooltip="Gestión de Usuarios">
                    <Users />
                    <span>Gestión de Usuarios</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton href="/reports" isActive={pathname === '/reports'} tooltip="Reportes">
                  <FileText />
                  <span>Reportes</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarSeparator />
              {isGlobalAdmin && (
                <SidebarMenuItem>
                  <SidebarMenuButton href="/admin" isActive={pathname === '/admin'} tooltip="Administración">
                    <Shield />
                    <span>Administración</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
               {isConsultant && (
                <SidebarMenuItem>
                  <SidebarMenuButton href="/audit-log" isActive={pathname === '/audit-log'} tooltip="Auditoría">
                    <History />
                    <span>Auditoría</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
              {canManageTemplates && (
                <SidebarMenuItem>
                  <SidebarMenuButton href="/templates" isActive={pathname === '/templates'} tooltip="Plantillas y Categorías">
                    <LayoutTemplate />
                    <span>Plantillas</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
                <SidebarMenuItem>
                  <SidebarMenuButton href="/settings" isActive={pathname === '/settings'} tooltip="Configuración">
                    <Settings />
                    <span>Configuración</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
            </>
          
        </SidebarMenu>

        <SidebarSeparator />

        <SidebarGroup className="group-data-[collapsible=icon]:hidden">
          <SidebarGroupLabel>Filtros</SidebarGroupLabel>
          <div className="space-y-4 px-2">
            <div>
              <Label htmlFor="category-filter">Categoría</Label>
              <Select disabled={!activeCompanyId || eventCategories.length === 0}>
                <SelectTrigger id="category-filter">
                  <SelectValue placeholder="Todas las Categorías" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las Categorías</SelectItem>
                  {eventCategories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="assignee-filter">Asignado a</Label>
              <Select 
                value={assigneeFilter || "all"} 
                onValueChange={(value) => setAssigneeFilter(value === "all" ? null : value)}
                disabled={!activeCompanyId || !assignableUsers || assignableUsers.length === 0}
              >
                <SelectTrigger id="assignee-filter">
                  <SelectValue placeholder="Todos los Asignados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los Asignados</SelectItem>
                  {assignableUsers?.map(user => (
                     <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </SidebarGroup>
      </SidebarContent>
      

      <NewCompanyDialog 
        isOpen={isNewCompanyDialogOpen}
        onOpenChange={setIsNewCompanyDialogOpen}
        onCompanyCreated={handleCompanyCreated}
      />
    </>
  );
}
