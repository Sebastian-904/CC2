

"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import type { ComplianceObligation, TaskCategory, User, Priority } from "@/lib/types";
import { useApp } from "./app-providers";

const obligationSchema = z.object({
  name: z.string().min(1, "El nombre es requerido."),
  status: z.enum(["activa", "inactiva"]),
  frequency: z.enum(["mensual", "anual", "semanal"]),
  dueDay: z.coerce.number().min(1, "El día debe ser mayor a 0.").max(366, "El día no puede ser mayor a 366."),
  assigneeId: z.string().optional(),
  category: z.string().optional(),
  defaultPriority: z.enum(["low", "medium", "high"]).optional(),
});


type ObligationEditDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onSave: (data: Omit<ComplianceObligation, 'id'>, obligationId: string | null) => void;
  obligation: ComplianceObligation | null;
  companyUsers: User[];
};

export function ObligationEditDialog({ isOpen, onOpenChange, onSave, obligation, companyUsers }: ObligationEditDialogProps) {
  const { taskCategories } = useApp();
  
  const form = useForm<z.infer<typeof obligationSchema>>({
    resolver: zodResolver(obligationSchema),
  });

  React.useEffect(() => {
    if (obligation) {
      form.reset({
        name: obligation.name,
        status: obligation.status,
        frequency: obligation.frequency,
        dueDay: obligation.dueDay,
        assigneeId: obligation.assigneeId,
        category: obligation.category,
        defaultPriority: obligation.defaultPriority || 'medium'
      });
    } else {
      form.reset({
        name: "",
        status: "activa",
        frequency: "mensual",
        dueDay: 1,
        assigneeId: "",
        category: "",
        defaultPriority: "medium"
      });
    }
  }, [obligation, form, isOpen]);

  const handleSubmit = (values: z.infer<typeof obligationSchema>) => {
    const dataToSave = { ...values };
    onSave(dataToSave, obligation?.id || null);
    onOpenChange(false);
  };
  
  const watchedFrequency = form.watch('frequency');

  const getDueDayLabel = () => {
    switch (watchedFrequency) {
        case 'anual': return "Día del Año de Vencimiento (1-366)";
        case 'semanal': return "Día de la Semana (1=Lu, 7=Do)";
        default: return "Día del Mes de Vencimiento (1-31)";
    }
  }

  const getDueDayPlaceholder = () => {
      switch (watchedFrequency) {
          case 'anual': return "Ej. 90 (para el 31 de marzo)";
          case 'semanal': return "Ej. 1 (para Lunes)";
          default: return "Ej. 17";
      }
  }


  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{obligation ? "Editar Obligación" : "Añadir Nueva Obligación"}</DialogTitle>
          <DialogDescription>
            {obligation ? "Modifica los detalles y la automatización de la obligación." : "Completa los detalles para la nueva obligación recurrente."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre de la Obligación</FormLabel>
                  <FormControl>
                    <Input placeholder="Ej. Reporte Anual de Operaciones de Comercio Exterior" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                 <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Categoría por Defecto</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..."/></SelectTrigger></FormControl>
                            <SelectContent>
                                {taskCategories.map(cat => (
                                     <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                <FormField
                    control={form.control}
                    name="assigneeId"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Asignado por Defecto</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!companyUsers || companyUsers.length === 0}>
                            <FormControl><SelectTrigger><SelectValue placeholder={!companyUsers || companyUsers.length === 0 ? "Añade usuarios" : "Seleccionar..."} /></SelectTrigger></FormControl>
                            <SelectContent>
                                {(companyUsers || []).map(user => (
                                    <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                 <FormField
                    control={form.control}
                    name="defaultPriority"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Prioridad por Defecto</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..." /></SelectTrigger></FormControl>
                            <SelectContent>
                                <SelectItem value="low">Baja</SelectItem>
                                <SelectItem value="medium">Media</SelectItem>
                                <SelectItem value="high">Alta</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
             <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FormField
                control={form.control}
                name="frequency"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel>Frecuencia</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..." /></SelectTrigger></FormControl>
                        <SelectContent>
                            <SelectItem value="semanal">Semanal</SelectItem>
                            <SelectItem value="mensual">Mensual</SelectItem>
                            <SelectItem value="anual">Anual</SelectItem>
                        </SelectContent>
                    </Select>
                    <FormMessage />
                    </FormItem>
                )}
                />
                <FormField
                    control={form.control}
                    name="dueDay"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>{getDueDayLabel()}</FormLabel>
                        <FormControl>
                            <Input type="number" placeholder={getDueDayPlaceholder()} {...field} />
                        </FormControl>
                        <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>Estado</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..." /></SelectTrigger></FormControl>
                            <SelectContent>
                                <SelectItem value="activa">Activa</SelectItem>
                                <SelectItem value="inactiva">Inactiva</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage />
                        </FormItem>
                    )}
                />
            </div>
            <DialogFooter className="pt-4">
              <DialogClose asChild>
                <Button type="button" variant="outline">Cancelar</Button>
              </DialogClose>
              <Button type="submit">Guardar</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
