
"use client";

import * as React from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Textarea } from "./ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Calendar } from "./ui/calendar";
import { Label } from "./ui/label";
import { CalendarIcon, Loader2, Trash2 } from "lucide-react";
import type { CalendarEvent, Priority, User } from "@/lib/types";
import { useApp } from "./app-providers";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "./ui/alert-dialog";

const taskSchema = z.object({
  title: z.string().min(3, "El título debe tener al menos 3 caracteres."),
  description: z.string().optional(),
  date: z.date({ required_error: "La fecha es requerida." }),
  startTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Formato de hora inválido (HH:MM)").optional(),
  endTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Formato de hora inválido (HH:MM)").optional(),
  categoryId: z.string().min(1, "La categoría es requerida."),
  priority: z.enum(["low", "medium", "high"]),
  assigneeId: z.string().min(1, "Debe asignar la tarea a un usuario."),
});

type TaskFormValues = z.infer<typeof taskSchema>;

type TaskEditDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onSave: (data: Omit<CalendarEvent, 'id' | 'companyId'>, id: string | null) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  event: Partial<CalendarEvent> | null;
};

export function TaskEditDialog({ isOpen, onOpenChange, onSave, onDelete, event }: TaskEditDialogProps) {
  const { taskTemplates, taskCategories, assignableUsers, user } = useApp();
  const [isSaving, setIsSaving] = React.useState(false);

  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskSchema),
  });
  
  React.useEffect(() => {
    if (isOpen) {
        setIsSaving(false);
        if (event && event.id) { // Editing existing event
            const category = taskCategories.find(c => c.name === event.category);
            form.reset({
                title: event.title || "",
                description: event.description || "",
                date: event.date ? new Date(event.date) : new Date(),
                startTime: event.startTime || "",
                endTime: event.endTime || "",
                categoryId: category?.id || "",
                priority: event.priority || "medium",
                assigneeId: event.assignee?.id || "",
            });
        } else { // Creating new event
            form.reset({
                title: "",
                description: "",
                date: event?.date ? new Date(event.date) : new Date(),
                startTime: "09:00",
                endTime: "10:00",
                categoryId: "",
                priority: "medium",
                assigneeId: user?.id || "",
            });
        }
    }
  }, [event, isOpen, form, taskCategories, user]);

  const handleTemplateSelect = (templateId: string) => {
    const template = taskTemplates.find(t => t.id === templateId);
    if (template) {
      form.setValue("title", template.name, { shouldValidate: true });
      form.setValue("description", template.description, { shouldValidate: true });
      form.setValue("categoryId", template.categoryId, { shouldValidate: true });
      form.setValue("priority", template.defaultPriority, { shouldValidate: true });
    }
  };

  const handleSubmit = async (values: TaskFormValues) => {
    setIsSaving(true);
    const category = taskCategories.find(c => c.id === values.categoryId);
    const assignee = assignableUsers.find(u => u.id === values.assigneeId);
    
    if (!category || !assignee) {
        console.error("Category or Assignee not found!");
        setIsSaving(false);
        return;
    }

    const dataToSave: Omit<CalendarEvent, 'id' | 'companyId'> = {
        title: values.title,
        description: values.description || '',
        date: format(values.date, 'yyyy-MM-dd'),
        startTime: values.startTime || '',
        endTime: values.endTime || '',
        location: event?.location || '',
        participants: event?.participants || [],
        comments: event?.comments || [],
        attachments: event?.attachments || [],
        priority: values.priority,
        status: event?.status || 'pending',
        category: category.name,
        assignee: assignee,
        sourceObligationId: event?.sourceObligationId,
    };
    
    await onSave(dataToSave, event?.id || null);
  };
  
  const handleDelete = async () => {
    if (event?.id) {
      setIsSaving(true);
      await onDelete(event.id);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{event?.id ? "Editar Tarea" : "Crear Nueva Tarea"}</DialogTitle>
          <DialogDescription>
            {event?.id ? "Modifica los detalles de la tarea." : "Usa una plantilla o completa los campos para crear una tarea."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
             {!event?.id && (
                 <div className="space-y-2">
                    <Label>Usar Plantilla (Opcional)</Label>
                    <Select onValueChange={handleTemplateSelect}>
                        <SelectTrigger>
                            <SelectValue placeholder="Seleccionar una plantilla..."/>
                        </SelectTrigger>
                        <SelectContent>
                            {taskTemplates.map(template => (
                                <SelectItem key={template.id} value={template.id}>{template.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
             )}

            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Título</FormLabel>
                  <FormControl>
                    <Input placeholder="Ej. Presentar declaración mensual" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descripción</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Añade detalles sobre la tarea..." {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FormField control={form.control} name="date" render={({ field }) => (
                     <FormItem className="flex flex-col">
                        <FormLabel>Fecha</FormLabel>
                        <Popover><PopoverTrigger asChild>
                            <FormControl>
                                <Button variant={"outline"} className={cn("pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                    {field.value ? format(field.value, "PPP") : <span>Elige una fecha</span>}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50"/>
                                </Button>
                            </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus/>
                        </PopoverContent></Popover>
                        <FormMessage/>
                    </FormItem>
                )}/>
                 <FormField control={form.control} name="startTime" render={({ field }) => (
                     <FormItem><FormLabel>Hora Inicio</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage/></FormItem>
                 )}/>
                  <FormField control={form.control} name="endTime" render={({ field }) => (
                     <FormItem><FormLabel>Hora Fin</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage/></FormItem>
                 )}/>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FormField control={form.control} name="categoryId" render={({ field }) => (
                    <FormItem>
                        <FormLabel>Categoría</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..."/></SelectTrigger></FormControl>
                            <SelectContent>{taskCategories.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}</SelectContent>
                        </Select>
                        <FormMessage/>
                    </FormItem>
                )}/>
                <FormField control={form.control} name="priority" render={({ field }) => (
                    <FormItem>
                        <FormLabel>Prioridad</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..."/></SelectTrigger></FormControl>
                            <SelectContent>
                                <SelectItem value="low">Baja</SelectItem>
                                <SelectItem value="medium">Media</SelectItem>
                                <SelectItem value="high">Alta</SelectItem>
                            </SelectContent>
                        </Select>
                        <FormMessage/>
                    </FormItem>
                )}/>
                <FormField control={form.control} name="assigneeId" render={({ field }) => (
                    <FormItem>
                        <FormLabel>Asignado A</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl><SelectTrigger><SelectValue placeholder="Seleccionar..."/></SelectTrigger></FormControl>
                            <SelectContent>{assignableUsers.map(u => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}</SelectContent>
                        </Select>
                        <FormMessage/>
                    </FormItem>
                )}/>
            </div>

            <DialogFooter className="pt-4 flex justify-between">
                <div>
                     {event?.id && (
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                               <Button type="button" variant="destructive" disabled={isSaving}><Trash2 className="mr-2 h-4 w-4"/>Eliminar</Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader><AlertDialogTitle>¿Confirmas la eliminación?</AlertDialogTitle><AlertDialogDescription>
                                    Esta acción es permanente y no se puede deshacer. Se eliminará la tarea "{event.title}".
                                </AlertDialogDescription></AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Sí, eliminar</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    )}
                </div>
                <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving}>Cancelar</Button>
                    <Button type="submit" disabled={isSaving}>
                        {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin"/>}
                        {isSaving ? "Guardando..." : "Guardar Tarea"}
                    </Button>
                </div>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
