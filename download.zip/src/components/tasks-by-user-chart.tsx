
"use client";

import * as React from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { CalendarEvent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { useApp } from "./app-providers";

type TasksByUserChartProps = {
  events: CalendarEvent[];
};

export function TasksByUserChart({ events }: TasksByUserChartProps) {
  const { activeCompany } = useApp();

  const data = React.useMemo(() => {
    if (!activeCompany?.users) return [];

    const userTaskCounts: { [key: string]: number } = {};

    // Initialize counters only for users within the active company
    activeCompany.users.forEach(user => {
      userTaskCounts[user.name] = 0;
    });

    // Aggregate task counts for assigned users
    events.forEach((event) => {
      if (event.assignee?.name && userTaskCounts.hasOwnProperty(event.assignee.name)) {
        userTaskCounts[event.assignee.name]++;
      }
    });

    return Object.entries(userTaskCounts)
      .map(([name, tasks]) => ({ name, tasks }))
      .sort((a, b) => b.tasks - a.tasks);
  }, [events, activeCompany]);

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>Carga de Trabajo por Usuario</CardTitle>
        <CardDescription>Total de tareas asignadas a cada miembro del equipo.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="horizontal" margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} interval={0} />
              <YAxis allowDecimals={false} />
              <Tooltip 
                 cursor={{fill: 'hsl(var(--muted))'}}
                 contentStyle={{
                     backgroundColor: 'hsl(var(--background))',
                     border: '1px solid hsl(var(--border))',
                     borderRadius: 'var(--radius)',
                 }}
              />
              <Bar dataKey="tasks" fill="hsl(var(--primary))" barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
