
"use client";

import * as React from "react";
import type { CalendarEvent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Target } from "lucide-react";

type ComplianceScoreKpiProps = {
  events: CalendarEvent[];
};

export function ComplianceScoreKpi({ events }: ComplianceScoreKpiProps) {
  const score = React.useMemo(() => {
    if (events.length === 0) {
      return 100;
    }
    const completedTasks = events.filter((e) => e.status === "completed").length;
    return Math.round((completedTasks / events.length) * 100);
  }, [events]);

  const getScoreColor = () => {
    if (score >= 90) return "text-green-500";
    if (score >= 70) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Índice de Cumplimiento</CardTitle>
        <Target className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className={`text-5xl font-bold ${getScoreColor()}`}>{score}%</div>
        <p className="text-xs text-muted-foreground pt-1">
          Porcentaje de tareas completadas
        </p>
      </CardContent>
    </Card>
  );
}
