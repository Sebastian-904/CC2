
"use client";

import {
  Search,
  Wand2,
  Bell,
  Settings,
  HelpCircle,
  LogOut,
  User as UserIcon,
  ChevronDown,
  PanelLeft,
} from "lucide-react";
import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { ThemeToggle } from "./theme-toggle";
import { NotificationPopover } from "./notification-popover";
import { LiveClock } from "./live-clock";
import { useApp } from "./app-providers";
import { useSidebar } from "./ui/sidebar";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";
import { useAuth } from "@/contexts/auth-context";
import { useRouter } from "next/navigation";
import { AiEventCreator } from "./ai-event-creator";
import { HelpCenter } from "./help-center";
import React from "react";
import { CreateEventFromTextOutput } from "@/ai/flows/create-event-from-text";


export function AppHeader() {
  const { user, events, activeCompany, addObligationToCalendar } = useApp();
  const { state: sidebarState, toggleSidebar } = useSidebar();
  const { logout } = useAuth();
  const router = useRouter();

  const [isHelpCenterOpen, setIsHelpCenterOpen] = React.useState(false);
  const [isAiCreatorOpen, setIsAiCreatorOpen] = React.useState(false);
  
  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  const handleEventCreated = (eventData: CreateEventFromTextOutput) => {
    addObligationToCalendar(eventData);
  }

  return (
    <>
      <header className="flex h-16 shrink-0 items-center gap-2 border-b bg-card px-4 md:px-6">
        <div className="flex items-center gap-2">
          <SidebarTrigger className="md:hidden" />
          <Button variant="ghost" size="icon" className="hidden md:inline-flex" onClick={toggleSidebar}>
              <PanelLeft />
              <span className="sr-only">Toggle Sidebar</span>
          </Button>
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="hidden md:block">
              <h1 className="text-lg font-semibold">CompliancePro</h1>
            </Link>
            <div className={cn("hidden text-lg font-semibold text-muted-foreground md:hidden lg:block", sidebarState === 'expanded' && 'md:hidden xl:block')}>
              {activeCompany && (
                <>
                  <span className="text-muted-foreground/50 mx-1">/</span>
                  <span className="truncate">{activeCompany.generalInfo.legalName}</span>
                </>
              )}
            </div>
          </div>
          <LiveClock />
        </div>
        <div className="flex w-full items-center gap-2 md:ml-auto">
          <form className="ml-auto flex-1 sm:flex-initial">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar eventos..."
                className="pl-8 w-full sm:w-[200px] md:w-[200px] lg:w-[300px]"
              />
            </div>
          </form>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="icon" onClick={() => setIsAiCreatorOpen(true)} aria-label="Crear evento con IA" id="tour-ai-event-creator">
                  <Wand2 className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Crear Evento con IA</p>
            </TooltipContent>
          </Tooltip>
          
          <NotificationPopover events={events} />
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" onClick={() => setIsHelpCenterOpen(true)} aria-label="Abrir centro de ayuda" id="tour-help-center">
                  <HelpCircle className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Centro de Ayuda</p>
            </TooltipContent>
          </Tooltip>
          
          <ThemeToggle />

          <DropdownMenu>
              <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-auto flex items-center gap-2 px-2">
                    <Avatar className="h-8 w-8">
                        <AvatarImage src={user?.avatarUrl} alt={user?.name} data-ai-hint="user avatar" />
                        <AvatarFallback>{user?.name?.[0]}</AvatarFallback>
                    </Avatar>
                    <span className="hidden md:flex flex-col items-start">
                          <span className="text-sm font-medium">{user?.name}</span>
                          <span className="text-xs text-muted-foreground -mt-1">{user?.email}</span>
                    </span>
                    <ChevronDown className="h-4 w-4 text-muted-foreground hidden md:block" />
                  </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                      <Link href="/user-profile">
                          <UserIcon className="mr-2 h-4 w-4" />
                          <span>Mi Perfil</span>
                      </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                      <Link href="/settings">
                          <Settings className="mr-2 h-4 w-4" />
                          <span>Configuración</span>
                      </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Cerrar Sesión</span>
                  </DropdownMenuItem>
              </DropdownMenuContent>
          </DropdownMenu>

        </div>
      </header>
       <HelpCenter 
        isOpen={isHelpCenterOpen}
        onOpenChange={setIsHelpCenterOpen}
      />
      <AiEventCreator 
        isOpen={isAiCreatorOpen}
        onOpenChange={setIsAiCreatorOpen}
        onEventCreate={handleEventCreated}
      />
    </>
  );
}
