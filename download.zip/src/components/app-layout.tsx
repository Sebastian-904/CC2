"use client";

import * as React from 'react';
import { usePathname } from 'next/navigation';
import { SidebarProvider, Sidebar, SidebarInset } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/app-sidebar';

export function AppLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const isLoginPage = pathname === '/login';

    if (isLoginPage) {
        return <>{children}</>;
    }
    
    return (
        <SidebarProvider>
            <Sidebar collapsible="icon">
                <AppSidebar />
            </Sidebar>
            <SidebarInset className="flex flex-col">
                {children}
            </SidebarInset>
        </SidebarProvider>
    )
}
