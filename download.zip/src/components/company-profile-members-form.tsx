
"use client";

import * as React from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Trash2 } from "lucide-react";
import { Separator } from "./ui/separator";
import type { CouncilMember } from "@/lib/types";

const memberSchema = z.object({
  id: z.string().optional(),
  fullName: z.string().min(1, "El nombre es requerido."),
  rfc: z.string().min(12, "El RFC debe tener al menos 12 caracteres.").max(13, "El RFC no debe exceder los 13 caracteres."),
  personType: z.enum(["fisica", "moral"]),
  role: z.enum(["socio", "representante_legal", "administrador"]),
  nationality: z.string().min(1, "La nacionalidad es requerida."),
  taxObligationInMexico: z.boolean(),
});

const membersFormSchema = z.object({
  members: z.array(memberSchema),
});

type MembersFormValues = z.infer<typeof membersFormSchema>;

type CompanyProfileMembersFormProps = {
    isReadOnly: boolean;
    defaultValues: CouncilMember[];
    onSave: (data: CouncilMember[]) => Promise<void>;
};

export function CompanyProfileMembersForm({ isReadOnly, defaultValues, onSave }: CompanyProfileMembersFormProps) {
  const form = useForm<MembersFormValues>({
    resolver: zodResolver(membersFormSchema),
    defaultValues: {
        members: defaultValues || [],
    }
  });

  React.useEffect(() => {
    form.reset({ members: defaultValues || [] });
  }, [defaultValues, form]);

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "members",
  });

  const onSubmit = async (data: MembersFormValues) => {
    await onSave(data.members);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Miembros del Consejo / Socios</CardTitle>
            <CardDescription>
              Gestión de las personas clave de la sociedad, como socios, accionistas o miembros del consejo de administración.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {fields.map((field, index) => (
                <fieldset disabled={isReadOnly} key={field.id} className="space-y-4 border p-4 rounded-lg relative">
                    <legend className="text-sm font-medium px-1">Miembro {index + 1}</legend>
                     {!isReadOnly && (
                        <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 text-destructive hover:bg-destructive/10"
                            onClick={() => remove(index)}
                            >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Eliminar Miembro</span>
                        </Button>
                    )}

                    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                        <FormField
                            control={form.control}
                            name={`members.${index}.fullName`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Nombre Completo / Razón Social</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. John Doe" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`members.${index}.rfc`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>RFC</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. DODJ880101ABC" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name={`members.${index}.personType`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Tipo de Persona</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="fisica">Física</SelectItem>
                                    <SelectItem value="moral">Moral</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`members.${index}.role`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Carácter</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="socio">Socio / Accionista</SelectItem>
                                    <SelectItem value="representante_legal">Representante Legal</SelectItem>
                                    <SelectItem value="administrador">Administrador Único</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`members.${index}.nationality`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Nacionalidad</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. Mexicana" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`members.${index}.taxObligationInMexico`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Tributa en México</FormLabel>
                                <Select onValueChange={(value) => field.onChange(value === 'true')} defaultValue={String(field.value)}>
                                    <FormControl>
                                        <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        <SelectItem value="true">Sí</SelectItem>
                                        <SelectItem value="false">No</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                </fieldset>
              ))}
            </div>

            {!isReadOnly && (
              <>
                <Separator className="my-6" />
                <div className="flex justify-between items-center">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => append({ id: `new-${Date.now()}`, fullName: "", rfc: "", personType: "fisica", role: "socio", nationality: '', taxObligationInMexico: true })}
                        className="mt-4"
                        >
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Añadir Miembro
                    </Button>
                    <Button type="submit">Guardar Cambios</Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </form>
    </Form>
  );
}
