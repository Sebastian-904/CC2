
"use client";

import * as React from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Trash2 } from "lucide-react";
import { Separator } from "./ui/separator";
import type { CustomsAgent } from "@/lib/types";

const agentSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "El nombre es requerido."),
  patentNumber: z.string().min(1, "La patente es requerida."),
  status: z.enum(["aceptado", "pendiente"]),
});

const agentsFormSchema = z.object({
  agents: z.array(agentSchema),
});

type AgentsFormValues = z.infer<typeof agentsFormSchema>;

type CompanyProfileAgentsFormProps = {
    isReadOnly: boolean;
    defaultValues: CustomsAgent[];
    onSave: (data: CustomsAgent[]) => Promise<void>;
};

export function CompanyProfileAgentsForm({ isReadOnly, defaultValues, onSave }: CompanyProfileAgentsFormProps) {
  const form = useForm<AgentsFormValues>({
    resolver: zodResolver(agentsFormSchema),
    defaultValues: {
        agents: defaultValues || []
    },
  });

  React.useEffect(() => {
    form.reset({ agents: defaultValues || [] });
  }, [defaultValues, form]);

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "agents",
  });

  const onSubmit = async (data: AgentsFormValues) => {
    await onSave(data.agents);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Agentes Aduanales</CardTitle>
            <CardDescription>
              Gestión de encargos conferidos a agentes aduanales para operaciones de comercio exterior.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {fields.map((field, index) => (
                <fieldset disabled={isReadOnly} key={field.id} className="space-y-4 border p-4 rounded-lg relative">
                     <legend className="text-sm font-medium px-1">Agente {index + 1}</legend>
                     {!isReadOnly && (
                        <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 text-destructive hover:bg-destructive/10"
                            onClick={() => remove(index)}
                            >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Eliminar Agente</span>
                        </Button>
                    )}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                            control={form.control}
                            name={`agents.${index}.name`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Nombre del Agente / Agencia</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. Agencia Aduanal G&O" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`agents.${index}.patentNumber`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Patente</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. 3456" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name={`agents.${index}.status`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Estado del Encargo</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                    <SelectItem value="aceptado">Aceptado</SelectItem>
                                    <SelectItem value="pendiente">Pendiente</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                </fieldset>
              ))}
            </div>

            {!isReadOnly && (
              <>
                <Separator className="my-6" />
                <div className="flex justify-between items-center">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => append({ id: `new-${Date.now()}`, name: "", patentNumber: "", status: "pendiente" })}
                        className="mt-4"
                        >
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Añadir Agente Aduanal
                    </Button>
                    <Button type="submit">Guardar Cambios</Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </form>
    </Form>
  );
}
