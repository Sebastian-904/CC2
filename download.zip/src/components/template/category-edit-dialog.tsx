
"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import type { TaskCategory } from "@/lib/types";

const categorySchema = z.object({
  name: z.string().min(1, "El nombre es requerido."),
  color: z.string().regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, "Debe ser un color hexadecimal válido (ej. #RRGGBB)."),
});

type CategoryEditDialogProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onSave: (data: Omit<TaskCategory, 'id'>) => void;
  category: TaskCategory | null;
};

export function CategoryEditDialog({ isOpen, onOpenChange, onSave, category }: CategoryEditDialogProps) {
  const form = useForm<z.infer<typeof categorySchema>>({
    resolver: zodResolver(categorySchema),
  });

  React.useEffect(() => {
    if (isOpen) {
        if (category) {
            form.reset({
                name: category.name,
                color: category.color,
            });
        } else {
            form.reset({
                name: "",
                color: "#34d399",
            });
        }
    }
  }, [category, form, isOpen]);

  const handleSubmit = (values: z.infer<typeof categorySchema>) => {
    onSave(values);
    onOpenChange(false);
  };

  const selectedColor = form.watch("color");

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{category ? "Editar Categoría" : "Nueva Categoría"}</DialogTitle>
          <DialogDescription>
            {category ? "Modifica los detalles de la categoría." : "Define una nueva categoría para organizar tareas."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre de la Categoría</FormLabel>
                  <FormControl>
                    <Input placeholder="Ej. Fiscal" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="color"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Color</FormLabel>
                   <div className="flex items-center gap-2">
                    <FormControl>
                        <Input type="color" {...field} className="p-1 h-10 w-14" />
                    </FormControl>
                    <Input 
                        value={field.value} 
                        onChange={field.onChange} 
                        placeholder="#RRGGBB"
                        className="font-mono flex-1"
                    />
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
              <Button type="submit">Guardar</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
