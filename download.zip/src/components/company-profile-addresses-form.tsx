
"use client";

import * as React from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PlusCircle, Trash2 } from "lucide-react";
import { Separator } from "./ui/separator";
import type { CompanyAddress } from "@/lib/types";


const addressSchema = z.object({
    id: z.string().optional(),
    streetAndNumber: z.string().min(1, "La calle y número son requeridos."),
    postalCode: z.string().min(5, "El código postal debe tener al menos 5 dígitos."),
    neighborhood: z.string().min(1, "La colonia es requerida."),
    municipality: z.string().min(1, "El municipio es requerido."),
    city: z.string().min(1, "La ciudad es requerida."),
    state: z.string().min(1, "El estado es requerido."),
    phone: z.string().min(10, "El teléfono debe tener al menos 10 dígitos.").optional().or(z.literal('')),
    linkedProgram: z.enum(["immex", "prosec", "none"]),
});

const addressesFormSchema = z.object({
  addresses: z.array(addressSchema),
});

type AddressesFormValues = z.infer<typeof addressesFormSchema>;

type CompanyProfileAddressesFormProps = {
    isReadOnly: boolean;
    defaultValues: CompanyAddress[];
    onSave: (data: CompanyAddress[]) => Promise<void>;
};

export function CompanyProfileAddressesForm({ isReadOnly, defaultValues, onSave }: CompanyProfileAddressesFormProps) {
  const form = useForm<AddressesFormValues>({
    resolver: zodResolver(addressesFormSchema),
    defaultValues: {
        addresses: defaultValues || []
    },
  });

  React.useEffect(() => {
    form.reset({ addresses: defaultValues || [] });
  }, [defaultValues, form]);

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "addresses",
  });

  const onSubmit = async (data: AddressesFormValues) => {
    await onSave(data.addresses);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Domicilios Operativos</CardTitle>
            <CardDescription>
              Registro de todas las ubicaciones físicas operativas de la empresa.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {fields.map((field, index) => (
                <fieldset disabled={isReadOnly} key={field.id} className="space-y-4 border p-4 rounded-lg relative">
                    <legend className="text-sm font-medium px-1">Domicilio {index + 1}</legend>
                     {!isReadOnly && (
                        <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 text-destructive hover:bg-destructive/10"
                            onClick={() => remove(index)}
                            >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Eliminar Domicilio</span>
                        </Button>
                    )}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                            control={form.control}
                            name={`addresses.${index}.streetAndNumber`}
                            render={({ field }) => (
                                <FormItem className="md:col-span-2">
                                <FormLabel>Calle y Número</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. Av. de la Industria 456" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name={`addresses.${index}.neighborhood`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Colonia</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. Parque Industrial" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`addresses.${index}.postalCode`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Código Postal</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. 76120" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`addresses.${index}.municipality`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Municipio / Alcaldía</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. El Marqués" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`addresses.${index}.city`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Ciudad</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. Querétaro" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`addresses.${index}.state`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Estado</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. Querétaro" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                         <FormField
                            control={form.control}
                            name={`addresses.${index}.phone`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Teléfono</FormLabel>
                                <FormControl>
                                    <Input placeholder="Ej. 442 123 4567" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                        <FormField
                            control={form.control}
                            name={`addresses.${index}.linkedProgram`}
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Programa Vinculado</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                        <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        <SelectItem value="none">Ninguno</SelectItem>
                                        <SelectItem value="immex">IMMEX</SelectItem>
                                        <SelectItem value="prosec">PROSEC</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    </div>
                </fieldset>
              ))}
            </div>

            {!isReadOnly && (
              <>
                <Separator className="my-6" />
                <div className="flex justify-between items-center">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={() => append({ id: `new-${Date.now()}`, streetAndNumber: "", postalCode: "", neighborhood: "", municipality: "", city: "", state: "", phone: "", linkedProgram: "none" })}
                        className="mt-4"
                        >
                        <PlusCircle className="mr-2 h-4 w-4" />
                        Añadir Domicilio
                    </Button>
                    <Button type="submit">Guardar Cambios</Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </form>
    </Form>
  );
}
