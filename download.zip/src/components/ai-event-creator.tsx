"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { createEventFromText, type CreateEventFromTextOutput } from "@/ai/flows/create-event-from-text";
import { Wand2, Loader2 } from "lucide-react";

const formSchema = z.object({
  description: z.string().min(10, {
    message: "Por favor describe el evento en al menos 10 caracteres.",
  }),
});

type AiEventCreatorProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onEventCreate: (result: CreateEventFromTextOutput) => void;
};

export function AiEventCreator({
  isOpen,
  onOpenChange,
  onEventCreate,
}: AiEventCreatorProps) {
  const [isProcessing, setIsProcessing] = React.useState(false);
  const { toast } = useToast();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: "",
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setIsProcessing(true);
    try {
      const result = await createEventFromText({ description: values.description });
      
      onEventCreate(result);
      
      toast({
        title: "Borrador de Evento Creado",
        description: "Revisa los detalles de tu nuevo evento en el calendario.",
      });
      form.reset();
      onOpenChange(false);
    } catch (error) {
      console.error("Falló la creación de evento con IA:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo crear el evento. Por favor, inténtalo de nuevo.",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="text-primary" />
            Crear Evento con IA
          </DialogTitle>
          <DialogDescription>
            Describe el evento que quieres crear usando lenguaje natural. Por
            ejemplo, &quot;Programar una reunión de cumplimiento para mañana a las 2 PM con
            el equipo legal.&quot;
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descripción del Evento</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe tu evento aquí..."
                      className="min-h-[120px] resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isProcessing}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={isProcessing}>
                {isProcessing ? (
                  <>
                    <Loader2 className="animate-spin" />
                    Procesando...
                  </>
                ) : (
                  "Crear Evento"
                )}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
