
"use client";

import * as React from "react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export function LiveClock() {
  const [currentTime, setCurrentTime] = React.useState<Date | null>(null);

  React.useEffect(() => {
    // Set initial time on client mount
    setCurrentTime(new Date());

    // Update time every second
    const timerId = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Cleanup interval on component unmount
    return () => clearInterval(timerId);
  }, []);

  if (!currentTime) {
    return (
        <div className="hidden lg:flex items-center gap-2 text-sm text-muted-foreground ml-4">
            <span>Cargando...</span>
        </div>
    );
  }

  const formattedDate = format(currentTime, "EEEE, d 'de' MMMM 'de' yyyy", { locale: es });
  const formattedTime = format(currentTime, "HH:mm:ss");

  return (
    <div className="hidden lg:flex items-center gap-2 text-sm text-muted-foreground ml-4">
      <span className="capitalize">{formattedDate}</span>
      <span>|</span>
      <span>{formattedTime}</span>
    </div>
  );
}
