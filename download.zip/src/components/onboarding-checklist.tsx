
"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Building, UserPlus, ListTodo, FileText, CheckCircle2, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";

type ChecklistState = {
  createdCompany: boolean;
  invitedUser: boolean;
  createdTask: boolean;
  generatedReport: boolean;
};

type OnboardingChecklistProps = {
  state: ChecklistState;
  onMarkAsDone: (key: keyof ChecklistState) => void;
};

export function OnboardingChecklist({ state, onMarkAsDone }: OnboardingChecklistProps) {
  const router = useRouter();

  const checklistItems = [
    {
      id: 'createdCompany' as keyof ChecklistState,
      icon: Building,
      title: "Crea tu primera empresa",
      description: "Añade una empresa cliente para empezar a gestionar.",
      buttonText: "Crear Empresa",
      href: "/company-profile",
    },
    {
      id: 'invitedUser' as keyof ChecklistState,
      icon: UserPlus,
      title: "Invita a un miembro del equipo",
      description: "Añade un usuario a la empresa que creaste.",
      buttonText: "Añadir Usuario",
      href: "/users",
    },
    {
      id: 'createdTask' as keyof ChecklistState,
      icon: ListTodo,
      title: "Crea tu primera tarea",
      description: "Añade una obligación para generar tareas en el calendario.",
      buttonText: "Añadir Obligación",
      href: "/obligations",
    },
    {
      id: 'generatedReport' as keyof ChecklistState,
      icon: FileText,
      title: "Genera tu primer reporte",
      description: "Exporta la actividad del calendario a un PDF.",
      buttonText: "Ir a Reportes",
      href: "/reports",
    },
  ];

  const handleNavigation = (href: string, id: keyof ChecklistState) => {
    onMarkAsDone(id);
    router.push(href);
  };
  

  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-base font-semibold">¡Bienvenido a Compliance Calendar Pro!</CardTitle>
        <CardDescription>
          Completa estos pasos para familiarizarte con las funciones clave.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {checklistItems.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between p-3 rounded-lg bg-background/70"
          >
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                {state[item.id] ? (
                    <CheckCircle2 className="h-6 w-6 text-green-500" />
                ) : (
                    <item.icon className="h-6 w-6 text-muted-foreground" />
                )}
                
              </div>
              <div>
                <p className={`font-medium ${state[item.id] ? 'text-muted-foreground line-through' : ''}`}>
                    {item.title}
                </p>
                <p className={`text-xs text-muted-foreground ${state[item.id] ? 'line-through' : ''}`}>
                    {item.description}
                </p>
              </div>
            </div>
            {!state[item.id] && (
              <Button size="sm" variant="ghost" onClick={() => handleNavigation(item.href, item.id)}>
                {item.buttonText}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
