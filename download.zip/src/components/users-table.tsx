

"use client";

import * as React from "react";
import { Loader2, MoreHorizontal, Pencil, PlusCircle, Trash2, Users } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Company, User } from "@/lib/types";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { DeleteConfirmationDialog } from "./template/delete-confirmation-dialog";
import { useApp } from "./app-providers";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";
import { UserEditDialog } from "./user-edit-dialog";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { UserAssignmentDialog } from "./user-assignment-dialog";


const roleTranslations: { [key in User['role']]: string } = {
    admin: "Administrador Global",
    consultor: "Consultor",
    cliente_admin: "Admin de Cliente",
    cliente_miembro: "Miembro de Cliente",
}

type UsersTableProps = {
  company: Company;
  onUsersChange: (users: User[]) => Promise<void>;
}

export function UsersTable({ company, onUsersChange }: UsersTableProps) {
  const { user: loggedInUser } = useApp();
  const [users, setUsers] = React.useState(company.users || []);
  const [isSaving, setIsSaving] = React.useState(false);

  const [isEditDialogOpen, setIsEditDialogOpen] = React.useState(false);
  const [editingUser, setEditingUser] = React.useState<User | null>(null);
  
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = React.useState(false);
  const [deletingUser, setDeletingUser] = React.useState<User | null>(null);
  
  const [justUpdatedId, setJustUpdatedId] = React.useState<string | null>(null);
  const { toast } = useToast();
  
  const [isAssignmentDialogOpen, setIsAssignmentDialogOpen] = React.useState(false);


  React.useEffect(() => {
    setUsers(company.users || []);
  }, [company]);
  
  const handleInitiateDelete = (user: User) => {
    setDeletingUser(user);
    setIsDeleteAlertOpen(true);
  };
  
  const openEditDialog = (userToEdit: User | null) => {
      setEditingUser(userToEdit);
      setIsEditDialogOpen(true);
  }

  const handleConfirmDelete = () => {
    if (deletingUser) {
      const updatedUsers = users.filter(u => u.id !== deletingUser.id);
      setUsers(updatedUsers);
    }
    setIsDeleteAlertOpen(false);
    setDeletingUser(null);
  };

  const handleSaveChanges = async () => {
    setIsSaving(true);
    await onUsersChange(users);
    toast({
      title: "¡Equipo actualizado!",
      description: "Los cambios en los usuarios se han guardado correctamente."
    });
    setIsSaving(false);
  };

  const handleSaveUser = async (data: Omit<User, 'id' | 'avatarUrl'>, userId: string | null) => {
      let updatedUsers: User[];
      let updatedId: string;

      if (userId) { // Editing existing user
          const originalUser = users.find(u => u.id === userId);
          if (!originalUser) return;
          const updatedUser = { ...originalUser, ...data };
          updatedUsers = users.map(u => u.id === userId ? updatedUser : u);
          updatedId = userId;
      } else { // This case is now handled by handleUserCreated from the assignment dialog
          return;
      }
      
      setUsers(updatedUsers);
      setIsEditDialogOpen(false);
      setJustUpdatedId(updatedId);
      setTimeout(() => setJustUpdatedId(null), 1500);
  };

  const handleUserCreated = (newUser: User) => {
      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      setJustUpdatedId(newUser.id);
      setTimeout(() => setJustUpdatedId(null), 1500);
  };

  const hasChanges = JSON.stringify(users) !== JSON.stringify(company.users || []);


  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <CardTitle>Gestión de Usuarios de Cliente</CardTitle>
              <CardDescription>
                Añade, edita o elimina miembros del equipo para {company.generalInfo.legalName}.
              </CardDescription>
            </div>
            <div className="flex justify-end gap-2">
              <Button onClick={() => setIsAssignmentDialogOpen(true)} disabled={isSaving}>
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Añadir Miembro
              </Button>
              <Button onClick={handleSaveChanges} disabled={!hasChanges || isSaving}>
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSaving ? 'Guardando...' : 'Guardar Cambios'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Rol</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.length > 0 ? users.map((user) => (
                  <TableRow 
                    key={user.id}
                    className={cn(justUpdatedId === user.id && "row-pulse-animation")}
                  >
                    <TableCell>
                      <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                              <AvatarImage src={user.avatarUrl} alt={user.name} data-ai-hint="user avatar" />
                              <AvatarFallback>{user.name.charAt(0).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{user.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{user.email}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{roleTranslations[user.role] || user.role}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" disabled={user.id === loggedInUser?.id}>
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Menú de acciones para {user.name}</span>
                              </Button>
                            </DropdownMenuTrigger>
                          </TooltipTrigger>
                           <TooltipContent><p>Menú de acciones</p></TooltipContent>
                        </Tooltip>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => openEditDialog(user)}>
                            <Pencil className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => handleInitiateDelete(user)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                      <TableCell colSpan={4} className="h-48 text-center text-muted-foreground">
                        <div className="flex flex-col items-center justify-center gap-2">
                            <Users className="w-10 h-10" />
                            <p className="font-medium">¡Es hora de construir tu equipo!</p>
                            <p className="text-sm">Añade tu primer usuario para empezar a colaborar.</p>
                        </div>
                      </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      <UserAssignmentDialog
          isOpen={isAssignmentDialogOpen}
          onOpenChange={setIsAssignmentDialogOpen}
          onUserCreated={handleUserCreated}
      />

      <UserEditDialog 
        isOpen={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onSave={handleSaveUser}
        user={editingUser}
        isGlobalAdmin={false}
      />

      <DeleteConfirmationDialog
        isOpen={isDeleteAlertOpen}
        onOpenChange={setIsDeleteAlertOpen}
        onConfirm={handleConfirmDelete}
        itemName={deletingUser?.name || ''}
        itemType="usuario"
        description="Esta acción eliminará al usuario de esta empresa. El cambio no se guardará en la base de datos hasta que presiones 'Guardar Cambios'."
      />
    </>
  );
}
