
"use client";

import * as React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts";
import type { CalendarEvent } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { cn } from "@/lib/utils";

type TasksByStatusChartProps = {
  events: CalendarEvent[];
};

const COLORS = {
  completed: "hsl(var(--completed))",
  pending: "hsl(var(--pending))",
  "in-progress": "hsl(var(--in-progress))",
};
const STATUS_NAMES = {
    completed: "Completadas",
    pending: "Pendientes",
    "in-progress": "En Progreso",
};


export function TasksByStatusChart({ events }: TasksByStatusChartProps) {
  const data = React.useMemo(() => {
    const statusCounts = {
      completed: 0,
      pending: 0,
      "in-progress": 0,
    };

    events.forEach((event) => {
      statusCounts[event.status]++;
    });
    
    return Object.entries(statusCounts).map(([name, value]) => ({
      name: STATUS_NAMES[name as keyof typeof STATUS_NAMES],
      value,
      color: COLORS[name as keyof typeof COLORS],
    }));
  }, [events]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm font-medium">Resumen de Tareas por Estado</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                <Pie
                    data={data}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={60}
                    innerRadius={40}
                    paddingAngle={5}
                    dataKey="value"
                    >
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                </Pie>
                <Legend 
                    layout="vertical" 
                    verticalAlign="middle" 
                    align="right"
                    iconType="circle"
                    formatter={(value, entry) => (
                        <span className="text-xs text-muted-foreground">
                            {value} <span className="font-semibold text-foreground">{entry.payload?.value}</span>
                        </span>
                    )}
                 />
                </PieChart>
            </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
