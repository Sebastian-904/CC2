
"use client";

import * as React from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { ComplianceObligation, Priority } from "@/lib/types";
import { format } from "date-fns";
import { Download } from "lucide-react";
import { Badge } from "./ui/badge";

type ReportPreviewProps = {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  reportTitle: string;
  reportData: Partial<ComplianceObligation>[];
  onConfirmDownload: () => void;
  reportType: 'monthly-summary' | 'pending-by-category' | 'upcoming-deadlines';
};

const priorityTranslations: {[key in Priority]: string} = {
    high: 'Alta',
    medium: 'Media',
    low: 'Baja',
}

const statusTranslations: {[key: string]: string} = {
    completed: 'Completado',
    pending: 'Pendiente',
    'in-progress': 'En Progreso',
}

export function ReportPreview({
  isOpen,
  onOpenChange,
  reportTitle,
  reportData,
  onConfirmDownload,
  reportType,
}: ReportPreviewProps) {

  const renderTable = () => {
    switch (reportType) {
      case 'pending-by-category':
        const groupedData: {[key: string]: Partial<ComplianceObligation>[]} = reportData.reduce((acc, event) => {
          const key = event.category || 'Sin Categoría';
          if (!acc[key]) {
            acc[key] = [];
          }
          acc[key].push(event);
          return acc;
        }, {} as {[key: string]: Partial<ComplianceObligation>[]});

        return (
          <div>
            {Object.entries(groupedData).map(([category, events]) => (
              <div key={category} className="mb-6">
                <h3 className="font-semibold text-lg mb-2 p-2 bg-muted rounded-md">{category}</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha Límite</TableHead>
                      <TableHead>Título</TableHead>
                      <TableHead>Prioridad</TableHead>
                      <TableHead>Asignado</TableHead>
                    </TableRow>
                  </TableHeader>
                   <TableBody>
                    {events.map((event) => (
                      <TableRow key={event.id}>
                        <TableCell>
                          {event.date ? format(new Date(event.date), "dd/MM/yyyy") : ""}
                        </TableCell>
                        <TableCell>{event.title}</TableCell>
                        <TableCell><Badge variant="outline" className="capitalize">{priorityTranslations[event.priority]}</Badge></TableCell>
                        <TableCell>{event.assignee?.name}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ))}
          </div>
        );
      
      case 'upcoming-deadlines':
         return (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Categoría</TableHead>
                  <TableHead>Prioridad</TableHead>
                   <TableHead>Asignado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reportData.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>
                      {event.date ? format(new Date(event.date), "dd/MM/yyyy") : ""}
                    </TableCell>
                    <TableCell>{event.title}</TableCell>
                    <TableCell><Badge variant="outline">{event.category}</Badge></TableCell>
                    <TableCell className="capitalize">{priorityTranslations[event.priority]}</TableCell>
                    <TableCell>{event.assignee?.name}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
         );

      case 'monthly-summary':
      default:
        return (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Categoría</TableHead>
                  <TableHead>Prioridad</TableHead>
                  <TableHead>Asignado</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reportData.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>
                      {event.date ? format(new Date(event.date), "dd/MM/yyyy") : ""}
                    </TableCell>
                    <TableCell>{event.title}</TableCell>
                    <TableCell><Badge variant="outline">{event.category}</Badge></TableCell>
                    <TableCell className="capitalize">{priorityTranslations[event.priority]}</TableCell>
                    <TableCell>{event.assignee?.name}</TableCell>
                    <TableCell className="capitalize">{statusTranslations[event.status]}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
        );
    }
  }


  return (
    <Sheet open={isOpen} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-3xl w-full flex flex-col">
        <SheetHeader>
          <SheetTitle>Vista Previa del Reporte</SheetTitle>
          <SheetDescription>{reportTitle}</SheetDescription>
        </SheetHeader>
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full pr-4">
            {reportData.length > 0 ? (
                renderTable()
            ) : (
                <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">No hay datos para mostrar en este reporte.</p>
                </div>
            )}
          </ScrollArea>
        </div>
        <SheetFooter className="pt-4">
          <Button
            type="button"
            onClick={() => onOpenChange(false)}
            variant="outline"
          >
            Cerrar
          </Button>
          <Button type="button" onClick={onConfirmDownload} disabled={reportData.length === 0}>
            <Download className="mr-2 h-4 w-4" />
            Confirmar y Descargar PDF
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}
