

"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { FormSection } from "./ui/form-section";
import { Button } from "./ui/button";
import type { GeneralInfo, IncorporationDocument, LegalRepresentative } from "@/lib/types";
import { Loader2 } from "lucide-react";

const generalInfoSchema = z.object({
  generalInfo: z.object({
      legalName: z.string().min(3, "La razón social debe tener al menos 3 caracteres."),
      rfc: z.string().min(12, "El RFC debe tener al menos 12 caracteres."),
      economicActivity: z.string().min(1, "La actividad económica es requerida."),
      taxAddress: z.string().min(10, "El domicilio fiscal debe tener al menos 10 caracteres."),
      phone: z.string().min(10, "El teléfono debe tener al menos 10 dígitos."),
  }),
  incorporationDocument: z.object({
      deedNumber: z.string().optional(),
      date: z.string().optional(),
      notary: z.string().optional(),
  }),
  legalRepresentative: z.object({
      powerOfAttorneyDeed: z.string().optional(),
      date: z.string().optional(),
      notary: z.string().optional(),
  })
});

type GeneralInfoFormValues = z.infer<typeof generalInfoSchema>;

type CompanyProfileGeneralFormProps = {
  isReadOnly: boolean;
  defaultValues: {
    generalInfo: GeneralInfo,
    incorporationDocument: IncorporationDocument,
    legalRepresentative: LegalRepresentative
  };
  onSave: (data: GeneralInfoFormValues) => Promise<void>;
};

const getSafeDefaults = (values: CompanyProfileGeneralFormProps['defaultValues']): GeneralInfoFormValues => {
    return {
        generalInfo: values.generalInfo || { legalName: '', rfc: '', economicActivity: '', taxAddress: '', phone: ''},
        incorporationDocument: values.incorporationDocument || { deedNumber: '', date: '', notary: ''},
        legalRepresentative: values.legalRepresentative || { powerOfAttorneyDeed: '', date: '', notary: ''}
    }
}

export function CompanyProfileGeneralForm({ isReadOnly, defaultValues, onSave }: CompanyProfileGeneralFormProps) {
  const [isSaving, setIsSaving] = React.useState(false);
  const form = useForm<GeneralInfoFormValues>({
    resolver: zodResolver(generalInfoSchema),
    defaultValues: getSafeDefaults(defaultValues),
  });
  
  React.useEffect(() => {
    form.reset(getSafeDefaults(defaultValues));
  }, [defaultValues, form]);

  const onSubmit = async (data: GeneralInfoFormValues) => {
    setIsSaving(true);
    await onSave(data);
    setIsSaving(false);
    form.reset(data); // Re-sync form state after saving
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Información General</CardTitle>
            <CardDescription>
              Datos fundamentales y legales de la empresa.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormSection title="Datos Fiscales" description="Información principal para la identificación fiscal de la empresa.">
              <fieldset disabled={isReadOnly || isSaving} className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="generalInfo.legalName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Razón Social</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. ACME S.A. de C.V." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="generalInfo.rfc"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>RFC</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. AME880808XXX" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="generalInfo.economicActivity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Actividad Económica Principal</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. Manufactura de electrónicos" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="generalInfo.phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Teléfono</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. 55 1234 5678" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="generalInfo.taxAddress"
                  render={({ field }) => (
                    <FormItem className="md:col-span-2">
                      <FormLabel>Domicilio Fiscal</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Ej. Av. Siempre Viva 742, Springfield..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </fieldset>
            </FormSection>
            
            <FormSection title="Acta Constitutiva" description="Datos del documento de constitución de la sociedad.">
               <fieldset disabled={isReadOnly || isSaving} className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="incorporationDocument.deedNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>No. de Escritura</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej. 12345" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="incorporationDocument.date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fecha</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="incorporationDocument.notary"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nombre del Fedatario Público</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej. Lic. Juan Pérez" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
               </fieldset>
            </FormSection>

            <FormSection title="Representante Legal" description="Datos del poder notarial del representante legal principal.">
               <fieldset disabled={isReadOnly || isSaving} className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="legalRepresentative.powerOfAttorneyDeed"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>No. de Escritura del Poder</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej. 54321" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="legalRepresentative.date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Fecha del Poder</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="legalRepresentative.notary"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nombre del Fedatario Público</FormLabel>
                        <FormControl>
                          <Input placeholder="Ej. Lic. Ana García" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
               </fieldset>
            </FormSection>
             {!isReadOnly && (
                <div className="flex justify-end">
                    <Button type="submit" disabled={!form.formState.isDirty || isSaving}>
                        {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isSaving ? "Guardando..." : "Guardar Cambios"}
                    </Button>
                </div>
            )}
          </CardContent>
        </Card>
      </form>
    </Form>
  );
}
