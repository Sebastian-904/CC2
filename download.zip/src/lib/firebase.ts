
// Import the functions you need from the SDKs you need
import { initializeApp, getApp, getApps } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBpF8XDzQLEjZNg9QHCyrTwNJh8aYwXmcY",
  authDomain: "compliance-calendar-pro.firebaseapp.com",
  projectId: "compliance-calendar-pro",
  storageBucket: "compliance-calendar-pro.appspot.com",
  messagingSenderId: "680960225362",
  appId: "1:680960225362:web:8a3e5685e3eff00af8af8b"
};


// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);

export { app, db, auth, storage };
