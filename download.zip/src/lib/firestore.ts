

import { db } from './firebase';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, where, DocumentData, getDoc, setDoc, writeBatch, arrayUnion, orderBy, limit, Timestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import type { CalendarEvent, Company, ComplianceObligation, User, Comment, TaskCategory, TaskTemplate, AuditLog, Attachment, Priority } from './types';
import { startOfYear, addYears, addMonths, setDate, setDayOfYear, format, isBefore, startOfMonth, endOfDay, startOfWeek, addWeeks, setDay } from 'date-fns';
import { sendCommentNotificationEmail } from './email';

// Initialize Firebase Storage
const storage = getStorage();

// --- Audit Log Functions ---

const auditLogsCollection = collection(db, 'audit_logs');

/**
 * Logs a user action to the audit trail.
 * @param actor - The user performing the action.
 * @param action - A string identifier for the action (e.g., 'COMPANY_CREATED').
 * @param details - A human-readable description of the action.
 * @param companyContext - Optional company object for context.
 */
export const logUserActivity = async (
    actor: User,
    action: string,
    details: string,
    companyContext?: Company,
): Promise<void> => {
    try {
        const logEntry: Omit<AuditLog, 'id'> = {
            timestamp: new Date().toISOString(),
            userId: actor.id,
            userName: actor.name,
            action,
            details,
            ...(companyContext && {
                companyId: companyContext.id,
                companyName: companyContext.generalInfo.legalName,
            }),
        };
        await addDoc(auditLogsCollection, logEntry);
    } catch (error) {
        console.error("Failed to log user activity:", error);
        // Fail silently so as not to interrupt the user's action
    }
};

type GetAuditLogsParams = {
    filters: {
        userId?: string;
        companyId?: string;
        startDate?: Date;
        endDate?: Date;
    };
    logLimit?: number;
};

/**
 * Fetches audit logs with optional filtering.
 * @param params - The filter and limit parameters.
 * @returns A promise that resolves to an array of audit log entries.
 */
export const getAuditLogs = async ({ filters, logLimit = 50 }: GetAuditLogsParams): Promise<AuditLog[]> => {
    const qConstraints: any[] = [orderBy("timestamp", "desc"), limit(logLimit)];

    if (filters.userId) {
        qConstraints.push(where("userId", "==", filters.userId));
    }
    if (filters.companyId) {
        qConstraints.push(where("companyId", "==", filters.companyId));
    }
    if (filters.startDate) {
        qConstraints.push(where("timestamp", ">=", filters.startDate.toISOString()));
    }
    if (filters.endDate) {
        // To include the whole end day, we set the time to the end of the day.
        qConstraints.push(where("timestamp", "<=", endOfDay(filters.endDate).toISOString()));
    }

    const q = query(auditLogsCollection, ...qConstraints);
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AuditLog));
};

// --- MOCK DATA FOR GLOBAL USERS (until a real auth system is in place) ---
const MOCK_GLOBAL_USERS: Omit<User, 'password'>[] = [
    { id: 'admin-01', name: 'ADMINISTRADOR', email: 'admin@compliance.com', avatarUrl: `https://placehold.co/32x32.png`, role: 'admin' },
    { id: 'consultor-01', name: 'Consultor Principal', email: 'consultor1@compliancepro.com', avatarUrl: `https://placehold.co/32x32.png`, role: 'consultor' },
    { id: 'consultor-02', name: 'Consultor de Cuentas', email: 'consultor2@compliancepro.com', avatarUrl: `https://placehold.co/32x32.png`, role: 'consultor' },
    { id: 'consultor-03', name: 'Especialista Fiscal', email: 'consultor3@compliancepro.com', avatarUrl: `https://placehold.co/32x32.png`, role: 'consultor' },
    { id: 'consultor-04', name: 'Especialista Legal', email: 'consultor4@compliancepro.com', avatarUrl: `https://placehold.co/32x32.png`, role: 'consultor' },
    { id: 'consultor-05', name: 'Auditor de Procesos', email: 'consultor5@compliancepro.com', avatarUrl: `https://placehold.co/32x32.png`, role: 'consultor' },
];

const GLOBAL_USERS_DOC_ID = '--global-users--';

export const getGlobalUsers = async (): Promise<User[]> => {
    const docRef = doc(db, 'users', GLOBAL_USERS_DOC_ID);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
        const users = docSnap.data().users as any[];
        return users.map(u => ({...u, password: 'password123'}));
    } else {
        await setDoc(docRef, { users: MOCK_GLOBAL_USERS });
        return MOCK_GLOBAL_USERS as User[];
    }
};

export const saveGlobalUsers = async (users: User[], actor: User): Promise<void> => {
    const docRef = doc(db, 'users', GLOBAL_USERS_DOC_ID);
    await setDoc(docRef, { users });
    await logUserActivity(actor, 'GLOBAL_USERS_UPDATED', `Updated the list of global users.`);
};


// --- Event Functions ---

const getEventsCollection = (companyId: string) => {
    return collection(db, 'companies', companyId, 'events');
}

export const getEvents = async (companyId: string): Promise<CalendarEvent[]> => {
    const eventsCollection = getEventsCollection(companyId);
    const snapshot = await getDocs(eventsCollection);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CalendarEvent));
};

export const addEvent = async (companyId: string, eventData: Omit<CalendarEvent, 'id' | 'companyId'>, actor: User): Promise<CalendarEvent> => {
    const eventsCollection = getEventsCollection(companyId);
    const eventWithCompanyId = { ...eventData, companyId };
    const docRef = await addDoc(eventsCollection, eventWithCompanyId as DocumentData);
    
    const newEvent = { id: docRef.id, ...eventWithCompanyId } as CalendarEvent;
    
    // Log this action
    const company = await getCompanyProfile(companyId);
    if(company) {
        await logUserActivity(actor, 'EVENT_CREATED', `Created event "${newEvent.title}"`, company);
    }
    
    return newEvent;
};


export const updateEvent = async (companyId: string, eventId: string, eventData: Partial<Omit<CalendarEvent, 'id'>>, actor: User): Promise<void> => {
    const eventDoc = doc(db, 'companies', companyId, 'events', eventId);
    await updateDoc(eventDoc, eventData);
    
    const company = await getCompanyProfile(companyId);
     if(company) {
        await logUserActivity(actor, 'EVENT_UPDATED', `Updated event "${eventData.title || eventId}"`, company);
    }
};

export const deleteEvent = async (companyId: string, eventId: string, actor: User): Promise<void> => {
    const eventDoc = doc(db, 'companies', companyId, 'events', eventId);
    const eventSnap = await getDoc(eventDoc);
    const eventTitle = eventSnap.data()?.title || eventId;
    
    await deleteDoc(eventDoc);
    
    const company = await getCompanyProfile(companyId);
     if(company) {
        await logUserActivity(actor, 'EVENT_DELETED', `Deleted event "${eventTitle}"`, company);
    }
};

export const addCommentToEvent = async (companyId: string, eventId: string, commentData: Omit<Comment, 'id'>, actor: User): Promise<void> => {
    const eventDocRef = doc(db, 'companies', companyId, 'events', eventId);
    const commentWithId = { ...commentData, id: `comment-${Date.now()}` };
    
    await updateDoc(eventDocRef, {
        comments: arrayUnion(commentWithId)
    });

    const eventSnap = await getDoc(eventDocRef);
    if (eventSnap.exists()) {
        const eventData = eventSnap.data() as CalendarEvent;
        // Log activity
        const company = await getCompanyProfile(companyId);
        if(company) {
           await logUserActivity(actor, 'COMMENT_ADDED', `Added comment to event "${eventData.title}"`, company);
        }
        // Send email
        await sendCommentNotificationEmail({
            eventTitle: eventData.title,
            commenter: commentData.user,
            commentText: commentData.text,
            participants: eventData.participants,
            assignee: eventData.assignee,
        });
    }
};

export const addAttachmentToEvent = async (
    companyId: string,
    eventId: string,
    file: File,
    actor: User
): Promise<Attachment> => {
    if (!file) {
        throw new Error('No file provided for upload.');
    }

    // 1. Upload file to Firebase Storage
    const storageRef = ref(storage, `companies/${companyId}/events/${eventId}/${file.name}`);
    const uploadResult = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(uploadResult.ref);

    // 2. Create Attachment object
    const newAttachment: Attachment = {
        id: `att-${Date.now()}-${file.name}`,
        name: file.name,
        url: downloadURL,
        type: 'other', // You can add logic to determine type from file.type
    };

    // 3. Update the event document in Firestore
    const eventDocRef = doc(db, 'companies', companyId, 'events', eventId);
    await updateDoc(eventDocRef, {
        attachments: arrayUnion(newAttachment)
    });

    // 4. Log the activity
    const company = await getCompanyProfile(companyId);
    const eventSnap = await getDoc(eventDocRef);
    const eventTitle = eventSnap.data()?.title || eventId;
    if (company) {
        await logUserActivity(actor, 'ATTACHMENT_ADDED', `Added attachment "${file.name}" to event "${eventTitle}"`, company);
    }
    
    return newAttachment;
};



// --- Company Profile Functions ---

const MOCK_COMPANY_USERS: Omit<User, 'password'>[] = [
    { id: 'client-admin-01', name: 'Laura Martinez', email: 'laura.martinez@innovatech.com', role: 'cliente_admin', avatarUrl: `https://placehold.co/32x32.png` },
    { id: 'client-member-01', name: 'Carlos Gomez', email: 'carlos.gomez@innovatech.com', role: 'cliente_miembro', avatarUrl: `https://placehold.co/32x32.png` },
];

const MOCK_COMPANY_OBLIGATIONS: Omit<ComplianceObligation, 'id'>[] = [
    { name: 'Reporte Anual de Operaciones de Comercio Exterior', status: 'activa', frequency: 'anual', dueDay: 90, assigneeId: 'client-admin-01', category: 'Fiscal', defaultPriority: 'high' },
    { name: 'Declaración Mensual de IVA', status: 'activa', frequency: 'mensual', dueDay: 17, assigneeId: 'client-member-01', category: 'Fiscal', defaultPriority: 'high'},
    { name: 'Declaración Mensual de ISR', status: 'activa', frequency: 'mensual', dueDay: 17, assigneeId: 'client-member-01', category: 'Fiscal', defaultPriority: 'medium'},
    { name: 'Reporte de Inventarios IMMEX', status: 'activa', frequency: 'anual', dueDay: 150, assigneeId: 'client-admin-01', category: 'Comercio Exterior', defaultPriority: 'medium' },
    { name: 'Pago de Cuota Anual de PROSEC', status: 'inactiva', frequency: 'anual', dueDay: 180, assigneeId: 'client-admin-01', category: 'Administrativo', defaultPriority: 'low' },
];


const MOCK_COMPANY_ID = 'innovatech-global-logistics';

const createDemoCompany = async (): Promise<Company> => {
    const companyDocRef = doc(db, 'companies', MOCK_COMPANY_ID);

    const allGlobalUsers = await getGlobalUsers();
    const actor = allGlobalUsers.find(u => u.role === 'admin');
    if (!actor) {
      throw new Error("Could not find admin user to perform initial setup.");
    }
    
    const demoCompanyData: Omit<Company, 'id' | 'events'> = {
        generalInfo: {
            legalName: 'Innovatech Global Logistics, S.A. de C.V.',
            rfc: 'IGL180101XYZ',
            economicActivity: 'Servicios de logística y transporte de carga internacional.',
            taxAddress: 'Av. de la Industria 456, Parque Industrial Querétaro, 76220, Querétaro, Qro.',
            phone: '442 123 4567'
        },
        incorporationDocument: {
            deedNumber: '54321',
            date: '2018-01-15',
            notary: 'Notaría Pública 15 de Querétaro'
        },
        legalRepresentative: {
            powerOfAttorneyDeed: '54322',
            date: '2018-01-20',
            notary: 'Notaría Pública 15 de Querétaro'
        },
        programs: {
            immex: { registrationNumber: 'IM-1234-2018', modality: 'Servicios', authorizationDate: '2018-03-01' },
            prosec: { registrationNumber: 'PS-5678-2019', modality: 'Servicios Logísticos', authorizationDate: '2019-05-10' },
            certiva: { folio: 'IVA-9988', category: 'AA', resolution: 'Favorable', renewalDate: '2025-06-30' },
        },
        members: [
            { id: 'member-1', fullName: 'Inversiones Tech S.A.', rfc: 'ITE101010ABC', personType: 'moral', role: 'socio', nationality: 'Mexicana', taxObligationInMexico: true }
        ],
        addresses: [
            { id: 'addr-1', streetAndNumber: 'Bodega 12, Av. de la Luz 100', postalCode: '76120', neighborhood: 'Parque Industrial Benito Juárez', municipality: 'Querétaro', city: 'Querétaro', state: 'Querétaro', phone: '442 987 6543', linkedProgram: 'immex' }
        ],
        customsAgents: [
            { id: 'agent-1', name: 'Agencia Aduanal Express', patentNumber: '3890', status: 'aceptado' }
        ],
        users: MOCK_COMPANY_USERS as User[],
        obligations: MOCK_COMPANY_OBLIGATIONS.map(o => ({...o, id: `ob-${Math.random()}`})),
        logoUrl: '',
    };
    
    await setDoc(companyDocRef, demoCompanyData);
    
    await generateEventsFromObligations(MOCK_COMPANY_ID, demoCompanyData.obligations, demoCompanyData.users, actor);
    
    const companySnap = await getDoc(companyDocRef);
    const company = { id: companySnap.id, ...companySnap.data() } as Company;
    
    await logUserActivity(actor, 'DEMO_COMPANY_CREATED', `Created demo company "${company.generalInfo.legalName}"`);
    return company;
};


export const getCompanies = async (): Promise<Company[]> => {
    const companiesCollection = collection(db, 'companies');
    const snapshot = await getDocs(companiesCollection);
    let companies = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Company));

    // Ensure the demo company always exists if it was deleted or never created.
    const demoCompanyExists = companies.some(c => c.id === MOCK_COMPANY_ID);
    if (!demoCompanyExists) {
        const demoCompany = await createDemoCompany();
        companies.push(demoCompany);
    }

    return companies;
}

/**
 * Finds the company a given user ID belongs to.
 * This is used for client-role users to scope their data.
 * @param userId The ID of the user to find.
 * @returns The Company object if found, otherwise null.
 */
export const findUserCompany = async (userId: string): Promise<Company | null> => {
    const companiesRef = collection(db, 'companies');
    // Firestore's `array-contains` works for exact matches on objects in an array.
    // However, our User object in the array can have more properties (like password).
    // The safest way to query is to iterate, but for performance, we should ensure
    // that the object we query for is a subset of the stored object.
    // A more robust but complex query would be needed if we can't guarantee this.
    // For now, let's try a more direct query on all companies, as the number of companies is small.
    
    try {
        const querySnapshot = await getDocs(companiesRef);
        for (const companyDoc of querySnapshot.docs) {
            const companyData = companyDoc.data() as Company;
            const userExists = (companyData.users || []).some(u => u.id === userId);
            if (userExists) {
                return { id: companyDoc.id, ...companyData };
            }
        }
        return null;
    } catch (error) {
        console.error("Error finding user's company:", error);
        return null;
    }
};

export const getCompanyProfile = async (companyId: string): Promise<Company | null> => {
    const companyDocRef = doc(db, 'companies', companyId);
    const docSnap = await getDoc(companyDocRef);

    if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Company;
    } else {
        console.warn(`No company profile found for ID: ${companyId}`);
        return null;
    }
};

export const updateCompanyProfile = async (companyId: string, data: Partial<Omit<Company, 'id'>>, actor: User, isNew: boolean): Promise<Company> => {
    const companyDocRef = doc(db, 'companies', companyId);
    
    await setDoc(companyDocRef, data, { merge: true });
    
    // Fetch the final state after update
    const updatedSnap = await getDoc(companyDocRef);
    if (!updatedSnap.exists()) {
        throw new Error("Failed to create or update company profile.");
    }
    const company = { id: updatedSnap.id, ...updatedSnap.data() } as Company;

    const action = isNew ? 'COMPANY_CREATED' : 'COMPANY_PROFILE_UPDATED';
    const details = isNew 
        ? `Created new company "${company.generalInfo.legalName}"` 
        : `Updated profile for company "${company.generalInfo.legalName}"`;
    await logUserActivity(actor, action, details, company);
    
    return company;
};

// --- Smart Obligation Functions ---

export const generateEventsFromObligations = async (
    companyId: string, 
    obligations: ComplianceObligation[],
    companyUsers: User[],
    actor: User
) => {
    const batch = writeBatch(db);
    const eventsCollectionRef = getEventsCollection(companyId);

    // Clear previously generated events
    const q = query(eventsCollectionRef, where("sourceObligationId", "!=", null));
    const oldEventsSnap = await getDocs(q);
    oldEventsSnap.forEach(document => {
        batch.delete(document.ref);
    });

    const today = new Date();
    const activeObligations = obligations.filter(o => o.status === 'activa');

    for (const obligation of activeObligations) {
        let assignee = companyUsers.find(u => u.id === obligation.assigneeId) || actor;

        const eventBase: Omit<CalendarEvent, 'id' | 'date' | 'status'> = {
            companyId,
            title: obligation.name,
            description: `Evento generado automáticamente para la obligación: ${obligation.name}.`,
            startTime: '09:00',
            endTime: '17:00',
            location: 'N/A',
            participants: [],
            comments: [],
            attachments: [],
            priority: obligation.defaultPriority || 'medium',
            category: obligation.category || 'General',
            assignee,
            sourceObligationId: obligation.id,
        };
        
        // Generate for the last 6 months and next 12 months for monthly/annual
        // Generate for last 8 weeks and next 24 weeks for weekly
        const iterations = obligation.frequency === 'semanal' ? { past: -8, future: 24 } : { past: -6, future: 12 };

        for (let i = iterations.past; i < iterations.future; i++) {
            let eventDate: Date | null = null;

            if (obligation.frequency === 'semanal') {
                // dueDay is 1 (Mon) to 7 (Sun)
                const startOfCurrentWeek = startOfWeek(today, { weekStartsOn: 1 });
                const targetWeek = addWeeks(startOfCurrentWeek, i);
                eventDate = setDay(targetWeek, obligation.dueDay % 7, { weekStartsOn: 1 }); // setDay uses 0 for Sun
            } else if (obligation.frequency === 'mensual') {
                const startOfCurrentMonth = startOfMonth(today);
                eventDate = setDate(addMonths(startOfCurrentMonth, i), obligation.dueDay);
            } else if (obligation.frequency === 'anual') {
                // For annual, only generate for last year and this year if relevant
                if (i < 0) { // Past events
                    let pastYearDate = setDayOfYear(addYears(startOfYear(today), -1), obligation.dueDay);
                    if (i === iterations.past) { // Only generate one past annual event
                         eventDate = pastYearDate;
                    } else continue;
                } else { // Future events
                    let futureYearDate = setDayOfYear(addYears(startOfYear(today), 0), obligation.dueDay);
                     if (i === 0) { // Only generate one future annual event
                         eventDate = futureYearDate;
                     } else continue;
                }
            }

            if (!eventDate) continue;

            let status: CalendarEvent['status'] = 'pending';
            if (isBefore(eventDate, today)) {
                status = 'completed';
            }
            
            const newEvent: Omit<CalendarEvent, 'id'> = { 
                ...eventBase, 
                date: format(eventDate, 'yyyy-MM-dd'),
                status: status,
            };

            const newEventRef = doc(eventsCollectionRef);
            batch.set(newEventRef, newEvent);
        }
    }

    await batch.commit();

    // Log this action
    const company = await getCompanyProfile(companyId);
    if(company) {
        await logUserActivity(actor, 'EVENTS_REGENERATED', `Regenerated calendar events from obligations`, company);
    }
};

// --- Task Categories and Templates ---

const categoriesCollection = collection(db, 'task_categories');
const templatesCollection = collection(db, 'task_templates');

// Categories
export const getTaskCategories = async (): Promise<TaskCategory[]> => {
    const snapshot = await getDocs(categoriesCollection);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TaskCategory));
};

export const addTaskCategory = async (categoryData: Omit<TaskCategory, 'id'>, actor: User): Promise<TaskCategory> => {
    const docRef = await addDoc(categoriesCollection, categoryData);
    const newCategory = { id: docRef.id, ...categoryData };
    await logUserActivity(actor, 'CATEGORY_CREATED', `Created category "${newCategory.name}"`);
    return newCategory;
};

export const updateTaskCategory = async (id: string, categoryData: Partial<Omit<TaskCategory, 'id'>>, actor: User): Promise<void> => {
    await updateDoc(doc(db, 'task_categories', id), categoryData);
    await logUserActivity(actor, 'CATEGORY_UPDATED', `Updated category "${categoryData.name || id}"`);
};

export const deleteTaskCategory = async (id: string, actor: User): Promise<void> => {
    const docRef = doc(db, 'task_categories', id);
    const docSnap = await getDoc(docRef);
    const categoryName = docSnap.data()?.name || id;
    await deleteDoc(docRef);
    await logUserActivity(actor, 'CATEGORY_DELETED', `Deleted category "${categoryName}"`);
};

// Templates
export const getTaskTemplates = async (): Promise<TaskTemplate[]> => {
    const snapshot = await getDocs(templatesCollection);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TaskTemplate));
};

export const addTaskTemplate = async (templateData: Omit<TaskTemplate, 'id'>, actor: User): Promise<TaskTemplate> => {
    const docRef = await addDoc(templatesCollection, templateData);
    const newTemplate = { id: docRef.id, ...templateData };
    await logUserActivity(actor, 'TEMPLATE_CREATED', `Created template "${newTemplate.name}"`);
    return newTemplate;
};

export const updateTaskTemplate = async (id: string, templateData: Partial<Omit<TaskTemplate, 'id'>>, actor: User): Promise<void> => {
    await updateDoc(doc(db, 'task_templates', id), templateData);
    await logUserActivity(actor, 'TEMPLATE_UPDATED', `Updated template "${templateData.name || id}"`);
};

export const deleteTaskTemplate = async (id: string, actor: User): Promise<void> => {
    const docRef = doc(db, 'task_templates', id);
    const docSnap = await getDoc(docRef);
    const templateName = docSnap.data()?.name || id;
    await deleteDoc(docRef);
    await logUserActivity(actor, 'TEMPLATE_DELETED', `Deleted template "${templateName}"`);
};
