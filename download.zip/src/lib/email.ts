
import type { User } from './types';

// In a real application, this file would integrate with an email service
// like SendGrid, Resend, or Nodemailer to send actual emails.
// For now, we will just log the email content to the console to simulate sending.

type CommentNotificationPayload = {
  eventTitle: string;
  commenter: User;
  commentText: string;
  participants: User[];
  assignee: User;
};

/**
 * Simulates sending an email to all participants and the assignee of an event
 * when a new comment is added.
 * @param payload - The data needed to construct the notification email.
 */
export const sendCommentNotificationEmail = async (payload: CommentNotificationPayload): Promise<void> => {
  const { eventTitle, commenter, commentText, participants, assignee } = payload;

  // Combine assignee and participants, ensuring no duplicates
  const recipients = new Map<string, User>();
  recipients.set(assignee.id, assignee);
  participants.forEach(p => recipients.set(p.id, p));

  console.log('--- SIMULATING EMAIL NOTIFICATION ---');
  
  recipients.forEach(recipient => {
    // Don't send a notification to the person who made the comment
    if (recipient.id === commenter.id) {
      return;
    }

    const email = {
      to: recipient.email,
      from: 'noreply@compliancepro.com',
      subject: `Nuevo comentario en la tarea: "${eventTitle}"`,
      body: `
        Hola ${recipient.name},

        ${commenter.name} ha añadido un nuevo comentario a la tarea "${eventTitle}".

        Comentario: "${commentText}"

        Puedes ver la tarea y responder aquí: [link a la tarea]

        Gracias,
        El equipo de Compliance Calendar Pro
      `,
    };

    console.log(`
      ---------------------------------
      To: ${email.to}
      From: ${email.from}
      Subject: ${email.subject}
      Body: ${email.body.trim().replace(/\s+/g, ' ')}
      ---------------------------------
    `);
  });

  console.log('--- END OF EMAIL SIMULATION ---');
};

type TaskAssignedNotificationPayload = {
    eventTitle: string;
    assignee: User;
    dueDate: string;
}

/**
 * Simulates sending an email when a task is assigned to a user.
 * @param payload - The data for the assignment email.
 */
export const sendTaskAssignmentEmail = async (payload: TaskAssignedNotificationPayload): Promise<void> => {
    const { eventTitle, assignee, dueDate } = payload;
    
    console.log('--- SIMULATING TASK ASSIGNMENT EMAIL ---');

    const email = {
        to: assignee.email,
        from: 'noreply@compliancepro.com',
        subject: `Se te ha asignado una nueva tarea: "${eventTitle}"`,
        body: `
            Hola ${assignee.name},

            Se te ha asignado una nueva tarea: "${eventTitle}".
            La fecha de vencimiento es el ${dueDate}.

            Por favor, revisa tus tareas pendientes en la plataforma.

            Gracias,
            El equipo de Compliance Calendar Pro
        `
    };

     console.log(`
      ---------------------------------
      To: ${email.to}
      From: ${email.from}
      Subject: ${email.subject}
      Body: ${email.body.trim().replace(/\s+/g, ' ')}
      ---------------------------------
    `);

    console.log('--- END OF EMAIL SIMULATION ---');
}
