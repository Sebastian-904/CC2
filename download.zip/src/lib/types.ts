

export type User = {
  id: string;
  name: string;
  avatarUrl: string;
  email: string;
  role: 'admin' | 'consultor' | 'cliente_admin' | 'cliente_miembro';
};

export type Role = 'admin' | 'consultor' | 'cliente_admin' | 'cliente_miembro';

export type Comment = {
  id: string;
  user: User;
  text: string;
  timestamp: string;
};

export type Attachment = {
  id:string;
  name: string;
  url: string;
  type: 'pdf' | 'doc' | 'image' | 'other';
};

export type Priority = 'low' | 'medium' | 'high';
export type Status = 'completed' | 'in-progress' | 'pending';

export type CalendarEvent = {
  id: string;
  companyId: string;
  sourceObligationId?: string; // Links back to the rule that created it
  title: string;
  description: string;
  date: string; // ISO string YYYY-MM-DD
  startTime: string; // "HH:MM"
  endTime: string; // "HH:MM"
  location: string;
  participants: User[];
  comments: Comment[];
  attachments: Attachment[];
  priority: Priority;
  status: Status;
  category: string;
  assignee: User;
};

export type ComplianceObligation = {
  id: string;
  name: string;
  status: 'activa' | 'inactiva';
  frequency: 'mensual' | 'anual' | 'semanal';
  dueDay: number;
  assigneeId?: string;
  category?: string;
  defaultPriority?: Priority;
};


// --- Company Profile Types ---

export type GeneralInfo = {
  legalName: string;
  rfc: string;
  economicActivity: string;
  taxAddress: string;
  phone: string;
};

export type IncorporationDocument = {
  deedNumber: string;
  date: string; // ISO string
  notary: string;
};

export type LegalRepresentative = {
  powerOfAttorneyDeed: string;
  date: string; // ISO string
  notary: string;
};

export type ImmexProgram = {
  registrationNumber: string;
  modality: string;
  authorizationDate: string; // ISO string
};

export type ProsecProgram = {
  registrationNumber: string;
  modality: string;
  authorizationDate: string; // ISO string
};

export type CertivaRegistration = {
  folio: string;
  category: string;
  resolution: string;
  renewalDate: string; // ISO string
};

export type ImportersRegistry = {
  folio: string;
  date: string; // ISO string
  sector: string;
};

export type CompanyPrograms = {
  immex?: ImmexProgram;
  prosec?: ProsecProgram;
  certiva?: CertivaRegistration;
  importersRegistry?: ImportersRegistry;
};

export type CouncilMember = {
  id: string;
  fullName: string;
  rfc: string;
  personType: 'fisica' | 'moral';
  role: 'socio' | 'representante_legal' | 'administrador';
  nationality: string;
  taxObligationInMexico: boolean;
};

export type CompanyAddress = {
  id: string;
  streetAndNumber: string;
  postalCode: string;
  neighborhood: string;
  municipality: string;
  city: string;
  state: string;
  phone: string;
  linkedProgram: 'immex' | 'prosec' | 'none';
};

export type CustomsAgent = {
  id: string;
  name: string;
  patentNumber: string;
  status: 'aceptado' | 'pendiente';
};

export type Company = {
  id: string;
  generalInfo: GeneralInfo;
  incorporationDocument: IncorporationDocument;
  legalRepresentative: LegalRepresentative;
  programs: CompanyPrograms;
  members: CouncilMember[];
  addresses: CompanyAddress[];
  customsAgents: CustomsAgent[];
  obligations: ComplianceObligation[];
  logoUrl?: string;
  users: User[];
};

// --- SaaS Features ---

export type TaskCategory = {
    id: string;
    name: string;
    color: string;
};

export type TaskTemplate = {
    id: string;
    name: string;
    description: string;
    categoryId: string;
    defaultPriority: Priority;
};

export type AuditLog = {
    id: string;
    timestamp: string; // ISO 8601 format
    userId: string;
    userName: string;
    companyId?: string;
    companyName?: string;
    action: string; // e.g., 'USER_CREATED', 'TASK_UPDATED'
    details: string; // e.g., 'Created user "John Doe" in company "ACME Inc."'
};
