
"use client";

import * as React from "react";
import type { User } from "@/lib/types";
import { useRouter } from "next/navigation";
import { getCompanies, getGlobalUsers } from "@/lib/firestore";
import { useToast } from "@/hooks/use-toast";


type AuthContextType = {
  user: User | null;
  loading: boolean;
  login: (email: string) => Promise<boolean>;
  logout: () => void;
};

const AuthContext = React.createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(true);
  const { toast } = useToast();
  const router = useRouter();

  React.useEffect(() => {
    const checkUser = async () => {
        try {
            const storedUserJson = sessionStorage.getItem('provisional-user');
            if(storedUserJson) {
                const storedUser = JSON.parse(storedUserJson);
                setUser(storedUser);
            }
        } catch (error) {
            console.error("Could not read from session storage", error)
        } finally {
            setLoading(false);
        }
    };
    checkUser();
  }, [])
  

  const login = async (email: string): Promise<boolean> => {
    setLoading(true);
    try {
        const [globalUsers, companies] = await Promise.all([
            getGlobalUsers(),
            getCompanies()
        ]);
        
        const clientUsers = companies.flatMap(c => c.users || []);
        const allUsers = [...globalUsers, ...clientUsers];

        const userToLogin = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

        if (userToLogin) {
            setUser(userToLogin);
            sessionStorage.setItem('provisional-user', JSON.stringify(userToLogin));
            router.push('/dashboard');
            return true;
        }
        
        toast({
            variant: "destructive",
            title: "Usuario no encontrado",
            description: "El usuario seleccionado no pudo ser encontrado en el sistema."
        });
        return false;

    } catch(e) {
        console.error("Login process failed", e);
        toast({ variant: "destructive", title: "Error de Inicio de Sesión", description: "Ocurrió un error inesperado."});
        return false;
    } finally {
        setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem('provisional-user');
    router.push('/login');
  };
  
  const value = {
    user,
    loading,
    login,
    logout,
  };

  return (
    <AuthContext.Provider value={value}>
        {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = React.useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
