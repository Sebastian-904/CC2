'use server';

/**
 * @fileOverview Creates a calendar event from a text description using AI.
 *
 * - createEventFromText - A function that takes a text description and returns event details.
 * - CreateEventFromTextInput - The input type for the createEventFromText function.
 * - CreateEventFromTextOutput - The return type for the createEventFromText function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const CreateEventFromTextInputSchema = z.object({
  description: z.string().describe('A natural language description of the event to create.'),
});
export type CreateEventFromTextInput = z.infer<typeof CreateEventFromTextInputSchema>;

const CreateEventFromTextOutputSchema = z.object({
  title: z.string().describe('The title of the event.'),
  date: z.string().describe('The date of the event in ISO 8601 format (YYYY-MM-DD).'),
  startTime: z.string().describe('The start time of the event in HH:MM format (24-hour clock).'),
  endTime: z.string().describe('The end time of the event in HH:MM format (24-hour clock).'),
  location: z.string().describe('The location of the event.'),
  attendees: z.array(z.string()).describe('A list of email addresses of attendees.'),
  description: z.string().describe('A detailed description of the event.'),
});
export type CreateEventFromTextOutput = z.infer<typeof CreateEventFromTextOutputSchema>;

export async function createEventFromText(input: CreateEventFromTextInput): Promise<CreateEventFromTextOutput> {
  return createEventFromTextFlow(input);
}

const prompt = ai.definePrompt({
  name: 'createEventFromTextPrompt',
  input: {schema: CreateEventFromTextInputSchema},
  output: {schema: CreateEventFromTextOutputSchema},
  prompt: `You are a calendar scheduling assistant.  Your job is to take a text description of an event and extract the key details to create a calendar event.

Here is the event description:

{{description}}

Based on this description, extract the following information:

*   title: The title of the event.
*   date: The date of the event in ISO 8601 format (YYYY-MM-DD).
*   startTime: The start time of the event in HH:MM format (24-hour clock).
*   endTime: The end time of the event in HH:MM format (24-hour clock).
*   location: The location of the event.
*   attendees: A list of email addresses of attendees.
*   description: A detailed description of the event.

Return the information in JSON format.
`,
});

const createEventFromTextFlow = ai.defineFlow(
  {
    name: 'createEventFromTextFlow',
    inputSchema: CreateEventFromTextInputSchema,
    outputSchema: CreateEventFromTextOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
