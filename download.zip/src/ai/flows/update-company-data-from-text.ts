
'use server';

/**
 * @fileOverview An AI flow to extract and structure company profile data from unstructured text.
 *
 * - updateCompanyDataFromText - A function that takes a block of text and returns structured company data.
 * - UpdateCompanyDataFromTextInput - The input type for the function.
 * - UpdateCompanyDataFromTextOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import type { CalendarEvent, ComplianceObligation } from '@/lib/types';


const UpdateCompanyDataFromTextInputSchema = z.object({
  text: z.string().describe('A block of text containing company information.'),
});
export type UpdateCompanyDataFromTextInput = z.infer<typeof UpdateCompanyDataFromTextInputSchema>;

// Defines the structure for the "General" tab data.
const UpdateCompanyDataFromTextOutputSchema = z.object({
    generalInfo: z.object({
        legalName: z.string().optional().describe("The company's full legal name (Razón Social)."),
        rfc: z.string().optional().describe("The company's unique tax identification number (RFC)."),
        economicActivity: z.string().optional().describe("A brief description of the company's main economic activity. This should not be an address."),
        taxAddress: z.string().optional().describe("The company's complete official tax address."),
        phone: z.string().optional().describe("The company's main contact phone number."),
    }).describe("General and fiscal information about the company."),

    incorporationDocument: z.object({
        deedNumber: z.string().optional().describe("The deed number of the incorporation document."),
        date: z.string().optional().describe("The date of the incorporation document in YYYY-MM-DD format."),
        notary: z.string().optional().describe("The name of the public notary for the incorporation."),
    }).describe("Details of the company's incorporation document."),

    legalRepresentative: z.object({
        powerOfAttorneyDeed: z.string().optional().describe("The deed number for the legal representative's power of attorney."),
        date: z.string().optional().describe("The date of the power of attorney document in YYYY-MM-DD format."),
        notary: z.string().optional().describe("The name of the public notary for the power of attorney."),
    }).describe("Details of the company's legal representative."),

    obligations: z.array(z.object({
        name: z.string().describe("The name of the compliance obligation."),
        frequency: z.string().describe("The frequency of the obligation (e.g., mensual, anual, semanal).")
    })).optional().describe("A list of recurring compliance obligations."),

    events: z.array(z.object({
        title: z.string().describe("The title of the calendar event."),
        date: z.string().describe("The date of the event in YYYY-MM-DD format.")
    })).optional().describe("A list of specific, dated events to be added to the calendar."),

}).describe("A JSON object containing the structured data extracted from the text. Omit any fields not found in the text.");

export type UpdateCompanyDataFromTextOutput = {
    generalInfo?: Partial<z.infer<typeof UpdateCompanyDataFromTextOutputSchema.shape.generalInfo>>;
    incorporationDocument?: Partial<z.infer<typeof UpdateCompanyDataFromTextOutputSchema.shape.incorporationDocument>>;
    legalRepresentative?: Partial<z.infer<typeof UpdateCompanyDataFromTextOutputSchema.shape.legalRepresentative>>;
    obligations?: Partial<ComplianceObligation>[];
    events?: Partial<CalendarEvent>[];
}


export async function updateCompanyDataFromText(input: UpdateCompanyDataFromTextInput): Promise<UpdateCompanyDataFromTextOutput> {
  return updateCompanyDataFromTextFlow(input);
}

const prompt = ai.definePrompt({
  name: 'updateCompanyDataFromTextPrompt',
  input: {schema: UpdateCompanyDataFromTextInputSchema},
  output: {schema: UpdateCompanyDataFromTextOutputSchema},
  prompt: `You are an expert data entry assistant and compliance specialist. Your task is to analyze a block of text and extract key information about a company to populate its profile and compliance calendar.

The target information is structured into several sections:
- generalInfo: The official business name (Razón Social), tax ID (RFC), primary business sector (Actividad Económica), full tax address (Domicilio Fiscal), and phone number (Teléfono).
- incorporationDocument: Details of the company's founding legal document (Acta Constitutiva).
- legalRepresentative: Details of the legal representative's power of attorney.
- obligations: A list of recurring compliance duties. Extract the name and frequency.
- events: A list of specific, dated tasks to be added to the calendar. Extract the title and the full date.

Here is the text provided by the user:
---
{{{text}}}
---

Analyze the text carefully and extract the information for all relevant fields.
- Be precise. For example, "Domicilio Fiscal" contains only the address. "Actividad Económica" contains only the description of the business activity. Do not mix them.
- Do not omit fields like "economicActivity" or "phone" if they are present in the text. Be thorough.
- For dates, always convert them to YYYY-MM-DD format.
- For "obligations", capture the core task and its recurrence (e.g., "Revisión mensual").
- For "events", capture the specific task and its exact date (e.g., "Opinión positiva SAT" on "1 de julio").
- If you cannot find a reasonable value for a specific field or section, omit it entirely from the final JSON object.
- Return the extracted data as a clean, well-structured JSON object that strictly follows the output schema.
`,
});

const updateCompanyDataFromTextFlow = ai.defineFlow(
  {
    name: 'updateCompanyDataFromTextFlow',
    inputSchema: UpdateCompanyDataFromTextInputSchema,
    outputSchema: UpdateCompanyDataFromTextOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
