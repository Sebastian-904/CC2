
'use server';

/**
 * @fileOverview An AI flow to intelligently map columns from an Excel file to a target schema.
 *
 * - mapExcelHeaders - A function that takes a list of Excel headers and returns a suggested mapping.
 * - MapExcelHeadersInput - The input type for the mapExcelHeaders function.
 * - MapExcelHeadersOutput - The return type for the mapExcelHeaders function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MapExcelHeadersInputSchema = z.object({
  headers: z.array(z.string()).describe('An array of column headers from the uploaded Excel file.'),
});
export type MapExcelHeadersInput = z.infer<typeof MapExcelHeadersInputSchema>;

// The output is a flexible object where keys are our target schema fields
// and values are the corresponding headers from the user's Excel file.
const MapExcelHeadersOutputSchema = z.object({
  // Company fields
  legalName: z.string().optional().describe("The header for the company's legal name (Razón Social)."),
  rfc: z.string().optional().describe("The header for the company's tax ID (RFC)."),
  economicActivity: z.string().optional().describe("The header for the company's main business activity."),
  taxAddress: z.string().optional().describe("The header for the company's fiscal address."),
  phone: z.string().optional().describe("The header for the company's phone number."),
  deedNumber: z.string().optional().describe("The header for the incorporation deed number."),
  incorporationDate: z.string().optional().describe("The header for the incorporation date."),
  incorporationNotary: z.string().optional().describe("The header for the incorporation notary."),
  powerOfAttorneyDeed: z.string().optional().describe("The header for the legal representative's power of attorney deed number."),
  powerOfAttorneyDate: z.string().optional().describe("The header for the power of attorney date."),
  powerOfAttorneyNotary: z.string().optional().describe("The header for the power of attorney notary."),
  
  // Task/Event fields
  title: z.string().optional().describe("The header from the user's file that maps to the event title."),
  description: z.string().optional().describe("The header from the user's file that maps to the event description."),
  date: z.string().optional().describe("The header from the user's file that maps to the event date."),
  startTime: z.string().optional().describe("The header from the user's file that maps to the event start time."),
  endTime: z.string().optional().describe("The header from the user's file that maps to the event end time."),
  location: z.string().optional().describe("The header from the user's file that maps to the event location."),
  participants: z.string().optional().describe("The header from the user's file that maps to the event participants/attendees."),
  priority: z.string().optional().describe("The header from the user's file that maps to the event priority."),
  status: z.string().optional().describe("The header from the user's file that maps to the event status."),
  category: z.string().optional().describe("The header from the user's file that maps to the event category."),
  assignee: z.string().optional().describe("The header from the user's file that maps to the event assignee/responsible person."),
}).describe("A JSON object mapping the target schema fields to the provided Excel headers. If a header for a specific field is not found, the field should be omitted.");

export type MapExcelHeadersOutput = z.infer<typeof MapExcelHeadersOutputSchema>;

export async function mapExcelHeaders(input: MapExcelHeadersInput): Promise<MapExcelHeadersOutput> {
  return mapExcelHeadersFlow(input);
}

const prompt = ai.definePrompt({
  name: 'mapExcelHeadersPrompt',
  input: {schema: MapExcelHeadersInputSchema},
  output: {schema: MapExcelHeadersOutputSchema},
  prompt: `You are an expert data migration assistant. Your task is to map a list of column headers from a user's Excel file to a predefined target schema.

The target schema fields are:
// COMPANY INFO
- legalName: The company's legal name. Common user headers: 'Razón Social', 'Company Name', 'Nombre Legal'.
- rfc: The company's tax ID. Common user headers: 'RFC', 'Tax ID'.
- economicActivity: The company's main business activity. Common user headers: 'Actividad Económica', 'Giro'.
- taxAddress: The company's fiscal address. Common user headers: 'Domicilio Fiscal'.
- phone: The company's phone number. Common user headers: 'Teléfono'.
- deedNumber: The incorporation deed number. Common user headers: 'No. de Escritura', 'Acta Constitutiva - No. Escritura'.
- incorporationDate: The incorporation date. Common user headers: 'Fecha de Constitución', 'Acta Constitutiva - Fecha'.
- incorporationNotary: The incorporation notary. Common user headers: 'Notario', 'Fedatario', 'Acta Constitutiva - Fedatario'.
- powerOfAttorneyDeed: The legal representative's power of attorney deed number. Common user headers: 'Poder - No. Escritura', 'Representante Legal - No. Escritura Poder'.
- powerOfAttorneyDate: The power of attorney date. Common user headers: 'Fecha Poder', 'Representante Legal - Fecha Poder'.
- powerOfAttorneyNotary: The power of attorney notary. Common user headers: 'Notario Poder', 'Representante Legal - Fedatario'.

// TASK/EVENT INFO
- title: The main name or title of the task/event.
- description: A detailed explanation of the task.
- date: The due date or date of the event.
- startTime: The start time of the event.
- endTime: The end time of the event.
- location: The place where the event occurs.
- participants: People involved in the event.
- priority: The urgency level (e.g., High, Medium, Low).
- status: The current state of the task (e.g., Pending, Completed).
- category: A classification for the task (e.g., Fiscal, Legal).
- assignee: The person responsible for the task. Common user headers could be 'Responsable', 'Encargado', 'Dueño de Tarea', 'Asignado a'.

Here are the headers from the user's file:
{{#each headers}}
- {{{this}}}
{{/each}}

Analyze the user's headers and return a JSON object that maps each field in the target schema to the most probable header from the user's list.
- The keys of the JSON object must be the fields from the target schema (e.g., "title", "description", "legalName").
- The values must be the corresponding header names from the user's list.
- If you cannot find a reasonable match for a schema field, omit it from the final JSON object.
- Be smart with language variations and abbreviations (e.g., 'Fecha' or 'Due Date' for 'date', 'Encargado' for 'assignee', 'Razón Social' for 'legalName').
`,
});

const mapExcelHeadersFlow = ai.defineFlow(
  {
    name: 'mapExcelHeadersFlow',
    inputSchema: MapExcelHeadersInputSchema,
    outputSchema: MapExcelHeadersOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

    