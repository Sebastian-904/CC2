
import { config } from 'dotenv';
config();

// Ensure all flows are loaded
import '@/ai/flows/create-event-from-text.ts';
import '@/ai/flows/update-company-data-from-text.ts';
import '@/ai/flows/map-excel-headers.ts';
